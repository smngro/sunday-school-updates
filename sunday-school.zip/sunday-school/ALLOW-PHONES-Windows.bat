@echo off
title Allow phones to connect
:: Lets phones and the TV reach the app on port 8080 - also when there is NO internet.
:: Just DOUBLE-CLICK this file and click "Yes" when Windows asks.
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo  Asking Windows for permission... click "Yes".
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
if not exist "%~dp0tools\check-network.ps1" (
  echo  Please EXTRACT the zip first, then run this file from the extracted folder.
  pause
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\check-network.ps1"
echo.
echo  ============================================================
echo   On every PHONE (important when there is no internet):
echo    - Connect to the SAME hotspot / Wi-Fi as this computer.
echo    - Turn OFF mobile data, or the phone goes to the internet
echo      instead of this computer.
echo    - If the phone says "Wi-Fi has no internet", tap
echo      "Stay connected" / "Keep Wi-Fi".
echo    - Type the address exactly, starting with http://
echo  ============================================================
echo.
pause

"""Sunday School Manager launcher.

Starts server.py and keeps it running through updates:
  - exit code 3  = an update was installed  -> start the new version
  - the new version fails to start          -> put the previous version back and start it
Uses only the Python standard library. Run it with:  python tools/run.py
"""
import datetime as dt
import json
import os
import subprocess
import sys
import zipfile

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.environ.get("SS_DATA") or os.path.join(os.path.expanduser("~"), "SundaySchool-Data")
PENDING = os.path.join(DATA, "update-pending.json")


def rollback():
    try:
        with open(PENDING, encoding="utf-8") as f:
            info = json.load(f)
        with zipfile.ZipFile(info["app_backup"]) as z:
            for n in z.namelist():
                norm = os.path.normpath(n).replace("\\", "/")
                if n.endswith("/") or norm.startswith(("../", "/")) or ".." in norm.split("/"):
                    continue
                dest = os.path.join(BASE, *norm.split("/"))
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with open(dest + ".new", "wb") as f:
                    f.write(z.read(n))
                os.replace(dest + ".new", dest)
        with open(os.path.join(DATA, "update-failed.json"), "w", encoding="utf-8") as f:
            json.dump({"from": info.get("from"), "to": info.get("to"),
                       "when": dt.datetime.now().isoformat(timespec="minutes")}, f)
        print("\n  The new version did not start, so the previous version was put back.")
        print("  Your data was not changed.\n")
    except Exception as e:
        print(f"\n  Could not put the previous version back: {e}")
        print(f"  The old app is saved in: {DATA}{os.sep}app-backups\n")
    finally:
        try:
            os.remove(PENDING)
        except OSError:
            pass


def main():
    args = sys.argv[1:]
    env = dict(os.environ, SS_LAUNCHER="1")
    first = True
    while True:
        cmd = [sys.executable, os.path.join(BASE, "server.py")] + args + ([] if first else ["--no-browser"])
        first = False
        try:
            code = subprocess.call(cmd, env=env, cwd=BASE)
        except KeyboardInterrupt:
            return 0
        if code == 3:                                  # update installed: start the new version
            print("\n  Starting the new version...\n")
            continue
        if code != 0 and os.path.exists(PENDING):      # new version crashed before it was ready
            rollback()
            continue
        return code


if __name__ == "__main__":
    sys.exit(main())

import urllib.request, urllib.error, json, sys
BASE = sys.argv[1].rstrip("/"); res = {}
def ok(n, c, i=""): res[n] = bool(c); print(("PASS " if c else "FAIL ") + n, i)
def call(path, method="GET", body=None, tok=None, raw=False):
    h = {"Content-Type": "application/json"}
    if tok: h["X-Token"] = tok
    r = urllib.request.Request(BASE + path, data=json.dumps(body).encode() if body is not None else None, headers=h, method=method)
    try:
        with urllib.request.urlopen(r) as x: d = x.read(); return x.status, (d if raw else json.loads(d or b"{}")), dict(x.headers)
    except urllib.error.HTTPError as e:
        d = e.read();
        try: d = json.loads(d)
        except Exception: pass
        return e.code, d, dict(e.headers)
st, d, _ = call("/api/login", "POST", {"pin": "1234"}); tok = d.get("token")
ok("default PIN login allowed (to change it)", st == 200 and d.get("default_pin"))
st, d, _ = call("/api/students", "POST", {"full_name": "X"}, tok)
ok("writes blocked while PIN is 1234", st == 403, d)
st, d, _ = call("/api/pin", "POST", {"old": "1234", "new": "0000"}, tok); ok("short PIN refused", st >= 400, d)
st, d, _ = call("/api/pin", "POST", {"old": "1234", "new": "111111"}, tok); ok("repeated-digit PIN refused", st >= 400, d)
st, d, _ = call("/api/pin", "POST", {"old": "1234", "new": "582913"}, tok); ok("good PIN accepted", st == 200, d); tok = d.get("token", tok)
st, d, _ = call("/api/programs"); ok("programs not public", st == 401, st)
st, d, _ = call("/api/students"); ok("students not public", st == 401, st)
for p in ["/../server.py", "/%2e%2e/server.py", "/..%2fserver.py", "/_headers", "/.hidden"]:
    st, d, _ = call(p, raw=True); ok(f"no file leak {p}", st in (400, 403, 404) or b"import" not in (d if isinstance(d, bytes) else b""), st)
st, d, _ = call("/api/students", "POST", {"full_name": "=HYPERLINK(\"http://x\")", "phone": "+251911", "consent": 1}, tok)
ok("member with formula-like name saved", st == 200, d)
st, d, _ = call("/api/export/students.csv", tok=tok, raw=True)
txt = d.decode("utf-8-sig") if isinstance(d, bytes) else str(d)
ok("CSV export neutralises formulas", "'=HYPERLINK" in txt and "'+251911" in txt, txt[:200].replace("\r\n", " | "))
ok("CSV has consent column", "Consent" in txt.splitlines()[0])
csv = "Full name,Christian name\nአበበ በቀለ,ገብረ ማርያም\nአበበ  በቀለ,ገብረ ማርያም\n"
st, d, _ = call("/api/import/students", "POST", {"csv": csv}, tok); ok("import skips duplicates", st == 200 and d.get("added") == 1 and d.get("duplicates") == 1, d)
st, d, _ = call("/api/import/students", "POST", {"csv": csv}, tok); ok("re-import adds nothing", st == 200 and d.get("added") == 0, d)
st, d, h = call("/", raw=True)
csp = {k.lower(): v for k, v in h.items()}.get("content-security-policy", "")
ok("CSP forbids inline script", "script-src 'self'" in csp and "unsafe-inline" not in csp.split("script-src")[1].split(";")[0], csp)
ok("JS served as javascript", "javascript" in call("/app.js", raw=True)[2].get("Content-Type", ""))
st, d, _ = call("/api/display"); ok("display public, no room code", st == 200 and "code" not in (d.get("checkin") or {}), d.get("checkin"))
print(json.dumps({"passed": sum(res.values()), "total": len(res)}))

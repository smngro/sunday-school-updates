import urllib.request, urllib.error, json, sys
B = sys.argv[1].rstrip("/") + "/api/"; res = []
def ok(n, c, i=""): res.append(bool(c)); print(("PASS " if c else "FAIL ") + n, i)
def call(p, m="GET", b=None, t=None):
    h = {"Content-Type": "application/json"}
    if t: h["X-Token"] = t
    try:
        with urllib.request.urlopen(urllib.request.Request(B + p, data=json.dumps(b).encode() if b is not None else None, headers=h, method=m)) as r: return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e: return {"error": e.code}
t = call("login", "POST", {"pin": "1234"})["token"]; t = call("pin", "POST", {"old": "1234", "new": "582913"}, t)["token"]
call("students", "POST", {"full_name": "First"}, t)
a = call("students", "POST", {"full_name": "Left"}, t)["id"]
call(f"students/{a}", "DELETE", None, t)
b = call("students", "POST", {"full_name": "New"}, t)["id"]
ok("a deleted member's ID number is not given again", b == a + 1, (a, b))
r = call("import/students", "POST", {"csv": "Full name\nCSV Person\n"}, t)
c = [x["id"] for x in call("students", t=t) if x["full_name"] == "CSV Person"][0]
ok("CSV import continues the numbering", c == b + 1, c)
d = call("depts", t=t)[0]["id"]
call(f"depts/{d}", "PUT", {"name": "ክፍል 1", "roles": "ሰብሳቢ, ጸሐፊ\nሰብሳቢ\n" + "x" * 60, "active": 1}, t)
roles = call("depts", t=t)[0]["roles"].split("\n")
ok("roles: commas or lines, no duplicates, length limited", roles[:2] == ["ሰብሳቢ", "ጸሐፊ"] and len(roles) == 3 and len(roles[2]) == 40, roles)
D = json.loads(urllib.request.urlopen(urllib.request.Request(B + "export/all.json", headers={"X-Token": t})).read())
call("import/single", "POST", {"data": D}, t)
ok("roles survive export + import", call("depts", t=t)[0]["roles"].split("\n")[:2] == ["ሰብሳቢ", "ጸሐፊ"])
print(json.dumps({"passed": sum(res), "total": len(res)}))

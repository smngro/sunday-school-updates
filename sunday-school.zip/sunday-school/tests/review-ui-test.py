import asyncio, sys, json, urllib.request
from playwright.async_api import async_playwright
URL = sys.argv[1]; res = []
def ok(n, c, i=""): res.append(bool(c)); print(("PASS " if c else "FAIL ") + n, i)
async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch(executable_path="/usr/bin/google-chrome"); errs = []
        A = await (await br.new_context(viewport={"width": 1366, "height": 900})).new_page(); A.on("pageerror", lambda e: errs.append(str(e)))
        await A.goto(URL); await A.evaluate("localStorage.clear()"); await A.reload(); await A.wait_for_timeout(500)
        await A.fill("#login-pin", "1234"); await A.keyboard.press("Enter"); await A.wait_for_timeout(800)
        await A.fill("#fp-new", "246813"); await A.fill("#fp-new2", "246813"); await A.click("#force-pin-form button.primary"); await A.wait_for_timeout(600)
        await A.evaluate("""async () => { for (const n of ['ሀ', 'ለ', 'ሐ']) await api('students', { method: 'POST', body: { full_name: n, grade: 4 } }); }""")
        await A.click("#tabs button[data-tab=attendance]"); await A.wait_for_timeout(900)
        # meanwhile a member checks in from a phone (simulated by a direct write)
        await A.evaluate("""async () => { const l = await api('attendance?date=' + today() + '&grade=');
            await fetch('/api/attendance', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Token': TOKEN },
              body: JSON.stringify({ date: today(), records: [{ student_id: l[0].id, status: 'P' }] }) }); }""")
        rows = A.locator(".att-row")
        await rows.nth(2).locator("button[data-s='A']").click()
        await A.click("#at-save"); await A.wait_for_timeout(700)
        st = await A.evaluate("async () => (await api('attendance?date=' + today() + '&grade=')).map(s => s.status)")
        ok("a check-in made after the page opened survives the admin's save", st[0] == 'P' and st[2] == 'A', st)
        await A.click("#tabs button[data-tab=mt]"); await A.wait_for_timeout(700)
        await A.click("#mt-grades button[data-grade='4']"); await A.wait_for_timeout(600)
        yr = await A.inner_text("#mt-year"); ok("school year selector", "2019" in yr, yr)
        ok("title shows the school year", "2019" in await A.inner_text("#mt-title"))
        await A.click("#mt-promote"); await A.wait_for_timeout(300); await A.click("#ask-yes"); await A.wait_for_timeout(900)
        grades = await A.evaluate("async () => (await api('students')).map(s => s.grade)")
        ok("promotion button works", grades == [5, 5, 5], grades)
        await A.click("#mt-promote"); await A.wait_for_timeout(300); await A.click("#ask-yes"); await A.wait_for_timeout(700)
        second = await A.is_visible("#ask-dlg") if await A.locator("#ask-dlg").count() else False
        ok("second promotion asks again", second)
        if second: await A.click("#ask-no") if await A.locator("#ask-no").count() else await A.keyboard.press("Escape")
        await A.wait_for_timeout(400)
        if await A.locator("#tabs button[data-tab=settings]").count():
            await A.click("#tabs button[data-tab=settings]"); await A.wait_for_timeout(700)
            has = await A.locator("#restore-db").count()
            ok("restore button (server version)" if has else "no restore button in single file", True)
        ok("no page errors", not errs, errs)
        await br.close()
asyncio.run(main())
print(json.dumps({"passed": sum(res), "total": len(res)}))

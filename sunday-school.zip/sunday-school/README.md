# ✠ Sunday School Manager (ሰንበት ትምህርት ቤት)

An offline web app for a Sunday school. It covers:

- **Student list (ስም ዝርዝር).** Add, edit, search, filter by class, import and export CSV (Amharic is supported), and print.
- **Attendance (ክትትል).** Teachers mark P / L / A / E from their phones. The reports show attendance % per student.
- **Programs (መርሐ ግብር).** One-time or weekly programs, each with a time, teacher, class and location.
- **Display screen (ማሳያ).** A full-screen page for a TV or projector. It shows a live clock with Gregorian and Ethiopian dates, the program running now and the next one with a countdown, and a scrolling announcement bar along the bottom.
- **Announcements, PIN login, and automatic daily backups.**

It needs **no internet**. One computer runs the server, and every other device opens it in a browser over the same Wi‑Fi router, switch or hotspot.

**Language:** the app opens in **Amharic (አማርኛ)**. Tap **EN / አማ** in the top bar to switch languages. The display screen follows the same choice and shows Ethiopian date and time (የኢትዮጵያ ሰዓት). To fix any translation, edit `public/i18n.js`.

**What's inside:**
- 👥 **Students:** the full name list, CSV import and export, and printing.
- 📘 **መሠረተ ትምህርት:** Grades 1–12. Each grade has its student list, tests and scores, and results with ranks (🥇🥈🥉, ties share a rank).
- 🔒 **Privacy & security:** only the **admin PIN** can view or edit data. Members get a **one-time code** (see below).
- ✅ Attendance, 📊 reports, 🗓 programs and 📢 announcements.
- 📅 **Calendar (ቀን መቁጠሪያ):** the Ethiopian Orthodox calendar for **any year**. It works out the movable feasts (ፋሲካ, ሆሣዕና, ስቅለት, ዕርገት, ጰራቅሊጦስ, ደብረ ዘይት, ርክበ ካህናት), the seven fasts (ነቢያት, ገሀድ, ነነዌ, ዐቢይ ጾም, ሐዋርያት, ፍልሰታ, plus Wednesday and Friday), the fixed feasts, the monthly commemorations and the Bahire Hasab numbers. It also shows a live countdown to the next major feast, today's fast with how many days are left, and your one-time programs. You can switch between the ዓ.ም and G.C. month views. Nothing is hard-coded per year, so it renews itself every Ethiopian New Year. Fasika is checked against the traditional Bahire Hasab (ነነዌ + 69 days) for 1900–2200.
- 📺 **TV display:** shows the program now and next, the feast countdown, today's fast and Ethiopian time.



| Version | Best for | Data |
|---|---|---|
| `single-file-version/SundaySchool.html` | One computer only. Double-click the file and it opens; no Python is needed. | Saved in that browser. Download a backup every week. |
| `server.py` (network version) | Many phones, tablets and TVs on one Wi‑Fi | Shared by all devices, in `C:\Users\<you>\SundaySchool-Data` (outside the app folder) |

---

## 🌐 Online version
To use it from anywhere (mobile data, any distance), use **sunday-school-online.zip** (Cloudflare). Move data with Settings → *Export all data (.json)* → *Import backup (.json)*.

## ⭐ Same data on every browser / በሁሉም ብሮውዘር አንድ አይነት መረጃ

**English**
1. On ONE computer (the "server"), double-click **`START-Windows.bat`** (first time: also double-click **`ALLOW-PHONES-Windows.bat`** and click **Yes**). Python must be installed once. Keep the black window open.
2. Connect every phone, tablet and TV to the **same Wi‑Fi**. The computer's own Mobile Hotspot works too, and no internet is needed.
3. On each device, open the address the black window shows, such as `http://192.168.1.20:8080`.
4. Done. An edit in any browser shows up in every other open browser within about 4 seconds, without reloading. A green dot next to EN means the device is connected live.
5. **Moving data from `SundaySchool.html`:** in that file go to Settings → *Download backup*. Then in the server version go to Settings → *Import backup (.json)*. Everything moves over: members, departments, grades, scores, programs and attendance. Students keep their passwords.

**አማርኛ**
1. በአንድ ኮምፒውተር (ሰርቨር) ላይ **`START-Windows.bat`**ን ሁለቴ ይጫኑ። Python አንድ ጊዜ መጫን አለበት። ጥቁሩን መስኮት አይዝጉት።
2. ስልኮች፣ ታብሌቶችና ቴሌቪዥን ሁሉ **በአንድ ዋይፋይ** ላይ ይሁኑ። የኮምፒውተሩ Mobile Hotspot ራሱም ይሠራል፤ ኢንተርኔት አያስፈልግም።
3. በእያንዳንዱ መሣሪያ ጥቁሩ መስኮት የሚያሳየውን አድራሻ ይክፈቱ (ለምሳሌ `http://192.168.1.20:8080`)።
4. በአንዱ ብሮውዘር የሚደረግ ለውጥ በሌሎቹ በሙሉ በ4 ሰከንድ ውስጥ ገጹን ሳያድሱ ይታያል። ከEN አጠገብ ያለው አረንጓዴ ነጥብ በቀጥታ መገናኘቱን ያሳያል።
5. **ከ`SundaySchool.html` መረጃ ለማዛወር፦** በዚያ ፋይል ቅንብሮች → *መጠባበቂያ አውርድ*፤ ከዚያ በሰርቨሩ ቅንብሮች → *መጠባበቂያ (.json) አስገባ*። አባላት፣ ክፍላት፣ ውጤቶች፣ መርሐ ግብርና ክትትል ሁሉ ይዛወራሉ፤ ተማሪዎች የይለፍ ቃላቸውን እንደያዙ ይቀጥላሉ።

## 🔒 Privacy, security & one-time codes / ግላዊነትና ደህንነት

**Who can do what**
| Who | How they get in | What they can do |
|---|---|---|
| **Admin** | Admin PIN | See and edit everything. The login lasts 12 hours and can be logged out from Settings. |
| **Member / student** | ID number + **one-time code** | See **only their own** results, rank and attendance, and mark **themselves** present **today** while self check-in is open. |
| **Anyone on the Wi‑Fi** | – | Only the TV display (programs, announcements, feasts). No names, scores or phone numbers. |

**One-time codes**
- **Making codes:** use 🔑 next to a member, or **🔑 One-time codes** in አባላት, in a department, or in a መሠረተ ትምህርት grade. You can then print the slips.
- **Each code works ONCE:** after a member logs in with it, the code is used up and the session ends after 20 minutes. Next time, they need a new code.
- **Expiry:** an unused code expires after 7 days. You can change this in Settings → Privacy & security. Making a new code cancels the old unused one.
- **Storage:** codes and the PIN are stored only in scrambled (hashed) form, so nobody can read them from the database. That's why slips can only be printed when the codes are made.

**Self check-in**
- In ክትትል (Attendance), click **Open 30 min / 1 hour / 3 hours**. A new 4-digit **room code** appears. Show it on the TV (use the TV link printed under the code, which has a secret `?key=`) or write it on the board.
- Members open `http://<server>:8080/#me` on their phones, enter their one-time code, type the **room code** and tap **✋ መጥቻለሁ**. Without the room code nobody can mark themselves present from home. The public `/display` page never shows the code.
- Members can only mark themselves present, and only for today. In the admin's list they appear with a 📱 mark, and the admin can still change any mark.

**Protection**
- **Wrong PINs:** 5 wrong tries lock that device for 5 minutes.
- **Wrong codes:** 5 wrong codes lock that ID for 15 minutes, and 20 wrong codes lock that device.
- **Browser protections:** the server tells browsers not to let other sites show the app in a frame or load outside content into it.
- **Downloads:** backups and exports are sent with the login hidden from the web address.
- **Single file:** `SundaySchool.html` cannot be truly private, because anyone using that computer's browser could read its stored data. Use the network version (`server.py`) when privacy matters.

## 1. Requirements

- One computer (Windows, Linux or Mac) with **Python 3.8+**. The app uses no extra packages and makes no `pip install`.
  - On Windows, if Python is missing, run the installer once (`python-3.x-amd64.exe`) and tick **“Add Python to PATH”**. You can bring the installer on a flash disk if you have no internet.
- A local network: a Wi‑Fi router, an Ethernet switch, or the computer's own **Mobile Hotspot** (Windows: Settings → Network → Mobile hotspot).

## 2. Start it

| System | How |
|---|---|
| Windows | Double‑click **`START-Windows.bat`** |
| Linux / Mac | `./start-linux-mac.sh`  (or `python3 server.py`) |
| Other port | `python server.py 9000` |

The window prints the addresses to use, for example:

```
On the network   : http://192.168.1.20:8080
TV / projector   : http://192.168.1.20:8080/display
```

Keep that window open while the school is running.

> **Windows Firewall:** the first time, Windows asks whether Python may use the network. Tick **Private networks** and click **Allow**. If phones still can't connect, open *Windows Defender Firewall → Allow an app* and tick Python for Private networks.

> **Tip:** in your router settings, give the server computer a fixed IP (a “DHCP reservation”), so the address never changes and you can bookmark it on every phone and TV.

## 3. First steps

1. Open `http://localhost:8080` on the server computer and log in with the default PIN **`1234`**. The app then **requires** you to set your own PIN (at least 6 characters, not 123456 / 111111 and the like) before anything can be changed.
2. Go to **Settings**. Set your Sunday school name and **change the PIN**.
3. Add students one by one, or **Import CSV** (see `students-template.csv`).
4. Add **Programs**. Use *Repeats → Every Sunday* for the weekly schedule.
5. On the TV, open `http://<server-ip>:8080/display` and click once to go full screen.

## 4. Daily use

- **Teachers:** open the address on a phone, log in, go to **Attendance**, pick the class, tap P/L/A/E, then **Save**.
- **Reports:** choose a date range and class to see each student's present / late / absent / excused counts and their %. Print the report or export it to CSV for Excel.
- **Display:** it refreshes every 30 seconds, so changes made on any phone show up automatically. The clock follows the server computer's time.
  - One screen per class: `/display?class=ጀማሪ ክፍል`. This shows that class's programs plus the programs for everyone.
  - Preview another day: `/display?date=2026-11-15`

## 5. Backups

- Data is kept in `C:\Users\<you>\SundaySchool-Data` (Linux/Mac: `~/SundaySchool-Data`), **not** in the app folder. Extracting a new copy or updating the app keeps the same members, PIN and school name. The window shows the exact folder at start.
- An automatic copy is saved once a day in `SundaySchool-Data\backups`, and the last 30 days are kept.
- **Settings → Download backup** saves a copy you can keep on a flash disk.
- **To restore:** stop the server, copy a backup over `SundaySchool-Data\sundayschool.db`, and start it again.
- **To move to a new computer:** copy the app folder and the `SundaySchool-Data` folder (or use Settings → Export all data / Import).

## 6. CSV import format

Save the file from Excel as **“CSV UTF‑8”**. The first row holds the headers, in any order:

`Full name, Christian name, Gender, Birth year, Class, Parent, Phone, Address, Notes, Grade`

Amharic headers also work: `ሙሉ ስም, የክርስትና ስም, ፆታ, ክፍል, ወላጅ, ስልክ, አድራሻ`.

## 7. Files

```
server.py              Python server + JSON API + SQLite database
public/index.html      Admin / teacher app
public/app.js          App logic
public/style.css       Styles (phone, desktop and print)
public/display.html    TV / projector display screen
public/ethiodate.js    Ethiopian date conversion
public/calendar.js     Ethiopian Orthodox feasts & fasts engine (Bahire Hasab)
public/i18n.js         Amharic / English text
(~/SundaySchool-Data)   Created on first run: database, config (PIN), backups
```

## 8. Security notes

- Anyone on the network can view the **display** and the program list. Student data, attendance and all editing need the PIN.
- Changing the PIN logs out every other device.
- The app is made for a trusted local network. Don't expose it to the internet as it is.

## 9. API (for future apps, such as the Android app)

| Method | Path | Auth |
|---|---|---|
| POST | `/api/login` `{pin}` → `{token}` | – |
| GET | `/api/display?class=&date=` | public |
| GET | `/api/programs?date=` | public |
| GET/POST/PUT/DELETE | `/api/students[/id]` | `X-Token` |
| GET/POST | `/api/attendance?date=&class=` | `X-Token` |
| GET | `/api/report?from=&to=&class=` | `X-Token` |
| POST/PUT/DELETE | `/api/programs[/id]` | `X-Token` |
| GET/POST/PUT/DELETE | `/api/announcements[/id]` | `X-Token` |
| GET | `/api/mt/grades`, `/api/mt/grade/<1-12>?term=` | `X-Token` |
| POST/PUT/DELETE | `/api/mt/tests[/id]`, POST `/api/mt/scores`, `/api/mt/password/<id>`, `/api/mt/passwords/<grade>` | `X-Token` |
| POST | `/api/codes` `{student_ids}` → one-time codes (shown once) | admin |
| GET/POST | `/api/checkin` `{minutes}` open/close self check-in | admin |
| POST | `/api/portal/login` `{id, code}` → member session (code is used up) | – |
| GET | `/api/portal/me?term=` · POST `/api/portal/checkin` · POST `/api/portal/logout` | `X-Member` |
| POST | `/api/logout`, `/api/sessions/revoke` | admin |
| GET | `/api/changes` → `{v}` change counter for live updates | – |
| POST | `/api/import/single` `{data}` (backup from SundaySchool.html) | `X-Token` |
| GET | `/api/export/students.csv`, `/api/export/attendance.csv`, `/api/backup` | `X-Token` |


## Long-term use: USB backups, updates and handover

- **USB backup:** while the app runs, a plugged-in flash drive gets a full copy once a week (`SundaySchool-Backup`, 12 newest kept). Settings → *Back up to USB now* does it at once. A yellow banner appears after 2 weeks without a copy.
- **Updates (optional):** Settings → Updates. Either *Check for updates* (needs internet only while downloading, and a `latest.json` address from the maintainer) or *Install update from file (.zip)*, which works fully offline. Before installing, the app copies your data and the current version. If the new version fails to start, `tools/run.py` puts the old one back by itself. Downloads must be `https` and match the SHA-256 in `latest.json`.
- **Python check:** `START-Windows.bat` needs Python 3.8+. It skips the fake Microsoft Store `python`, and it can use a portable Python in a `python` folder. If Python is missing, it offers to install it (winget).
- **Handover:** see **HANDOVER-GUIDE.txt** (Amharic/English): weekly routine, restore, updates, forgotten PIN, new computer and the yearly checklist.
- Maintainers publish updates with `python tools/make-release.py <zip https address>`.

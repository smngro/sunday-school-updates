/* ===== Language support: Amharic (አማርኛ) / English =====
   Default language is Amharic. Static text is translated automatically;
   dynamic text in app.js uses t('English text', {vars}).
   To fix or add a translation, edit the AM dictionary below. */
const I18N = (() => {
  const AM = {
    // top bar & tabs
    'Sunday School Manager': 'የሰንበት ትምህርት ቤት መቆጣጠሪያ',
    'Students': 'ተማሪዎች', 'Attendance': 'ክትትል', 'Reports': 'ሪፖርት', 'Programs': 'መርሐ ግብር',
    'Announcements': 'ማስታወቂያ', 'Settings': 'ቅንብሮች', 'Display': 'ማሳያ', 'Log out': 'ውጣ',
    // login
    'Log in': 'ግባ', 'Enter the teacher / admin PIN': 'የመምህር / የአስተዳዳሪ የሚስጥር ቁጥር ያስገቡ', 'PIN': 'የሚስጥር ቁጥር',
    'Open the program display screen →': 'የመርሐ ግብር ማሳያውን ክፈት →',
    'Wrong PIN': 'የተሳሳተ የሚስጥር ቁጥር', 'Login failed': 'መግባት አልተቻለም',
    'Cannot reach the server': 'ከሰርቨሩ ጋር መገናኘት አልተቻለም',
    'Cannot reach the server. Is it still running?': 'ከሰርቨሩ ጋር መገናኘት አልተቻለም። ሰርቨሩ እየሰራ ነው?',
    // students
    'Search name, parent, phone…': 'ስም፣ ወላጅ ወይም ስልክ ይፈልጉ…', 'All classes': 'ሁሉም ክፍሎች',
    'Show inactive': 'ንቁ ያልሆኑትንም አሳይ', 'Add student': 'ተማሪ ጨምር', 'Edit student': 'ተማሪ አስተካክል',
    'Import CSV': 'CSV አስገባ', 'Export CSV': 'CSV አውርድ', 'Print': 'አትም', 'Edit': 'አስተካክል',
    'Full name': 'ሙሉ ስም', 'Full name *': 'ሙሉ ስም *', 'Christian name': 'የክርስትና ስም', 'Class': 'ክፍል',
    'Gender': 'ፆታ', 'Age': 'ዕድሜ', 'Parent': 'ወላጅ', 'Phone': 'ስልክ', 'Male': 'ወንድ', 'Female': 'ሴት',
    'Class / group': 'ክፍል / ቡድን', 'Birth year (G.C.)': 'የትውልድ ዓመት (እ.ኤ.አ)', 'Parent / guardian': 'ወላጅ / አሳዳጊ',
    'Address': 'አድራሻ', 'Notes': 'ማስታወሻ', 'Active student': 'ንቁ ተማሪ',
    '{n} students': '{n} ተማሪዎች', '{n} student': '{n} ተማሪ', 'Student list': 'የተማሪዎች ስም ዝርዝር',
    'No students yet — click “+ Add student” or import a CSV.': 'እስካሁን ተማሪ የለም — “+ ተማሪ ጨምር”ን ይጫኑ ወይም CSV ያስገቡ።',
    'Delete this student and all their attendance records?\n(Tip: untick “Active” instead to keep history.)':
      'ይህ ተማሪ ከነሙሉ የክትትል መዝገቡ ይሰረዝ?\n(ምክር፦ መዝገቡን ለማቆየት “ንቁ ተማሪ” የሚለውን ምልክት ያንሱ።)',
    'Imported {n} student(s)': '{n} ተማሪ(ዎች) ገብተዋል', ', skipped {n} without a name': '፣ ስም የሌላቸው {n} ተዘልለዋል',
    // attendance
    'Mark rest present': 'ቀሪዎቹን “ተገኝቷል” አድርግ', 'Save attendance': 'ክትትሉን አስቀምጥ',
    'Present': 'ተገኝቷል', 'Late': 'ዘግይቷል', 'Absent': 'ቀርቷል', 'Excused': 'በፈቃድ',
    'Not marked': 'ያልተመዘገበ', 'Total': 'ጠቅላላ', 'No class': 'ክፍል ያልተመደበ',
    'No active students in this class.': 'በዚህ ክፍል ንቁ ተማሪ የለም።',
    'Tap P = Present, L = Late, A = Absent, E = Excused. Tap again to clear.':
      'ተ = ተገኝቷል፣ ዘ = ዘግይቷል፣ ቀ = ቀርቷል፣ ፈ = በፈቃድ። ለማጥፋት እንደገና ይንኩ።',
    'Attendance saved ✓': 'ክትትሉ ተቀምጧል ✓',
    // reports
    'From': 'ከ', 'To': 'እስከ', 'Show report': 'ሪፖርት አሳይ', 'Attendance CSV': 'የክትትል CSV',
    'Attendance report': 'የክትትል ሪፖርት', 'No data': 'መረጃ የለም',
    '{n} attendance day(s) recorded': '{n} የክትትል ቀን(ቀናት) ተመዝግቧል',
    // programs
    'Add program': 'መርሐ ግብር ጨምር', 'Edit program': 'መርሐ ግብር አስተካክል', 'Show past': 'ያለፉትንም አሳይ',
    'Preview day': 'የቀኑ እይታ', 'Weekly programs': 'ሳምንታዊ መርሐ ግብሮች', 'One-time programs': 'የአንድ ጊዜ መርሐ ግብሮች',
    'Schedule': 'የዕለቱ መርሐ ግብር', 'No weekly programs.': 'ሳምንታዊ መርሐ ግብር የለም።',
    'No upcoming one-time programs.': 'መጪ የአንድ ጊዜ መርሐ ግብር የለም።', 'Nothing scheduled.': 'ምንም የታቀደ የለም።',
    'Title *': 'ርዕስ *', 'Repeats': 'ድግግሞሽ', 'One time only': 'አንድ ጊዜ ብቻ', 'Date *': 'ቀን *',
    'Every Sunday': 'ሁልጊዜ እሑድ', 'Every Monday': 'ሁልጊዜ ሰኞ', 'Every Tuesday': 'ሁልጊዜ ማክሰኞ',
    'Every Wednesday': 'ሁልጊዜ ረቡዕ', 'Every Thursday': 'ሁልጊዜ ሐሙስ', 'Every Friday': 'ሁልጊዜ ዓርብ', 'Every Saturday': 'ሁልጊዜ ቅዳሜ',
    'Start time': 'መጀመሪያ ሰዓት', 'End time': 'መጨረሻ ሰዓት', 'Teacher / leader': 'መምህር / መሪ',
    'Class (empty = everyone)': 'ክፍል (ባዶ = ለሁሉም)', 'Location': 'ቦታ', 'Description': 'መግለጫ',
    'e.g. ትምህርተ ሃይማኖት / Bible lesson': 'ለምሳሌ፦ ትምህርተ ሃይማኖት', 'e.g. Hall 1': 'ለምሳሌ፦ አዳራሽ 1',
    'Delete this program?': 'ይህ መርሐ ግብር ይሰረዝ?',
    // announcements
    'New announcement (shown at the bottom of the display screen)…': 'አዲስ ማስታወቂያ (በማሳያው ግርጌ ይታያል)…',
    'Add': 'ጨምር', 'On screen': 'በማሳያ ላይ', 'No announcements.': 'ማስታወቂያ የለም።',
    'Delete this announcement?': 'ይህ ማስታወቂያ ይሰረዝ?',
    // settings
    'School': 'ትምህርት ቤት', 'Sunday school name': 'የሰንበት ትምህርት ቤቱ ስም', 'Change PIN': 'የሚስጥር ቁጥር ቀይር',
    'Current PIN': 'የአሁኑ የሚስጥር ቁጥር', 'New PIN (min 4)': 'አዲስ የሚስጥር ቁጥር (ቢያንስ 4)', 'Repeat new PIN': 'አዲሱን ይድገሙ',
    'Connect other devices': 'ሌሎች መሣሪያዎችን ያገናኙ', 'Backup': 'መጠባበቂያ', 'Download backup': 'መጠባበቂያ አውርድ',
    'Restore backup': 'መጠባበቂያ መልስ', 'CSV import format': 'የCSV ማስገቢያ ቅርጸት', 'Language': 'ቋንቋ',
    'Where is my data?': 'መረጃዬ የት ነው የሚቀመጠው?', 'TV / projector': 'ቴሌቪዥን / ፕሮጀክተር',
    'App:': 'መተግበሪያ፦', 'Display (TV):': 'ማሳያ (ቴሌቪዥን)፦', 'Members:': 'አባላት፦',
    'New PINs do not match': 'አዲሶቹ የሚስጥር ቁጥሮች አይመሳሰሉም',
    'PIN changed ✓ (other devices must log in again)': 'የሚስጥር ቁጥሩ ተቀይሯል ✓ (ሌሎች መሣሪያዎች እንደገና መግባት አለባቸው)',
    'Last backup downloaded:': 'መጠባበቂያ የወረደበት ቀን፦', 'today': 'ዛሬ', '{n} days ago': 'ከ{n} ቀን በፊት',
    'No backup downloaded yet.': 'እስካሁን መጠባበቂያ አልወረደም።',
    'Replace ALL current data in this browser with this backup?': 'በዚህ ብሮውዘር ያለው መረጃ በሙሉ በዚህ መጠባበቂያ ይተካ?',
    'Backup restored ✓ — log in with the PIN from that backup': 'መጠባበቂያው ተመልሷል ✓ — በዚያ መጠባበቂያ የሚስጥር ቁጥር ይግቡ',
    'That file is not a backup (.json)': 'ይህ ፋይል መጠባበቂያ (.json) አይደለም',
    'This is not a Sunday School backup file': 'ይህ የሰንበት ትምህርት ቤት መጠባበቂያ ፋይል አይደለም',

    // members (general list)
    'Members': 'አባላት', 'Add member': 'አባል ጨምር', 'Edit member': 'አባል አስተካክል', 'Active member': 'ንቁ አባል',
    '{n} members': '{n} አባላት', '{n} member': '{n} አባል', 'Member list': 'የአባላት ስም ዝርዝር',
    'No members yet — click “+ Add member” or import a CSV.': 'እስካሁን አባል የለም — “+ አባል ጨምር”ን ይጫኑ ወይም CSV ያስገቡ።',
    'Delete this member and all their records?\n(Tip: untick “Active member” instead to keep history.)':
      'ይህ አባል ከነሙሉ መዝገቡ ይሰረዝ?\n(ምክር፦ መዝገቡን ለማቆየት “ንቁ አባል” የሚለውን ምልክት ያንሱ።)',
    'No active members in this class.': 'በዚህ ክፍል ንቁ አባል የለም።', 'Imported {n} member(s)': '{n} አባል(ላት) ገብተዋል',
    // ክፍላት (departments)
    'Departments': 'ክፍላት', 'Add members': 'አባላት ጨምር', 'New member': 'አዲስ አባል', 'Edit department': 'ክፍሉን አስተካክል',
    'Add department': 'ክፍል ጨምር', 'Search in this department…': 'በዚህ ክፍል ውስጥ ይፈልጉ…', 'Department name *': 'የክፍሉ ስም *',
    'Leader': 'ኃላፊ', 'Active department': 'ንቁ ክፍል', 'Role': 'ኃላፊነት', 'Remove': 'አስወግድ', 'Remove from this department?': 'ከዚህ ክፍል ይወገድ?',
    'Delete this department? (Members are not deleted.)': 'ይህ ክፍል ይሰረዝ? (አባላቱ አይሰረዙም።)',
    'No members in this department yet. Click “+ Add members”.': 'በዚህ ክፍል እስካሁን አባል የለም። “+ አባላት ጨምር”ን ይጫኑ።',
    'Choose members to add': 'የሚጨመሩ አባላትን ይምረጡ', 'Add selected': 'የተመረጡትን ጨምር', 'Everyone is already in this department.': 'ሁሉም አባላት በዚህ ክፍል ውስጥ አሉ።',
    'Search members…': 'አባላትን ይፈልጉ…', '{n} added': '{n} ተጨምረዋል', 'Inactive': 'ንቁ ያልሆነ', 'Name is required': 'ስም ያስፈልጋል',
    'Removed': 'ተወግዷል', 'Select all': 'ሁሉንም ምረጥ', 'No match.': 'ምንም አልተገኘም።',
    // መሠረተ ትምህርት
    'Meserete Timhirt': 'መሠረተ ትምህርት', 'Calendar': 'ቀን መቁጠሪያ',
    'Tests & scores': 'ፈተናና ውጤት', 'Results & ranks': 'ውጤትና ደረጃ', 'Semester': 'ወሰነ ትምህርት', 'Whole year': 'ዓመታዊ ድምር', 'First semester': '1ኛ ወሰነ ትምህርት', 'Second semester': '2ኛ ወሰነ ትምህርት', 'Year total': 'የዓመቱ ድምር',
    'Create missing passwords': 'የሌላቸውን የይለፍ ቃል ፍጠር', 'Add test': 'ፈተና ጨምር', 'Edit test': 'ፈተና አስተካክል',
    'Save scores': 'ውጤቱን አስቀምጥ', 'ID number': 'መለያ ቁጥር', 'Password': 'የይለፍ ቃል', 'Set': 'ተሰጥቷል', 'Not set': 'አልተሰጠም',
    'No students in this grade yet. Click “+ Add student”, or open a student and choose their grade.':
      'በዚህ ክፍል እስካሁን ተማሪ የለም። “+ ተማሪ ጨምር”ን ይጫኑ ወይም ተማሪውን ከፍተው ክፍሉን ይምረጡ።',
    'No tests yet. Click “+ Add test” to create the first one.': 'እስካሁን ፈተና የለም። የመጀመሪያውን ለመፍጠር “+ ፈተና ጨምር”ን ይጫኑ።',
    'Click to edit': 'ለማስተካከል ይጫኑ', 'out of {n}': 'ከ{n}', 'No students in this grade yet.': 'በዚህ ክፍል እስካሁን ተማሪ የለም።',
    'Leave a box empty if the student did not take the test (it counts as 0 in the ranking).':
      'ተማሪው ፈተናውን ካልወሰደ ሳጥኑን ባዶ ይተዉት (በደረጃ አወጣጥ እንደ 0 ይቆጠራል)።',
    '{n} tests': '{n} ፈተናዎች', 'Rank': 'ደረጃ', 'Average': 'አማካይ', 'Tests taken': 'የተወሰዱ ፈተናዎች',
    'Some scores are higher than the maximum — please fix the red boxes': 'አንዳንድ ውጤቶች ከከፍተኛው ነጥብ በላይ ናቸው — ቀዩን ሳጥን ያስተካክሉ',
    'Scores saved ✓': 'ውጤቱ ተቀምጧል ✓', 'Delete this test and all its scores?': 'ይህ ፈተና ከነውጤቶቹ ይሰረዝ?',
    'Password removed': 'የይለፍ ቃሉ ተወግዷል', 'Every student in this grade already has a password': 'በዚህ ክፍል ያሉ ተማሪዎች ሁሉ የይለፍ ቃል አላቸው',
    'Subject': 'የትምህርት ዓይነት', 'Date': 'ቀን', 'Maximum score *': 'ከፍተኛ ነጥብ *',
    'e.g. ትምህርተ ሃይማኖት — 1ኛ ፈተና': 'ለምሳሌ፦ ትምህርተ ሃይማኖት — 1ኛ ፈተና', 'e.g. 1ኛ ወሰነ ትምህርት': 'ለምሳሌ፦ 1ኛ ወሰነ ትምህርት',
    'Student password': 'የተማሪ የይለፍ ቃል', 'New password (min 4)': 'አዲስ የይለፍ ቃል (ቢያንስ 4)', 'Remove password': 'የይለፍ ቃሉን አስወግድ',
    'New student passwords': 'አዲስ የተማሪ የይለፍ ቃላት',
    'Write these down or print them now — for safety they cannot be shown again. Cut the slips and give each student their own.':
      'እነዚህን አሁኑኑ ይጻፉ ወይም ያትሙ — ለደህንነት ሲባል ዳግመኛ አይታዩም። ወረቀቶቹን ቆርጠው ለእያንዳንዱ ተማሪ የራሱን ይስጡ።',
    'Close': 'ዝጋ', 'Print slips': 'ወረቀቶቹን አትም', 'Meserete Timhirt grade': 'የመሠረተ ትምህርት ክፍል',
    'Grade must be 1-12': 'ክፍል ከ1 እስከ 12 መሆን አለበት', 'Max score must be more than 0': 'ከፍተኛው ነጥብ ከ0 በላይ መሆን አለበት',
    'Password must be at least 4 characters': 'የይለፍ ቃል ቢያንስ 4 ፊደል/ቁጥር መሆን አለበት',
    // student portal
    'Student? See your result': 'ተማሪ ነዎት? ውጤትዎን ይመልከቱ', 'Meserete Timhirt — student result': 'መሠረተ ትምህርት — የተማሪ ውጤት',
    'See my result': 'ውጤቴን አሳይ', 'Back': 'ተመለስ', 'out of {n} students': 'ከ{n} ተማሪዎች', 'Test': 'ፈተና', 'Score': 'ውጤት',
    'No results have been published yet.': 'እስካሁን ውጤት አልተለቀቀም።', 'Wrong ID number or password': 'የተሳሳተ መለያ ቁጥር ወይም የይለፍ ቃል', 'Error': 'ስህተት',
    // calendar
    'Today': 'ዛሬ', 'Tomorrow': 'ነገ', 'in {n} days': '{n} ቀን ቀርቷል', 'Major feast': 'ዐቢይ በዓል', 'Fast': 'ጾም', 'Program': 'ፕሮግራም',
    'Feast': 'በዓል', 'Previous month': 'ያለፈው ወር', 'Next month': 'የሚቀጥለው ወር', "Feast / saint's day": 'በዓል / የቅዱሳን መታሰቢያ',
    'Fasting day': 'የጾም ቀን', 'Our program': 'የእኛ መርሐ ግብር', 'This month': 'በዚህ ወር', 'Coming up': 'መጪ በዓላትና አጽዋማት',
    'Nothing this month.': 'በዚህ ወር ምንም የለም።', 'Feasts and fasts of {y}': 'የ{y} በዓላትና አጽዋማት', 'Name': 'ስም', 'Type': 'ዓይነት',
    'Ethiopian date': 'በኢትዮጵያ አቆጣጠር', 'Gregorian date': 'በፈረንጆች አቆጣጠር', 'Day': 'ዕለት', 'When': 'መቼ', 'Now': 'አሁን', '{n} days': '{n} ቀናት',
    'Wednesday/Friday fast': 'የረቡዕና የዓርብ ጾም', 'Fasting today': 'የዛሬ ጾም', 'Day {d} of {n}': 'ከ{n} ቀናት {d}ኛው ቀን',
    '{n} days left': '{n} ቀን ቀርቷል', 'Last day': 'የመጨረሻ ቀን', 'Wednesday fast': 'የረቡዕ ጾም', 'Friday fast': 'የዓርብ ጾም',
    'Fast of salvation (ጾመ ድኅነት)': 'ጾመ ድኅነት', 'No fasting — the 50 days after Fasika (በዓለ ሃምሳ).': 'ጾም የለም — ከትንሣኤ በኋላ ያሉት 50 ቀናት (በዓለ ሃምሳ)።',
    'Today is not a fasting day.': 'ዛሬ የጾም ቀን አይደለም።', 'Next fast': 'ቀጣይ ጾም', 'Bahire Hasab': 'ባሕረ ሐሳብ', 'Year': 'ዘመን',
    'leap year (Pagume 6)': 'ጳጉሜን 6 ቀን', 'New Year falls on': 'ዘመን መለወጫ የሚውልበት', 'Fast of Nineveh': 'ጾመ ነነዌ',
    'Great Lent begins': 'ዐቢይ ጾም የሚገባበት', 'Fasika': 'ትንሣኤ (ፋሲካ)', 'Countdown to the next feast': 'ለቀጣዩ ዐቢይ በዓል የቀረው ጊዜ',
    'days': 'ቀናት', 'hours': 'ሰዓት', 'minutes': 'ደቂቃ', 'seconds': 'ሰከንድ', 'Then': 'ቀጥሎ', 'Monthly commemoration': 'ወርኃዊ በዓል',
    'Ethiopian time': 'የኢትዮጵያ ሰዓት', 'International time': 'ዓለም አቀፍ ሰዓት',
    // live updates & import
    'Updated from another device ↻': 'ከሌላ መሣሪያ ተዘምኗል ↻', 'Bring data from the single-file version': 'ከባለ አንድ ፋይል ስሪቱ መረጃ ማምጣት', 'Move data (single file ⇄ this computer ⇄ online)': 'መረጃ ማዛወር (ባለ አንድ ፋይል ⇄ ይህ ኮምፒውተር ⇄ ኦንላይን)', 'Export all data (.json)': 'ሁሉንም መረጃ አውጣ (.json)',
    'Import backup (.json)': 'መጠባበቂያ (.json) አስገባ', 'Live': 'በቀጥታ',
    'Replace ALL data on this server with the data from this file?\n(A safety copy of the current data is saved first.)':
      'በዚህ ሰርቨር ያለው መረጃ በሙሉ በዚህ ፋይል መረጃ ይተካ?\n(አሁን ያለው መረጃ መጀመሪያ በደህንነት ቅጂ ይቀመጣል።)',
    'Imported: {s} members, {p} programs, {t} tests': 'ገብቷል፦ {s} አባላት፣ {p} መርሐ ግብሮች፣ {t} ፈተናዎች',
    // privacy, one-time codes, self check-in
    'One-time codes': 'የአንድ ጊዜ ኮዶች', 'One-time code': 'የአንድ ጊዜ ኮድ', 'New code': 'አዲስ ኮድ', 'New one-time code': 'አዲስ የአንድ ጊዜ ኮድ',
    'One-time codes for this grade': 'ለዚህ ክፍል የአንድ ጊዜ ኮዶች', 'One-time codes for the members listed': 'ለተዘረዘሩት አባላት የአንድ ጊዜ ኮዶች',
    'Unused code, valid until': 'ያልተጠቀመ ኮድ፣ የሚያገለግለው እስከ', 'No members to create codes for': 'ኮድ የሚፈጠርላቸው አባላት የሉም',
    'Create a new one-time code for {name}?': 'ለ{name} አዲስ የአንድ ጊዜ ኮድ ይፈጠር?', 'Create new one-time codes for {n} members?': 'ለ{n} አባላት አዲስ የአንድ ጊዜ ኮድ ይፈጠር?',
    'Any older unused code for them stops working.': 'ከዚህ በፊት የተሰጣቸው ያልተጠቀሙበት ኮድ መሥራት ያቆማል።',
    'New one-time codes': 'አዲስ የአንድ ጊዜ ኮዶች',
    'Print or write these down now — for safety they cannot be shown again. Each code works ONCE. Cut the slips and give each member their own.':
      'እነዚህን አሁኑኑ ያትሙ ወይም ይጻፉ — ለደህንነት ሲባል ዳግመኛ አይታዩም። እያንዳንዱ ኮድ የሚሠራው አንድ ጊዜ ብቻ ነው። ወረቀቶቹን ቆርጠው ለእያንዳንዱ አባል የራሱን ይስጡ።',
    'Works only once · use before': 'አንድ ጊዜ ብቻ ይሠራል · የመጨረሻ ቀን',
    'Member? See your result / mark attendance': 'አባል ነዎት? ውጤትዎን ይመልከቱ / ክትትልዎን ይሙሉ',
    'Members — enter the one-time code you received from the admin': 'አባላት — ከአስተዳዳሪው የተቀበሉትን የአንድ ጊዜ ኮድ ያስገቡ',
    'Open': 'ክፈት', 'Each code works only once. You will see only your own information.': 'እያንዳንዱ ኮድ አንድ ጊዜ ብቻ ይሠራል። የሚያዩት የራስዎን መረጃ ብቻ ነው።',
    'Wrong ID number or code, or the code was already used': 'የተሳሳተ መለያ ቁጥር ወይም ኮድ፣ ወይም ኮዱ ቀደም ብሎ ተሠርቶበታል',
    'Your session has ended. Ask the admin for a new one-time code.': 'ጊዜዎ አብቅቷል። ከአስተዳዳሪው አዲስ የአንድ ጊዜ ኮድ ይጠይቁ።',
    'Your attendance today': 'የዛሬ ክትትልዎ', "I'm here — mark my attendance": 'መጥቻለሁ — ክትትሌን መዝግብ',
    'Check-in is open until': 'ክትትል ክፍት የሆነው እስከ', 'Self check-in is closed right now': 'የራስ ክትትል አሁን ዝግ ነው',
    'Last 3 months': 'ያለፉት 3 ወራት', 'This code worked once. You will be logged out automatically in {n} minutes.': 'ይህ ኮድ አንድ ጊዜ ሠርቷል። በ{n} ደቂቃ ውስጥ በራስ-ሰር ይወጣሉ።',
    'Self check-in': 'የራስ ክትትል', 'Self check-in is OPEN': 'የራስ ክትትል ክፍት ነው', 'Self check-in is closed': 'የራስ ክትትል ዝግ ነው', 'until': 'እስከ',
    "Members use their one-time code on their own phone and tap “I'm here”. They can only mark themselves present, today.":
      'አባላት በራሳቸው ስልክ የአንድ ጊዜ ኮዳቸውን አስገብተው “መጥቻለሁ”ን ይጫናሉ። ራሳቸውን ብቻ፣ ለዛሬ ብቻ “ተገኝቷል” ማለት ይችላሉ።',
    'Open 30 min': '30 ደቂቃ ክፈት', 'Open 1 hour': '1 ሰዓት ክፈት', 'Open 3 hours': '3 ሰዓት ክፈት', 'Close now': 'አሁን ዝጋ',
    'Privacy & security': 'ግላዊነትና ደህንነት', 'One-time codes must be used within (days)': 'የአንድ ጊዜ ኮድ የሚያገለግልበት ጊዜ (ቀናት)',
    'Log out all other admin devices': 'ሌሎች የአስተዳዳሪ መሣሪያዎችን በሙሉ አስወጣ',
    'Log out every other device that is logged in as admin?': 'በአስተዳዳሪነት የገቡ ሌሎች መሣሪያዎች በሙሉ ይውጡ?', 'Other devices were logged out': 'ሌሎች መሣሪያዎች ወጥተዋል',
    'Download failed': 'ማውረድ አልተቻለም', 'Days must be 1-365': 'ቀናት ከ1 እስከ 365 መሆን አለባቸው',
    'Too many wrong tries. Try again in 5 min.': 'በጣም ብዙ የተሳሳቱ ሙከራዎች። ከ5 ደቂቃ በኋላ እንደገና ይሞክሩ።',
    'Too many wrong tries. Try again in 15 min.': 'በጣም ብዙ የተሳሳቱ ሙከራዎች። ከ15 ደቂቃ በኋላ እንደገና ይሞክሩ።',
    // grades in attendance/report, department meetings
    'All grades (1–12)': 'ሁሉም ክፍሎች (1ኛ–12ኛ)', 'No grade': 'ክፍል ያልተመደቡ', '{p} of {n} present': '{p}/{n} ተገኝተዋል',
    'Meserete Timhirt grade': 'የመሠረተ ትምህርት ክፍል', 'Meeting attendance': 'የስብሰባ ክትትል', 'Meeting report': 'የስብሰባ ሪፖርት',
    'Meeting date': 'የስብሰባ ቀን', '{n} meetings recorded': '{n} ስብሰባዎች ተመዝግበዋል', 'Meeting dates': 'የስብሰባ ቀናት',
    'Birth date (E.C.) · የትውልድ ቀን (ዓ.ም)': 'የትውልድ ቀን (ዓ.ም)', '{m} {y} has only {n} days': '{m} {y} ያለው {n} ቀን ብቻ ነው',
    'Day': 'ዕለት', 'Month': 'ወር', 'Year (E.C.)': 'ዓመት (ዓ.ም)', 'Gregorian date': 'በፈረንጆች አቆጣጠር',
    // common
    'Save': 'አስቀምጥ', 'Cancel': 'ተው', 'Delete': 'ሰርዝ', 'OK': 'እሺ', 'Saved ✓': 'ተቀምጧል ✓', 'Deleted': 'ተሰርዟል',
    // server error messages
    'Full name is required': 'ሙሉ ስም ያስፈልጋል', 'Title is required': 'ርዕስ ያስፈልጋል', 'Text is required': 'ጽሑፍ ያስፈልጋል',
    'Date is required for a one-time program': 'ለአንድ ጊዜ መርሐ ግብር ቀን ያስፈልጋል',
    'Current PIN is wrong': 'የአሁኑ የሚስጥር ቁጥር ተሳስቷል', 'New PIN must be at least 4 characters': 'አዲሱ የሚስጥር ቁጥር ቢያንስ 4 መሆን አለበት',
    'Birth year must be a number': 'የትውልድ ዓመት ቁጥር መሆን አለበት', 'login required': 'እባክዎ ይግቡ',

    // ---- review additions
    'New PIN (min 6)': 'አዲስ የሚስጥር ቁጥር (ቢያንስ 6)', 'Save my PIN': 'የሚስጥር ቁጥሬን አስቀምጥ', 'Set your own admin PIN': 'የራስዎን የአስተዳዳሪ የሚስጥር ቁጥር ያስገቡ',
    'Change the default PIN 1234 first (Settings)': 'መጀመሪያ ነባሩን የሚስጥር ቁጥር 1234 ይቀይሩ (ቅንብሮች)',
    'New PIN must be at least 6 characters': 'አዲሱ የሚስጥር ቁጥር ቢያንስ 6 ቁምፊ መሆን አለበት',
    'Choose a less obvious PIN': 'በቀላሉ የማይገመት የሚስጥር ቁጥር ይምረጡ',
    'Wrong room code. Look at the screen or ask the teacher.': 'የክፍሉ ኮድ ተሳስቷል። ማያውን ይመልከቱ ወይም መምህሩን ይጠይቁ።',
    'Room code': 'የክፍል ኮድ', 'Room code (on the screen / board)': 'የክፍል ኮድ (በማያው / በሰሌዳው ላይ ያለው)',
    'Show it on the screen or write it on the board. Members need it to check in, so they must be in the room.': 'በማያው ላይ ያሳዩት ወይም በሰሌዳው ላይ ይጻፉት። አባላት ክትትላቸውን ለመሙላት ይህ ኮድ ያስፈልጋቸዋል፤ ስለዚህ በክፍሉ ውስጥ መገኘት አለባቸው።',
    'TV link that shows the code': 'ኮዱን የሚያሳይ የቴሌቪዥን አድራሻ',
    'Parent / member gave consent to store this information': 'ወላጅ / አባሉ ይህ መረጃ እንዲቀመጥ ፈቅደዋል',
    'No consent recorded': 'ፈቃድ አልተመዘገበም',
    ', {n} already in the list (not added again)': '፣ {n} ቀድሞ በዝርዝሩ ያሉ (እንደገና አልተጨመሩም)',
    'One of the nine major feasts': 'ከዘጠኙ ዐበይት በዓላት', 'Nine major feasts': 'ዘጠኙ ዐበይት በዓላት', 'Great holiday': 'ታላቅ በዓል',
    'PIN changed ✓ (other devices must log in again)': 'የሚስጥር ቁጥሩ ተቀይሯል ✓ (ሌሎች መሣሪያዎች እንደገና መግባት አለባቸው)',
    'Error': 'ስሕተት',
    'Also in': 'በተጨማሪ በ', 'change these in the Departments tab': 'እነዚህን በክፍላት ገጽ ይቀይሩ', 'Former member': 'የቀድሞ አባል',
    'School year': 'የትምህርት ዘመን', 'School year (E.C.)': 'የትምህርት ዘመን (ዓ.ም)',
    'New school year: move everyone up': 'አዲስ የትምህርት ዘመን፦ ሁሉንም ወደ ቀጣይ ክፍል አሳልፍ',
    'Do this once, at the start of a new school year (Meskerem)': 'ይህን በአዲስ የትምህርት ዘመን መጀመሪያ (መስከረም) አንድ ጊዜ ብቻ ያድርጉ',
    'New school year: every active student moves up one grade (1→2 … 11→12). Grade 12 students become graduates (no grade). Last year\'s tests and results stay saved under last year. A backup is made first. Do this ONCE, in Meskerem. Continue?': 'አዲስ የትምህርት ዘመን፦ እያንዳንዱ ንቁ ተማሪ ወደ ቀጣዩ ክፍል ያልፋል (1→2 … 11→12)። የ12ኛ ክፍል ተማሪዎች ተመራቂ ይሆናሉ (ክፍል የላቸውም)። ያለፈው ዓመት ፈተናዎችና ውጤቶች በያለፈው ዓመት ስር ተቀምጠው ይቆያሉ። አስቀድሞ መጠባበቂያ ይወሰዳል። ይህን በመስከረም አንድ ጊዜ ብቻ ያድርጉ። ይቀጥል?',
    '{n} students moved up, {g} graduated': '{n} ተማሪዎች ወደ ቀጣይ ክፍል አልፈዋል፣ {g} ተመርቀዋል',
    'Restore a backup': 'መጠባበቂያን መልስ', 'Restore from a backup file (.db)': 'ከመጠባበቂያ ፋይል (.db) መልስ',
    'Replace ALL current data with the backup "{f}"? A copy of the current data is saved first.': 'ያሁኑን መረጃ በሙሉ በመጠባበቂያው "{f}" ይተካ? አስቀድሞ የአሁኑ መረጃ ቅጂ ይቀመጣል።',
    'Restored ✓ ({n} members). Please log in again.': 'ተመልሷል ✓ ({n} አባላት)። እባክዎ እንደገና ይግቡ።',
    'This is not a Sunday School backup (.db) file': 'ይህ የሰንበት ት/ቤት መጠባበቂያ (.db) ፋይል አይደለም',
    'This backup is damaged or is not a Sunday School backup': 'ይህ መጠባበቂያ የተበላሸ ወይም የሰንበት ት/ቤት መጠባበቂያ አይደለም',
    'Export': 'ወደ ፋይል አውጣ', 'Choose the format:': 'የፋይሉን አይነት ይምረጡ፦', 'Cancel': 'ተው',
    'The list shown now (one table)': 'አሁን የሚታየው ዝርዝር (አንድ ሰንጠረዥ)',
    'Grouped by Meserete Timhirt grade (one table per grade)': 'በመሠረተ ትምህርት ክፍል ተከፋፍሎ (ለእያንዳንዱ ክፍል ሰንጠረዥ)',
    'This department': 'ይህ ክፍል (ዲፓርትመንት)', 'members and meeting report': 'አባላትና የስብሰባ ሪፖርት',
    'All departments (members, one table per department)': 'ሁሉም ክፍላት (አባላት፣ ለእያንዳንዱ ክፍል ሰንጠረዥ)',
    'Summary': 'ማጠቃለያ', 'All departments': 'ሁሉም ክፍላት', 'Choose a department first': 'መጀመሪያ ክፍል ይምረጡ',
    'This grade': 'ይህ ክፍል', 'results with every test score, and the student list': 'ውጤት ከእያንዳንዱ ፈተና ነጥብ ጋር፣ እና የተማሪዎች ዝርዝር',
    'All grades 1–12 (one table per grade, plus a summary)': 'ሁሉም ክፍሎች 1–12 (ለእያንዳንዱ ክፍል ሰንጠረዥ፣ ከማጠቃለያ ጋር)',
    'Shown now': 'አሁን የሚታየው', 'Yes': 'አዎ', 'Saved': 'ተቀምጧል',
    'Birth date (E.C.)': 'የትውልድ ቀን (ዓ.ም)', 'Grade': 'ክፍል', 'Consent': 'ፈቃድ', 'Active': 'ንቁ', 'Department': 'ክፍል (ዲፓርትመንት)',
    'Attendance %': 'የመገኘት %', 'Out of': 'ሙሉ ነጥብ', 'Average %': 'አማካይ %', 'Tests': 'ፈተናዎች', 'First rank': '1ኛ ደረጃ',
    'Status': 'ሁኔታ', 'Checked in by phone': 'በስልክ የገባ', 'Daily records (CSV)': 'የየቀኑ መዝገብ (CSV)',
    'Every attendance mark, one row per day': 'እያንዳንዱ የክትትል ምልክት፣ በቀን አንድ መስመር',
    'Backup to USB flash drive': 'በፍላሽ (USB) መጠባበቂያ', 'Back up to USB now': 'አሁን ወደ ፍላሽ ቅዳ',
    'Copy automatically every (days)': 'በራሱ የሚቀዳው በየ (ቀናት)',
    'Or always copy to this folder (optional, e.g. an external disk)': 'ወይም ሁልጊዜ ወደዚህ አቃፊ ቅዳ (አማራጭ፣ ለምሳሌ ውጫዊ ዲስክ)',
    'Never backed up to a USB flash drive yet.': 'እስካሁን ወደ ፍላሽ አልተቀዳም።', 'Last USB backup': 'የመጨረሻው የፍላሽ መጠባበቂያ',
    'USB / folder found': 'የተገኘ ፍላሽ / አቃፊ', 'No USB flash drive plugged in now.': 'አሁን ፍላሽ አልተሰካም።', 'Your data folder': 'የመረጃዎ አቃፊ',
    'No USB backup yet. Plug in a flash drive and click': 'እስካሁን ወደ ፍላሽ አልተቀዳም። ፍላሽ ይሰኩና ይጫኑ፦',
    'Backup copied to USB ✓': 'መጠባበቂያው ወደ ፍላሽ ተቀድቷል ✓',
    'No USB backup for more than two weeks. Plug in a flash drive and click': 'ከሁለት ሳምንት በላይ ወደ ፍላሽ አልተቀዳም። ፍላሽ ይሰኩና ይጫኑ፦',
    'Updates': 'ማሻሻያዎች', 'Check for updates': 'ማሻሻያ ፈልግ', 'Install update from file (.zip)': 'ማሻሻያን ከፋይል ጫን (.zip)',
    'Update address (from the person who maintains the app)': 'የማሻሻያ አድራሻ (መተግበሪያውን ከሚጠብቀው ሰው)',
    'This version': 'ይህ ስሪት', 'Checking…': 'በመፈለግ ላይ…', 'You have the newest version': 'የቅርብ ጊዜው ስሪት አለዎት',
    'New version': 'አዲስ ስሪት', 'Install now': 'አሁን ጫን',
    'Install version {v}? Your data is kept, and a copy of everything is saved first. The app restarts for a few seconds.': 'ስሪት {v} ይጫን? መረጃዎ አይነካም፤ አስቀድሞ የሁሉም ቅጂ ይቀመጣል። መተግበሪያው ለጥቂት ሰከንዶች እንደገና ይጀምራል።',
    'Install the update from "{f}"? Your data is kept, and a copy of everything is saved first.': 'ማሻሻያውን ከ"{f}" ይጫን? መረጃዎ አይነካም፤ አስቀድሞ የሁሉም ቅጂ ይቀመጣል።',
    'Installing and restarting… the page reloads by itself.': 'በመጫንና እንደገና በመጀመር ላይ… ገጹ በራሱ ይታደሳል።',
    'The last update did not start, so the previous version was put back': 'የመጨረሻው ማሻሻያ ስላልሠራ የቀድሞው ስሪት ተመልሷል',
    'No USB flash drive found. Plug one in (or choose a backup folder) and try again.': 'ፍላሽ አልተገኘም። ፍላሽ ይሰኩ (ወይም የመጠባበቂያ አቃፊ ይምረጡ) እና እንደገና ይሞክሩ።',
    'No update address is set yet (Settings → Updates)': 'የማሻሻያ አድራሻ ገና አልተሞላም (ቅንብሮች → ማሻሻያዎች)',
    'The update address must start with https://': 'የማሻሻያ አድራሻው በ https:// መጀመር አለበት',
    'That folder does not exist on this computer': 'ያ አቃፊ በዚህ ኮምፒውተር ላይ የለም',
    'This is not a Sunday School update (.zip) file': 'ይህ የሰንበት ት/ቤት ማሻሻያ (.zip) ፋይል አይደለም',
    'The downloaded update is damaged or not genuine (checksum differs). Nothing was changed.': 'የወረደው ማሻሻያ የተበላሸ ወይም ትክክለኛ ያልሆነ ነው። ምንም አልተቀየረም።',
    'main yearly feast': 'ዓመታዊ ክብረ በዓሉ', 'Main yearly feast': 'ዓመታዊ ክብረ በዓል',
    'Commemoration (every month)': 'ወርኃዊ መታሰቢያ', 'Today we commemorate': 'ዛሬ የሚታሰቡት', 'Saint of the day': 'የዕለቱ ቅዱስ',
    'Saints of every day of the month (ወርኃዊ በዓላት)': 'በየወሩ የሚታሰቡ ቅዱሳን (ወርኃዊ በዓላት)',
    'Each day of every month remembers these saints. The third column is the saint\'s main feast of the year. Lists differ a little between churches — check with your clergy.': 'በየወሩ በእያንዳንዱ ቀን እነዚህ ቅዱሳን ይታሰባሉ። ሦስተኛው ዓምድ የቅዱሱ ዓመታዊ ክብረ በዓል ነው። ዝርዝሩ ከቤተ ክርስቲያን ቤተ ክርስቲያን ትንሽ ሊለያይ ይችላል — ከካህናት ጋር ያረጋግጡ።',
  };

  // Rich text blocks (contain bold/links): element attribute data-html="key"
  const HTML = {
    'export-help': {
      en: '<b>Excel</b> and <b>Spreadsheet</b> files open in Excel, LibreOffice, WPS or Google Sheets. The <b>Word</b> file is a printable table. The file is saved in your <b>Downloads</b> folder. It contains personal data: keep it on this computer or a locked flash drive, and don\'t send it online.',
      am: '<b>Excel</b> እና <b>Spreadsheet</b> ፋይሎች በ Excel፣ LibreOffice፣ WPS ወይም Google Sheets ይከፈታሉ። <b>Word</b> ፋይሉ ለማተም የተዘጋጀ ሰንጠረዥ ነው። ፋይሉ በ<b>Downloads</b> አቃፊ ውስጥ ይቀመጣል። የግል መረጃ ስለያዘ በዚህ ኮምፒውተር ወይም በተቆለፈ ፍላሽ ብቻ ያስቀምጡት፤ በኦንላይን አይላኩት።' },
    'usb-help': {
      en: 'The first time, plug in the flash drive you will use for backups and click <b>Back up to USB now</b>. From then on, whenever <b>that</b> flash drive is plugged in, the app copies all data to it by itself once a week (folder <b>SundaySchool-Backup</b>, 12 newest copies). Other people\'s flash drives are never used. Keep the backup drive in a <b>locked place</b>: it holds children\'s personal data.',
      am: 'ለመጀመሪያ ጊዜ ለመጠባበቂያ የሚጠቀሙበትን ፍላሽ ይሰኩና <b>አሁን ወደ ፍላሽ ቅዳ</b> ይጫኑ። ከዚያ በኋላ <b>ያ</b> ፍላሽ በተሰካ ቁጥር መተግበሪያው በሳምንት አንድ ጊዜ በራሱ ሙሉ ቅጂ ይወስዳል (<b>SundaySchool-Backup</b> አቃፊ፣ የቅርብ 12 ቅጂዎች)። የሌሎች ሰዎች ፍላሽ በፍጹም አይነካም። ፍላሹ የሕፃናትን የግል መረጃ ስለያዘ <b>በተቆለፈ ቦታ</b> ያስቀምጡት።' },
    'restore-help': {
      en: 'If data was lost or damaged: choose a backup file (<b>sundayschool-….db</b>) from the flash drive folder <b>SundaySchool-Backup</b>, or from <b>SundaySchool-Data\\backups</b>. All current data is replaced by the backup; a copy of the current data is saved first. Your PIN does not change.',
      am: 'መረጃ ከጠፋ ወይም ከተበላሸ፦ ከፍላሹ <b>SundaySchool-Backup</b> አቃፊ ወይም ከ<b>SundaySchool-Data\\backups</b> የመጠባበቂያ ፋይል (<b>sundayschool-….db</b>) ይምረጡ። ያሁኑ መረጃ በሙሉ በመጠባበቂያው ይተካል፤ አስቀድሞ የአሁኑ መረጃ ቅጂ ይቀመጣል። የሚስጥር ቁጥርዎ አይቀየርም።' },
    'update-help': {
      en: 'Updates need internet only while downloading; the app keeps working offline as before. Before installing, the app saves a copy of your data and of the current version. If a new version does not start, the old one is put back by itself. Your members, results and PIN are never changed by an update.',
      am: 'ማሻሻያ ኢንተርኔት የሚያስፈልገው በሚወርድበት ጊዜ ብቻ ነው፤ መተግበሪያው እንደበፊቱ ያለ ኢንተርኔት ይሠራል። ከመጫኑ በፊት የመረጃዎና የአሁኑ ስሪት ቅጂ ይቀመጣል። አዲሱ ስሪት ካልሠራ የቀድሞው በራሱ ይመለሳል። አባላት፣ ውጤቶችና የሚስጥር ቁጥሩ በማሻሻያ አይቀየሩም።' },
    'security-help': {
      en: 'Only someone with the admin PIN can change anything. Members see <b>only their own</b> results, using a one-time code you print for them. A code works once and expires. Self check-in also needs the <b>room code</b> shown in class, so nobody can mark themselves present from home.',
      am: 'ማንኛውንም ነገር መለወጥ የሚችለው የአስተዳዳሪው የሚስጥር ቁጥር ያለው ብቻ ነው። አባላት <b>የራሳቸውን ውጤት ብቻ</b> የሚያዩት እርስዎ በሚያትሙላቸው የአንድ ጊዜ ኮድ ነው። ኮዱ አንድ ጊዜ ብቻ ይሠራል፣ ጊዜውም ያልፍበታል። የራስ ክትትል በክፍሉ የሚታየውን <b>የክፍል ኮድ</b> ይፈልጋል፤ ስለዚህ ማንም ከቤቱ ሆኖ “ተገኝቻለሁ” ማለት አይችልም።' },
    'privacy-law': {
      en: '⚖ Ethiopia’s Personal Data Protection Proclamation (No. 1321/2024) covers names, phone numbers, birth dates and children’s records. Collect only what you need, record the parent’s consent for children, keep backups in a locked place, and delete records you no longer need. The <b>online version stores data on servers outside Ethiopia</b>; ask a lawyer before putting children’s personal data there. This note is general information, not legal advice.',
      am: '⚖ የኢትዮጵያ የግል መረጃ ጥበቃ አዋጅ (ቁጥር 1321/2016) ስም፣ ስልክ ቁጥር፣ የትውልድ ቀንና የሕፃናትን መረጃ ይመለከታል። የሚያስፈልገውን ብቻ ይሰብስቡ፣ ለሕፃናት የወላጅ ፈቃድ ይመዝግቡ፣ መጠባበቂያዎችን በተቆለፈ ቦታ ያስቀምጡ፣ የማያስፈልጉ መረጃዎችን ይሰርዙ። <b>የኦንላይን ስሪቱ መረጃን ከኢትዮጵያ ውጭ ባሉ ሰርቨሮች ያስቀምጣል</b>፤ የሕፃናትን የግል መረጃ እዚያ ከማስቀመጥዎ በፊት የሕግ ባለሙያ ያማክሩ። ይህ ማስታወሻ አጠቃላይ መረጃ እንጂ የሕግ ምክር አይደለም።' },
    'force-pin-help': {
      en: 'You logged in with the factory PIN <b>1234</b>, which anyone can guess. Choose your own PIN (at least 6 characters) before making any changes, and write it down somewhere safe.',
      am: 'የገቡት ሁሉም ሊገምተው በሚችለው ነባር የሚስጥር ቁጥር <b>1234</b> ነው። ማንኛውንም ለውጥ ከማድረግዎ በፊት የራስዎን የሚስጥር ቁጥር (ቢያንስ 6 ቁምፊ) ይምረጡ፤ በጥንቃቄ ቦታም ይጻፉት።' },
    'pin-warning': {
      en: '⚠ You are using the default PIN <b>1234</b>. Change it in <a href="#" data-goto="settings">Settings</a>.',
      am: '⚠ ነባሩን የሚስጥር ቁጥር <b>1234</b> እየተጠቀሙ ነው። በ<a href="#" data-goto="settings">ቅንብሮች</a> ውስጥ ይቀይሩት።' },
    'connect-help': {
      en: 'Phones, tablets and TVs must be on the <b>same Wi‑Fi / router</b> as this computer. Type one of these addresses in their browser:',
      am: 'ስልኮች፣ ታብሌቶችና ቴሌቪዥኖች ከዚህ ኮምፒውተር ጋር <b>በአንድ ዋይፋይ / ራውተር</b> ላይ መሆን አለባቸው። ከእነዚህ አድራሻዎች አንዱን በብሮውዘራቸው ይጻፉ፦' },
    'backup-help': {
      en: 'A copy is saved automatically every day in the <code>data/backups</code> folder (last 30 days). You can also download one now and keep it on a flash disk.',
      am: 'በየቀኑ አንድ ቅጂ በራሱ በ<code>data/backups</code> አቃፊ ውስጥ ይቀመጣል (የመጨረሻዎቹ 30 ቀናት)። አሁንም አውርደው በፍላሽ ማስቀመጥ ይችላሉ።' },
    'csv-help': {
      en: 'First row = headers. Accepted: <code>Full name, Christian name, Gender, Birth year, Class, Parent, Phone, Address, Notes</code> (Amharic headers like <code>ሙሉ ስም, የክርስትና ስም, ክፍል, ስልክ</code> also work). Save from Excel as “CSV UTF‑8”.',
      am: 'የመጀመሪያው ረድፍ የዓምድ ርዕሶች ናቸው፦ <code>ሙሉ ስም, የክርስትና ስም, ፆታ, የትውልድ ዘመን, ክፍል, ወላጅ, ስልክ, አድራሻ, ማስታወሻ</code> (የእንግሊዝኛ ርዕሶችም ይሰራሉ)። ከExcel ሲያስቀምጡ “CSV UTF‑8” ይምረጡ።' },
    'local-data': {
      en: 'This is the <b>single-file version</b>. Everything is saved <b>inside this browser on this device</b> — no internet and no server needed. Clearing the browser\'s history/site data will erase it, so <b>download a backup every week</b> and keep it on a flash disk.',
      am: 'ይህ <b>ባለ አንድ ፋይል ስሪት</b> ነው። መረጃው በሙሉ <b>በዚህ መሣሪያ ብሮውዘር ውስጥ</b> ይቀመጣል — ኢንተርኔትም ሰርቨርም አያስፈልግም። የብሮውዘሩን ታሪክ/መረጃ ማጽዳት ያጠፋዋል፤ ስለዚህ <b>በየሳምንቱ መጠባበቂያ አውርደው</b> በፍላሽ ያስቀምጡ።' },
    'move-help': {
      en: 'To move to another computer: download a backup here, open this same HTML file there, and use “Restore backup”.',
      am: 'ወደ ሌላ ኮምፒውተር ለማዛወር፦ እዚህ መጠባበቂያ ያውርዱ፣ ይህንኑ HTML ፋይል እዚያ ይክፈቱ፣ ከዚያ “መጠባበቂያ መልስ” ይጫኑ።' },
    'tv-help': {
      en: 'Connect this computer to the TV (HDMI), click <b>📺 Display</b>, then click the screen for full screen. Press <b>Esc</b> to come back. For one class only, add <code>#display?class=NAME</code> to the address.',
      am: 'ኮምፒውተሩን ከቴሌቪዥኑ ጋር (በHDMI) ያገናኙ፣ <b>📺 ማሳያ</b>ን ይጫኑ፣ ከዚያ ሙሉ ገጽ ለማድረግ ማያውን ይንኩ። ለመመለስ <b>Esc</b> ይጫኑ። ለአንድ ክፍል ብቻ በአድራሻው መጨረሻ <code>#display?class=የክፍሉ ስም</code> ይጨምሩ።' },
    'bk-warning': {
      en: '💾 Single-file version: everything is saved <b>only in this browser</b> — another browser or phone starts empty. To share one set of data on every device, use the network version (<b>START-Windows.bat</b>). <a href="#" data-goto="settings">Download a backup</a> to move your data there.',
      am: '💾 ባለ አንድ ፋይል ስሪት፦ መረጃው የሚቀመጠው <b>በዚህ ብሮውዘር ብቻ</b> ነው — ሌላ ብሮውዘር ወይም ስልክ ባዶ ሆኖ ይጀምራል። በሁሉም መሣሪያ አንድ አይነት መረጃ እንዲኖር የኔትወርክ ስሪቱን (<b>START-Windows.bat</b>) ይጠቀሙ። መረጃዎን ወደዚያ ለማዛወር <a href="#" data-goto="settings">መጠባበቂያ ያውርዱ</a>።' },
    'connect-help-online': {
      en: '🌐 This is the <b>online version</b>. It works on any phone or computer with internet (Wi‑Fi or mobile data), anywhere. Share these addresses:',
      am: '🌐 ይህ <b>የኦንላይን ስሪት</b> ነው። ኢንተርኔት (ዋይፋይ ወይም የሞባይል ዳታ) ባለው በማንኛውም ስልክ ወይም ኮምፒውተር፣ በየትኛውም ቦታ ይሠራል። እነዚህን አድራሻዎች ያጋሩ፦' },
    'import-help': {
      en: 'Move everything between versions: <b>Export all data</b> here, then <b>Import backup</b> on the other one (single file → this server, this computer → online, or online → this computer). Members, departments, grades, scores, programs and attendance all move. After moving, create new one-time codes.',
      am: 'መረጃን በስሪቶች መካከል ለማዛወር፦ እዚህ <b>ሁሉንም መረጃ አውጣ</b>፤ ከዚያ በሌላኛው <b>መጠባበቂያ አስገባ</b> (ባለ አንድ ፋይል → ሰርቨር፣ ኮምፒውተር → ኦንላይን፣ ወይም ኦንላይን → ኮምፒውተር)። አባላት፣ ክፍላት፣ ውጤቶች፣ መርሐ ግብርና ክትትል ሁሉ ይዛወራሉ። ከተዛወረ በኋላ አዲስ የአንድ ጊዜ ኮዶች ይፍጠሩ።' },
    'mem-warning': {
      en: '⚠ This viewer blocks saving. <b>Open this file in Chrome</b> (or another browser) or your data will be lost when you close it.',
      am: '⚠ ይህ መመልከቻ መረጃ ማስቀመጥ አይፈቅድም። <b>ፋይሉን በChrome</b> (ወይም በሌላ ብሮውዘር) ይክፈቱ፤ አለበለዚያ ሲዘጉት መረጃው ይጠፋል።' },
  };

  const EN = {};
  Object.entries(AM).forEach(([k, v]) => (EN[v] = k));
  let lang = 'am';
  try { lang = localStorage.getItem('ss_lang') || 'am'; } catch (e) {}

  function t(s, vars) {
    let out = lang === 'am' && AM[s] !== undefined ? AM[s] : s;
    if (vars) Object.entries(vars).forEach(([k, v]) => (out = out.split('{' + k + '}').join(v)));
    return out;
  }

  // translate one string, keeping leading symbols (emoji, +, spaces) and trailing spaces
  function tr(str) {
    const m = /^([^\p{L}\p{N}“"]*)([\s\S]*?)(\s*)$/u.exec(str);
    if (!m || !m[2]) return str;
    const core = m[2];
    const hit = lang === 'am' ? AM[core] : EN[core];
    return hit !== undefined ? m[1] + hit + m[3] : str;
  }

  const SKIP = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE']);
  function walk(root) {
    if (root.nodeType === 3) { const v = tr(root.nodeValue); if (v !== root.nodeValue) root.nodeValue = v; return; }
    if (root.nodeType !== 1 || SKIP.has(root.tagName) || root.closest('[data-noi18n]')) return;
    if (root.dataset && root.dataset.html && HTML[root.dataset.html]) {
      const h = HTML[root.dataset.html][lang];
      if (root.innerHTML !== h) root.innerHTML = h;
      return;
    }
    ['placeholder', 'title'].forEach(a => {
      if (root.hasAttribute && root.hasAttribute(a)) { const v = tr(root.getAttribute(a)); if (v !== root.getAttribute(a)) root.setAttribute(a, v); }
    });
    root.childNodes.forEach(walk);
  }

  const listeners = [];
  function apply() {
    document.documentElement.lang = lang;
    walk(document.body);
    document.querySelectorAll('[data-lang-btn]').forEach(b => (b.textContent = lang === 'am' ? 'EN' : 'አማ'));
    if (document.title) document.title = tr(document.title);
  }
  function set(l) {
    lang = l;
    try { localStorage.setItem('ss_lang', l); } catch (e) {}
    apply();
    listeners.forEach(f => f(l));
  }

  // auto-translate anything the app adds later (tables, dialogs, toasts…)
  new MutationObserver(muts => {
    muts.forEach(m => {
      if (m.type === 'characterData') walk(m.target);
      else m.addedNodes.forEach(walk);
    });
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  document.addEventListener('click', e => {
    if (e.target.closest('[data-lang-btn]')) set(lang === 'am' ? 'en' : 'am');
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply); else apply();

  return { t, set, apply, get lang() { return lang; }, onChange: f => listeners.push(f), HTML };
})();
const t = I18N.t;

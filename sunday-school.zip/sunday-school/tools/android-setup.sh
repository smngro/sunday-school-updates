#!/data/data/com.termux/files/usr/bin/sh
# One-time setup on an Android phone (Termux). Run:  sh ~/sunday-school/tools/android-setup.sh
APP="$(cd "$(dirname "$0")/.." && pwd)"
echo ""
echo " Setting up Sunday School Manager in $APP ..."
pkg install -y python termux-api >/dev/null 2>&1 || pkg install -y python
python -c "import sqlite3, http.server" || { echo " Python did not install. Check internet and run again."; exit 1; }
chmod +x "$APP/start-android.sh"
# 1) a short command:  school
# ("ss" is also the name of another Termux program, so the command is called "school")
sed -i '/alias ss=/d' "$HOME/.bashrc" 2>/dev/null
grep -q "alias school=" "$HOME/.bashrc" 2>/dev/null || echo "alias school='sh \"$APP/start-android.sh\"'" >> "$HOME/.bashrc"
# 2) a home-screen button (needs the free Termux:Widget app)
mkdir -p "$HOME/.shortcuts"
printf '#!/data/data/com.termux/files/usr/bin/sh\nsh "%s/start-android.sh"\n' "$APP" > "$HOME/.shortcuts/SundaySchool"
chmod +x "$HOME/.shortcuts/SundaySchool"
[ -d "$HOME/storage/shared" ] || echo " TIP: run  termux-setup-storage  and tap Allow, so weekly backups go to the phone's storage."
echo ""
echo " ============================================================"
echo "  DONE. To start the app from now on:"
echo "    - CLOSE Termux, open it again, type   school   and press Enter, or"
echo "    - use the 'SundaySchool' button of the Termux:Widget app."
echo "  Then open  http://localhost:8080  on this phone."
echo " ============================================================"

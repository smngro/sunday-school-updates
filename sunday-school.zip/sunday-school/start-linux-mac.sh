#!/bin/sh
# Start the Sunday School server (restarts itself after an update)
cd "$(dirname "$0")"
exec python3 tools/run.py "$@"

/* =====================================================================
   Ethiopian Orthodox Tewahedo Church calendar engine (ባሕረ ሐሳብ)
   - Works for ANY Ethiopian year: everything is calculated, nothing is
     hard-coded per year, so it renews itself every Ethiopian New Year.
   - Movable feasts and fasts are counted from Fasika (Easter), which is
     calculated with the Alexandrian computus (Julian calendar).
   - Needs: ethiodate.js (for month/day names).
   ===================================================================== */
const EthioCal = (() => {
  const MONTHS_EN = ['Meskerem', 'Tikimt', 'Hidar', 'Tahsas', 'Tir', 'Yekatit', 'Megabit',
                     'Miyazya', 'Ginbot', 'Sene', 'Hamle', 'Nehase', 'Pagume'];
  const EVANGELISTS = { 1: ['ዘመነ ማቴዎስ', 'Year of Matthew'], 2: ['ዘመነ ማርቆስ', 'Year of Mark'],
                        3: ['ዘመነ ሉቃስ', 'Year of Luke'], 0: ['ዘመነ ዮሐንስ', 'Year of John'] };

  /* ---------- day-number (JDN) conversions ---------- */
  function gToJdn(y, m, d) {               // Gregorian -> JDN
    const a = Math.floor((14 - m) / 12), yy = y + 4800 - a, mm = m + 12 * a - 3;
    return d + Math.floor((153 * mm + 2) / 5) + 365 * yy + Math.floor(yy / 4) - Math.floor(yy / 100) + Math.floor(yy / 400) - 32045;
  }
  function julToJdn(y, m, d) {             // Julian -> JDN
    const a = Math.floor((14 - m) / 12), yy = y + 4800 - a, mm = m + 12 * a - 3;
    return d + Math.floor((153 * mm + 2) / 5) + 365 * yy + Math.floor(yy / 4) - 32083;
  }
  function jdnToG(j) {                     // JDN -> Gregorian {y,m,d}
    const a = j + 32044, b = Math.floor((4 * a + 3) / 146097), c = a - Math.floor(146097 * b / 4);
    const d = Math.floor((4 * c + 3) / 1461), e = c - Math.floor(1461 * d / 4), m = Math.floor((5 * e + 2) / 153);
    return { y: 100 * b + d - 4800 + Math.floor(m / 10), m: m + 3 - 12 * Math.floor(m / 10), d: e - Math.floor((153 * m + 2) / 5) + 1 };
  }
  function eToJdn(y, m, d) {               // Ethiopian -> JDN
    return 1723856 + 365 + 365 * (y - 1) + Math.floor(y / 4) + 30 * (m - 1) + d - 1;
  }
  function jdnToE(j) {                     // JDN -> Ethiopian {year,month,day}
    const off = j - 1723856, r = ((off % 1461) + 1461) % 1461;
    const n = (r % 365) + 365 * Math.floor(r / 1460);
    return { year: 4 * Math.floor(off / 1461) + Math.floor(r / 365) - Math.floor(r / 1460),
             month: Math.floor(n / 30) + 1, day: (n % 30) + 1 };
  }
  const dateToJdn = dt => gToJdn(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
  const jdnToDate = j => { const g = jdnToG(j); return new Date(g.y, g.m - 1, g.d); };
  const weekday = j => (j + 1) % 7;        // 0 = Sunday … 6 = Saturday (same as JS getDay)
  const monthLength = (y, m) => (m < 13 ? 30 : (y % 4 === 3 ? 6 : 5));
  const isLeap = y => y % 4 === 3;         // Pagume has 6 days at the end of a leap year

  /* ---------- Fasika (Easter) for Ethiopian year Y ---------- */
  function fasika(Y) {
    const G = Y + 8;                       // Fasika of E.C. year Y falls in Gregorian year Y+8
    const a = G % 4, b = G % 7, c = G % 19, d = (19 * c + 15) % 30, e = (2 * a + 4 * b - d + 34) % 7;
    const month = Math.floor((d + e + 114) / 31), day = ((d + e + 114) % 31) + 1;
    return julToJdn(G, month, day);
  }

  /* ---------- Bahire Hasab numbers (for information) ---------- */
  function bahire(Y) {
    const ameteAlem = 5500 + Y, medeb = ameteAlem % 19, wenber = medeb === 0 ? 18 : medeb - 1;
    const abekte = (wenber * 11) % 30, metqi = (wenber * 19) % 30;
    return { ameteAlem, medeb, wenber, abekte, metqi, evangelist: EVANGELISTS[ameteAlem % 4],
             newYearWeekday: weekday(eToJdn(Y, 1, 1)), leap: isLeap(Y) };
  }

  /* ---------- fixed feasts [month, day, Amharic, English, type] ----------
     type: 'major' = one of the nine major feasts of the Lord (ዘጠኙ ዐበይት በዓላት),
           'holiday' = great holiday that is not one of the nine (New Year, Meskel),
           'feast' = feast / saint's day */
  const FIXED = [
    [1, 1, 'ርእሰ ዓውደ ዓመት (ዕንቁጣጣሽ)', 'Ethiopian New Year (Enkutatash)', 'holiday'],
    [1, 16, 'ደመራ', 'Demera (eve of Meskel)', 'feast'],
    [1, 17, 'መስቀል', 'Meskel (Finding of the True Cross)', 'holiday'],
    [1, 21, 'ግሸን ማርያም', 'Gishen Mariam', 'feast'],
    [3, 12, 'ኅዳር ሚካኤል', 'St. Michael (Hidar)', 'feast'],
    [3, 21, 'ኅዳር ጽዮን', 'Hidar Tsion (Ark of the Covenant)', 'feast'],
    [4, 19, 'ታኅሣሥ ገብርኤል', 'St. Gabriel (Tahsas)', 'feast'],
    [4, 29, 'ልደት (ገና)', 'Genna (Christmas)', 'major'],          // 28 in the year after a leap year
    [5, 6, 'ግዝረት', 'Circumcision of Christ', 'feast'],
    [5, 10, 'ከተራ', 'Ketera (eve of Timket)', 'feast'],
    [5, 11, 'ጥምቀት', 'Timket (Epiphany)', 'major'],
    [5, 12, 'ቃና ዘገሊላ', 'Cana of Galilee', 'feast'],
    [5, 21, 'አስተርእዮ ማርያም', 'Asterio Mariam', 'feast'],
    [6, 16, 'ኪዳነ ምሕረት', 'Kidane Mihret', 'feast'],
    [7, 29, 'በዓለ ትስብእት (ብሥራት)', 'Annunciation (Tsinset)', 'major'],
    [8, 23, 'ቅዱስ ጊዮርጊስ', 'St. George', 'feast'],
    [9, 1, 'ልደታ ለማርያም', 'Nativity of St. Mary', 'feast'],
    [10, 12, 'ሰኔ ሚካኤል', 'St. Michael (Sene)', 'feast'],
    [11, 5, 'ጴጥሮስ ወጳውሎስ', 'Sts. Peter and Paul', 'feast'],
    [11, 19, 'ሐምሌ ገብርኤል', 'St. Gabriel (Hamle)', 'feast'],
    [12, 13, 'ደብረ ታቦር (ቡሄ)', 'Debre Tabor (Transfiguration)', 'major'],
    [12, 16, 'ፍልሰታ ለማርያም', 'Assumption of St. Mary (Filseta)', 'feast'],
    [12, 24, 'አቡነ ተክለ ሃይማኖት', 'Abune Tekle Haymanot', 'feast'],
    [13, 3, 'ቅዱስ ሩፋኤል', 'St. Raphael', 'feast'],
    // ---- main annual days of the saints of the month (ዓመታዊ ክብረ በዓል) ----
    [1, 2, 'ቅዱስ ዮሐንስ መጥምቀ መለኮት', 'St. John the Baptist', 'feast'],
    [1, 18, 'አቡነ ኤዎስጣቴዎስ', 'Abune Ewostatewos', 'feast'],
    [1, 29, 'ቅድስት አርሴማ', 'St. Arsema', 'feast'],
    [2, 5, 'አቡነ ገብረ መንፈስ ቅዱስ', 'Abune Gebre Menfes Kidus', 'feast'],
    [2, 14, 'አቡነ አረጋዊ', 'Abune Aregawi', 'feast'],
    [2, 27, 'መድኃኔ ዓለም', 'Medhane Alem', 'feast'],
    [3, 6, 'ቁስቋም ማርያም', 'Kusquam Mariam', 'feast'],
    [3, 25, 'ቅዱስ መርቆሬዎስ', 'St. Mercurius', 'feast'],
    [4, 3, 'በዓታ ለማርያም', 'Ba\'eta Mariam', 'feast'],
    [4, 24, 'ልደተ አቡነ ተክለ ሃይማኖት', 'Birth of Abune Tekle Haymanot', 'feast'],
    [5, 4, 'ቅዱስ ዮሐንስ ወንጌላዊ', 'St. John the Evangelist', 'feast'],
    [5, 15, 'ቅዱስ ቂርቆስ ወቅድስት ኢየሉጣ', 'Sts. Kirkos and Iyeluta', 'feast'],
    [7, 5, 'ዕረፍተ አቡነ ገብረ መንፈስ ቅዱስ', 'Abune Gebre Menfes Kidus (repose)', 'feast'],
    [7, 27, 'መድኃኔ ዓለም', 'Medhane Alem', 'feast'],
    [8, 30, 'ቅዱስ ማርቆስ ወንጌላዊ', 'St. Mark the Evangelist', 'feast'],
    [9, 11, 'ቅዱስ ያሬድ', 'St. Yared', 'feast'],
    [9, 26, 'ቅዱስ ቶማስ ሐዋርያ', 'St. Thomas the Apostle', 'feast'],
    [10, 17, 'አባ ገሪማ', 'Abba Gerima', 'feast'],
    [10, 20, 'ሕንጸታ ለማርያም', 'Hintseta Mariam', 'feast'],
    [11, 7, 'ሥላሴ (ቤተ አብርሃም)', 'Holy Trinity (House of Abraham)', 'feast'],
    [11, 8, 'አባ ኪሮስ', 'Abba Kiros', 'feast'],
    [11, 22, 'ቅዱስ ዑራኤል', 'St. Uriel', 'feast'],
  ];

  /* ---------- movable feasts, days from Fasika ---------- */
  const MOVABLE = [
    [-28, 'ደብረ ዘይት', 'Debre Zeit (mid-Lent)', 'feast'],
    [-7, 'ሆሣዕና', 'Hosanna (Palm Sunday)', 'major'],
    [-2, 'ስቅለት', 'Siklet (Good Friday)', 'major'],
    [0, 'ትንሣኤ (ፋሲካ)', 'Fasika (Easter)', 'major'],
    [24, 'ርክበ ካህናት', 'Rikbe Kahnat', 'feast'],
    [39, 'ዕርገት', 'Erget (Ascension)', 'major'],
    [49, 'ጰራቅሊጦስ', 'Paraclete (Pentecost)', 'major'],
  ];

  /* ---------- monthly commemorations (ወርኃዊ በዓላት) ---------- */
  // Every day of the month has its commemoration. Common EOTC list; local churches may add others — verify with your clergy.
  const MONTHLY = {
    1: ['ልደታ ለማርያም፣ ቅዱስ ራጉኤል', 'Lideta (Nativity of St. Mary), St. Raguel'],
    2: ['ቅዱስ ታዴዎስ ሐዋርያ', 'St. Thaddeus the Apostle'],
    3: ['በዓታ ለማርያም', 'Ba\'eta Mariam (Presentation of St. Mary)'],
    4: ['ቅዱስ ዮሐንስ ወልደ ነጎድጓድ', 'St. John the Evangelist'],
    5: ['አቡነ ገብረ መንፈስ ቅዱስ፣ ጴጥሮስ ወጳውሎስ', 'Abune Gebre Menfes Kidus, Sts. Peter and Paul'],
    6: ['ቁስቋም ማርያም፣ ቅድስት አርሴማ', 'Kusquam Mariam, St. Arsema'],
    7: ['ቅድስት ሥላሴ', 'Holy Trinity'],
    8: ['አባ ኪሮስ፣ አባ ባኑዳ', 'Abba Kiros, Abba Banuda'],
    9: ['ቅዱስ ቶማስ ሐዋርያ', 'St. Thomas the Apostle'],
    10: ['በዓለ መስቀል', 'The Holy Cross'],
    11: ['ሐና ወኢያቄም', 'Sts. Anna and Joachim (parents of St. Mary)'],
    12: ['ቅዱስ ሚካኤል', 'St. Michael the Archangel'],
    13: ['ቅዱስ ሩፋኤል', 'St. Raphael the Archangel'],
    14: ['አቡነ አረጋዊ፣ አባ ገብረ ክርስቶስ', 'Abune Aregawi, Abba Gebre Kristos'],
    15: ['ቅዱስ ቂርቆስ ወቅድስት ኢየሉጣ', 'Sts. Kirkos and Iyeluta'],
    16: ['ኪዳነ ምሕረት', 'Kidane Mihret (Covenant of Mercy)'],
    17: ['ቅዱስ እስጢፋኖስ፣ አባ ገሪማ', 'St. Stephen, Abba Gerima'],
    18: ['አቡነ ኤዎስጣቴዎስ', 'Abune Ewostatewos'],
    19: ['ቅዱስ ገብርኤል', 'St. Gabriel the Archangel'],
    20: ['ሕንጸታ ለማርያም፣ ቅዱስ ዳዊት', 'Hintseta (first church of St. Mary), King David'],
    21: ['እመቤታችን ቅድስት ድንግል ማርያም', 'St. Mary, Mother of God'],
    22: ['ቅዱስ ዑራኤል', 'St. Uriel the Archangel'],
    23: ['ቅዱስ ጊዮርጊስ', 'St. George'],
    24: ['አቡነ ተክለ ሃይማኖት፣ ሃያ አራቱ ካህናተ ሰማይ', 'Abune Tekle Haymanot, the 24 Heavenly Priests'],
    25: ['ቅዱስ መርቆሬዎስ', 'St. Mercurius'],
    26: ['አቡነ ሀብተ ማርያም፣ ቅዱስ ዮሴፍ', 'Abune Habte Mariam, St. Joseph'],
    27: ['መድኃኔ ዓለም', 'Medhane Alem (Saviour of the World)'],
    28: ['አማኑኤል', 'Emmanuel'],
    29: ['በዓለ ወልድ', 'Bale Wold (Feast of the Son)'],
    30: ['ቅዱስ ማርቆስ ወንጌላዊ፣ አቡነ ዜና ማርቆስ', 'St. Mark the Evangelist, Abune Zena Markos'],
  };

  // where each monthly commemoration has its main yearly feast: day of month -> [[month, day], ...]
  const ANNUAL_OF = {
    1: [[9, 1]], 3: [[4, 3]], 4: [[5, 4]], 5: [[2, 5], [7, 5], [11, 5]], 6: [[3, 6], [1, 29]], 7: [[11, 7]], 8: [[11, 8]],
    9: [[9, 26]], 10: [[1, 17]], 12: [[3, 12], [10, 12]], 13: [[13, 3]], 14: [[2, 14]], 15: [[5, 15]], 16: [[6, 16]],
    17: [[10, 17]], 18: [[1, 18]], 19: [[4, 19], [11, 19]], 20: [[10, 20]], 21: [[5, 21], [3, 21], [12, 16]], 22: [[11, 22]],
    23: [[8, 23]], 24: [[12, 24], [4, 24]], 25: [[3, 25]], 27: [[2, 27], [7, 27]], 29: [[4, 29], [7, 29]], 30: [[8, 30]],
  };

  const cache = {};
  function year(Y) {
    if (cache[Y]) return cache[Y];
    const E = fasika(Y), genna = eToJdn(Y, 4, Y % 4 === 0 ? 28 : 29), timket = eToJdn(Y, 5, 11), list = [];
    const add = (start, end, am, en, type) => list.push({ start, end, am, en, type });
    FIXED.forEach(([m, d, am, en, type]) => {
      const j = (m === 4 && d === 29) ? genna : eToJdn(Y, m, d);
      add(j, j, am, en, type);
    });
    MOVABLE.forEach(([off, am, en, type]) => add(E + off, E + off, am, en, type));
    // the seven fasts (ሰባቱ አጽዋማት) — Wednesday & Friday fasts are handled in dayInfo()
    add(eToJdn(Y, 3, 15), genna - 1, 'ጾመ ነቢያት (የገና ጾም)', 'Fast of the Prophets (Advent)', 'fast');
    add(eToJdn(Y, 5, 10), eToJdn(Y, 5, 10), 'ጾመ ገሀድ', 'Gahad fast (eve of Timket)', 'fast');
    add(E - 69, E - 67, 'ጾመ ነነዌ', 'Fast of Nineveh', 'fast');
    add(E - 55, E - 1, 'ዐቢይ ጾም (ሁዳዴ)', 'Great Lent (Hudade)', 'fast');
    add(E + 50, eToJdn(Y, 11, 4), 'ጾመ ሐዋርያት', 'Fast of the Apostles', 'fast');
    add(eToJdn(Y, 12, 1), eToJdn(Y, 12, 15), 'ጾመ ፍልሰታ', 'Fast of the Assumption (Filseta)', 'fast');
    list.sort((a, b) => a.start - b.start || (a.type === 'fast') - (b.type === 'fast'));
    return (cache[Y] = { Y, E, genna, timket, events: list, ...bahire(Y) });
  }

  function dayInfo(j) {
    const e = jdnToE(j), info = year(e.year), wd = weekday(j);
    const here = info.events.filter(x => x.start <= j && j <= x.end);
    const inFifty = j > info.E && j <= info.E + 49;               // 50 days after Fasika: no fasting
    const exempt = j === info.genna || j === info.timket;         // Genna / Timket on Wed/Fri: no fasting
    const weekly = (wd === 3 || wd === 5) && !inFifty && !exempt;
    const fasts = here.filter(x => x.type === 'fast');
    return { j, e, g: jdnToG(j), wd, feasts: here.filter(x => x.type !== 'fast'), fasts,
             weekly, fasting: fasts.length > 0 || weekly, inFifty, monthly: MONTHLY[e.day] || null };
  }

  /* upcoming events from day j (default: today) */
  function upcoming(j, { types = ['major', 'holiday', 'feast', 'fast'], limit = 10 } = {}) {
    const Y = jdnToE(j).year, out = [];
    [Y, Y + 1].forEach(y => year(y).events.forEach(ev => {
      if (ev.start >= j && types.includes(ev.type)) out.push(ev);
    }));
    return out.sort((a, b) => a.start - b.start).slice(0, limit);
  }

  /* fasting seasons running on day j */
  function currentFasts(j) {
    return dayInfo(j).fasts.map(f => ({ ...f, day: j - f.start + 1, total: f.end - f.start + 1, left: f.end - j }));
  }

  const name = (x, lang) => (lang === 'en' ? x.en : x.am);
  const monthName = (m, lang) => (lang === 'en' ? MONTHS_EN[m - 1] : EthioDate.MONTHS[m - 1]);
  const fmtE = (j, lang) => { const e = jdnToE(j); return `${monthName(e.month, lang)} ${e.day}, ${e.year}`; };

  return { gToJdn, julToJdn, jdnToG, eToJdn, jdnToE, dateToJdn, jdnToDate, weekday, monthLength, isLeap,
           fasika, bahire, year, dayInfo, upcoming, currentFasts, name, monthName, fmtE, MONTHLY, ANNUAL_OF, MONTHS_EN };
})();
if (typeof module !== 'undefined') module.exports = EthioCal;

#!/data/data/com.termux/files/usr/bin/sh
# Start the Sunday School server on an Android phone (Termux). Restarts itself after an update.
cd "$(dirname "$0")"
command -v termux-wake-lock >/dev/null && termux-wake-lock          # keep running when the screen is off
# weekly backup copy goes to the phone's own storage (survives if Termux is removed)
if [ -d "$HOME/storage/shared" ]; then
  export SS_BACKUP_FOLDER="$HOME/storage/shared"          # the app adds the SundaySchool-Backup folder itself
fi
( sleep 4; command -v termux-open-url >/dev/null && termux-open-url "http://localhost:8080" ) &
exec python tools/run.py --no-browser "$@"

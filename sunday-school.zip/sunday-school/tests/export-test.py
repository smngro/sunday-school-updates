import asyncio, sys, os, json, urllib.request, warnings
from playwright.async_api import async_playwright
URL = sys.argv[1]; SF = URL.startswith("file:")
OUT = "/tmp/exports"; os.makedirs(OUT, exist_ok=True)
res = []

def check(path):
    ext = path.rsplit(".", 1)[1]
    if ext == "xlsx":
        import openpyxl
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            wb = openpyxl.load_workbook(path)
        return f"{len(wb.sheetnames)} sheets: {wb.sheetnames[:4]} rows={wb[wb.sheetnames[-1]].max_row}"
    if ext == "docx":
        import docx
        d = docx.Document(path); return f"{len(d.tables)} tables, first row: {[c.text for c in d.tables[0].rows[0].cells][:4]}"
    if ext == "ods":
        from odf.opendocument import load
        from odf.table import Table
        o = load(path); return f"{len(o.spreadsheet.getElementsByType(Table))} tables"
    return open(path, encoding="utf-8-sig").read().splitlines()[0][:60]

async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch(executable_path="/usr/bin/google-chrome"); errs = []
        A = await (await br.new_context(viewport={"width": 1366, "height": 900}, accept_downloads=True)).new_page()
        A.on("pageerror", lambda e: errs.append(str(e)))
        await A.goto(URL); await A.evaluate("localStorage.clear()"); await A.reload(); await A.wait_for_timeout(600)
        await A.fill("#login-pin", "1234"); await A.keyboard.press("Enter"); await A.wait_for_timeout(800)
        await A.fill("#fp-new", "246813"); await A.fill("#fp-new2", "246813"); await A.click("#force-pin-form button.primary"); await A.wait_for_timeout(600)
        # data through the app's own API (works for server and single file)
        await A.evaluate("""async () => {
          const call = (p, m, b) => api(p, { method: m, body: b });
          const ids = [];
          for (const [g, names] of [[2, ['ሰላም ገብሩ', 'ቃልኪዳን አበራ']], [4, ['ቤዛ ተስፋዬ', 'ናትናኤል ደምሴ', 'ሊዲያ ግርማ']]])
            for (const n of names) ids.push([(await call('students', 'POST', { full_name: n, grade: g, gender: 'Female', phone: '0911000000', consent: 1 })).id, g]);
          for (const g of [2, 4]) {
            const t1 = await call('mt/tests', 'POST', { grade: g, title: 'ትምህርተ ሃይማኖት', max_score: 50, term: SEM1 });
            const t2 = await call('mt/tests', 'POST', { grade: g, title: 'መጽሐፍ ቅዱስ', max_score: 50, term: SEM1 });
            const sc = []; ids.filter(x => x[1] === g).forEach(([id], i) => { sc.push({ test_id: t1.id, student_id: id, score: 40 + i }); sc.push({ test_id: t2.id, student_id: id, score: 30 + i }); });
            await call('mt/scores', 'POST', { scores: sc });
          }
          const all = await api('attendance?date=' + today() + '&grade=');
          await call('attendance', 'POST', { date: today(), records: all.map((s, i) => ({ student_id: s.id, status: ['P', 'L', 'A', 'E', 'P'][i % 5] })) });
          const deps = await api('depts');
          await call(`depts/${deps[0].id}/members`, 'POST', { student_ids: ids.slice(0, 3).map(x => x[0]) });
          await call(`depts/${deps[0].id}/attendance`, 'POST', { date: today(), records: ids.slice(0, 3).map(x => ({ student_id: x[0], status: 'P' })) });
        }""")
        jobs = [("students", "#st-export", None), ("depts", "#dp-export", None), ("mt", "#mt-export", "#mt-grades button[data-grade='4']"),
                ("attendance", "#at-export", None), ("reports", "#rp-xport", None)]
        for tab, btn, pre in jobs:
            await A.click(f"#tabs button[data-tab={tab}]"); await A.wait_for_timeout(900)
            if pre: await A.click(pre); await A.wait_for_timeout(600)
            for scope_i in range(2):
                for fmt in ["xlsx", "docx", "ods", "csv"]:
                    await A.click(btn); await A.wait_for_timeout(300)
                    await A.locator("#exp-scope input").nth(scope_i).check()
                    async with A.expect_download(timeout=20000) as d:
                        await A.click(f"#exp-dlg [data-fmt={fmt}]")
                    dl = await d.value
                    path = os.path.join(OUT, f"{tab}-{scope_i}-{dl.suggested_filename}")
                    await dl.save_as(path)
                    try: info = check(path); ok = True
                    except Exception as e: info = repr(e); ok = False
                    res.append(ok); print(("PASS " if ok else "FAIL ") + f"{tab} scope{scope_i} {fmt}: {dl.suggested_filename} -> {info}")
                    await A.wait_for_timeout(200)
        await A.click("#tabs button[data-tab=mt]"); await A.wait_for_timeout(500)
        await A.click("#mt-export"); await A.wait_for_timeout(300); await A.screenshot(path="/tmp/exp-dlg.png")
        print("page errors:", errs); await br.close()
asyncio.run(main())
print(json.dumps({"passed": sum(res), "total": len(res)}))

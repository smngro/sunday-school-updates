import asyncio, re, sys, json
from playwright.async_api import async_playwright
URL = sys.argv[1]; TAG = sys.argv[2]; SF = TAG == "sf"
NEWPIN = "246813"
res = {}
def ok(name, cond, info=""):
    res[name] = bool(cond); print(("PASS " if cond else "FAIL ") + name, info)

async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch(executable_path="/usr/bin/google-chrome"); errs = []
        ctxA = await br.new_context(viewport={"width": 1366, "height": 900}, accept_downloads=True)
        A = await ctxA.new_page(); A.on("pageerror", lambda e: errs.append("A " + str(e)))
        await A.goto(URL); await A.evaluate("localStorage.clear()"); await A.reload(); await A.wait_for_timeout(500)
        await A.fill("#login-pin", "1234"); await A.keyboard.press("Enter"); await A.wait_for_timeout(900)
        ok("forced PIN dialog opens after default login", await A.is_visible("#force-pin-dlg"))
        await A.keyboard.press("Escape"); await A.wait_for_timeout(200)
        ok("forced PIN dialog can't be skipped with Esc", await A.is_visible("#force-pin-dlg"))
        await A.fill("#fp-new", "123456"); await A.fill("#fp-new2", "123456"); await A.click("#force-pin-form button.primary"); await A.wait_for_timeout(500)
        ok("obvious PIN 123456 refused", "obvious" in (await A.text_content("#fp-err")) or "የማይገመት" in (await A.text_content("#fp-err")), await A.text_content("#fp-err"))
        await A.fill("#fp-new", NEWPIN); await A.fill("#fp-new2", NEWPIN); await A.click("#force-pin-form button.primary"); await A.wait_for_timeout(700)
        ok("own PIN accepted, dialog closed", not await A.is_visible("#force-pin-dlg"))
        # members in grade 4
        await A.click("#tabs button[data-tab=mt]"); await A.wait_for_timeout(300); await A.click("#mt-grades button[data-grade='4']"); await A.wait_for_timeout(300)
        for i, n in enumerate(["ቤዛ ተስፋዬ", "ናትናኤል ደምሴ", "ሊዲያ ግርማ"]):
            if not await A.is_visible("#st-dlg"): await A.click("#mt-add-student"); await A.wait_for_timeout(200)
            await A.fill("#st-form [name=full_name]", n)
            if i == 0: await A.check("#st-form [name=consent]")
            await A.click("#st-form button.primary"); await A.wait_for_timeout(450)
        await A.keyboard.press("Escape"); await A.wait_for_timeout(300)
        await A.click("#tabs button[data-tab=students]"); await A.wait_for_timeout(500)
        marks = await A.locator("#st-table .no-consent, table .no-consent").count()
        ok("no-consent marker on 2 of 3 members", marks == 2, f"markers={marks}")
        await A.click("#tabs button[data-tab=mt]"); await A.wait_for_timeout(300)
        await A.click("#mt-gen"); await A.wait_for_timeout(300); await A.click("#ask-yes"); await A.wait_for_timeout(700)
        slips = await A.inner_text("#slips")
        ids = re.findall(r"(?:መለያ ቁጥር|ID number): (\d+)", slips); codes = re.findall(r"(?:የአንድ ጊዜ ኮድ|One-time code): (\d{6})", slips)
        ok("one-time codes issued", len(codes) == 3, str(list(zip(ids, codes))))
        await A.click("#slips-dlg [data-close]"); await A.wait_for_timeout(300)
        # open check-in, read room code
        await A.click("#tabs button[data-tab=attendance]"); await A.wait_for_timeout(500)
        await A.click("[data-ci='30']"); await A.wait_for_timeout(600)
        room = (await A.text_content(".room-code") or "").strip()
        ok("room code shown to admin", re.fullmatch(r"\d{4}", room), room)
        tvtxt = await A.inner_text("#ci-code")
        key = (re.search(r"key=([^\s&]+)", tvtxt) or [None, None])[1]
        if not SF: ok("TV link with display key shown", bool(key), tvtxt[-80:])
        # member device
        M = await ctxA.new_page() if SF else await (await br.new_context(viewport={"width": 390, "height": 844})).new_page()
        M.on("pageerror", lambda e: errs.append("M " + str(e)))
        await M.goto(URL + "#me"); await M.wait_for_timeout(700)
        await M.fill("#pt-id", ids[0]); await M.fill("#pt-pw", codes[0]); await M.click("#portal-form button.primary"); await M.wait_for_timeout(1000)
        txt = await M.inner_text("#portal-result")
        ok("member sees only own name", sum(n in txt for n in ["ቤዛ ተስፋዬ", "ናትናኤል ደምሴ", "ሊዲያ ግርማ"]) == 1)
        await M.fill("#pt-room", "0000" if room != "0000" else "1111"); await M.click("#pt-checkin"); await M.wait_for_timeout(700)
        ok("check-in refused without the right room code", not await M.locator(".ci-done").count())
        await M.fill("#pt-room", room); await M.click("#pt-checkin"); await M.wait_for_timeout(800)
        ok("check-in works with the room code", await M.locator(".ci-done").count() > 0)
        # TV display
        if not SF:
            D = await (await br.new_context(viewport={"width": 1280, "height": 720})).new_page()
            D.on("pageerror", lambda e: errs.append("D " + str(e)))
            await D.goto(URL.rstrip("/") + "/display"); await D.wait_for_timeout(1500)
            ok("public TV does NOT show the room code", room not in await D.inner_text("body"))
            await D.goto(URL.rstrip("/") + "/display?key=" + key); await D.wait_for_timeout(1500)
            ok("keyed TV shows the room code", room in await D.inner_text("body"))
            await D.screenshot(path=f"/tmp/{TAG}-tv.png")
        # excused does not lower the %
        await A.reload(); await A.wait_for_timeout(800)
        await A.click("#tabs button[data-tab=attendance]"); await A.wait_for_timeout(600)
        rows = A.locator(".att-row")
        await rows.nth(1).locator("button[data-s='E']").click(); await rows.nth(2).locator("button[data-s='P']").click()
        await A.click("#at-save"); await A.wait_for_timeout(500)
        await A.click("#tabs button[data-tab=reports]"); await A.wait_for_timeout(800)
        rep = await A.inner_text("#tab-reports")
        ok("report: excused member not shown as 0%", "0%" not in rep.replace("100%", ""), "")
        # calendar labels
        await A.click("#tabs button[data-tab=calendar]"); await A.wait_for_timeout(600)
        cal = await A.inner_text("#tab-calendar")
        ok("calendar legend separates nine major feasts / great holidays", ("ዘጠኙ ዐበይት በዓላት" in cal or "Nine major feasts" in cal) and ("ታላቅ በዓል" in cal or "Great holiday" in cal))
        await A.click("#tabs button[data-tab=settings]"); await A.wait_for_timeout(400)
        st = await A.inner_text("#tab-settings")
        ok("privacy-law + security help visible", "1321" in st and ("የክፍል ኮድ" in st or "room code" in st))
        if SF:
            # restore a server-style backup (no pin_hash) must NOT lock the admin out
            bk = {"settings": {"school_name": "ከሰርቨር የመጣ"}, "students": [], "programs": [], "attendance": {}}
            await A.evaluate("b => LocalServer.restore(b)", bk); await A.reload(); await A.wait_for_timeout(700)
            await A.evaluate("localStorage.removeItem('ss_token'); sessionStorage.clear()"); await A.reload(); await A.wait_for_timeout(600)
            if await A.is_visible("#login-pin"):
                await A.fill("#login-pin", NEWPIN); await A.keyboard.press("Enter"); await A.wait_for_timeout(700)
            ok("restore of a server backup keeps my PIN", not await A.is_visible("#login") and not await A.is_visible("#force-pin-dlg"))
        ok("no page errors", not errs, str(errs))
        await br.close()
asyncio.run(main())
print(json.dumps({"tag": TAG, "passed": sum(res.values()), "total": len(res)}))

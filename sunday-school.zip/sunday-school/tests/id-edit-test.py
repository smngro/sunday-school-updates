import urllib.request, urllib.error, json, sys, datetime as dt
B = sys.argv[1].rstrip("/") + "/api/"; res = []
def ok(n, c, i=""): res.append(bool(c)); print(("PASS " if c else "FAIL ") + n, i)
def call(p, m="GET", b=None, t=None, mem=None):
    h = {"Content-Type": "application/json"}
    if t: h["X-Token"] = t
    if mem: h["X-Member"] = mem
    try:
        with urllib.request.urlopen(urllib.request.Request(B + p, data=json.dumps(b).encode() if b is not None else None, headers=h, method=m)) as r: return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e: return {"error": e.code, "msg": json.loads(e.read() or b"{}").get("error")}
t = call("login", "POST", {"pin": "1234"})["token"]; t = call("pin", "POST", {"old": "1234", "new": "582913"}, t)["token"]
today = dt.date.today().isoformat()
r = call("students", "POST", {"full_name": "Typed", "id": 1001, "grade": 4}, t); ok("new member with a typed ID number", r.get("id") == 1001, r)
r = call("students", "POST", {"full_name": "Auto"}, t); ok("automatic numbers continue after it", r.get("id") == 1002, r)
r = call("students", "POST", {"full_name": "Dup", "id": 1001}, t); ok("a used ID number is refused", r.get("error") == 400, r)
r = call("students", "POST", {"full_name": "Bad", "id": "abc"}, t); ok("a non-number is refused", r.get("error") == 400, r)
# give member 1001 records everywhere, then change the number
d = call("depts", t=t)[0]["id"]
call(f"depts/{d}/members", "POST", {"student_ids": [1001]}, t)
call(f"depts/{d}/members/1001", "PUT", {"role": "ጸሐፊ"}, t)
call(f"depts/{d}/attendance", "POST", {"date": today, "records": [{"student_id": 1001, "status": "P"}]}, t)
call("attendance", "POST", {"date": today, "records": [{"student_id": 1001, "status": "L"}]}, t)
tid = call("mt/tests", "POST", {"grade": 4, "title": "T", "max_score": 50}, t)["id"]
call("mt/scores", "POST", {"scores": [{"test_id": tid, "student_id": 1001, "score": 44}]}, t)
code = call("codes", "POST", {"student_ids": [1001]}, t)[0]["code"]
r = call("students/1001", "PUT", {"full_name": "Typed", "grade": 4, "new_id": 77}, t); ok("ID number changed", r.get("id") == 77, r)
ok("the old number is gone", 1001 not in [x["id"] for x in call("students", t=t)])
ok("attendance followed", [x for x in call(f"attendance?date={today}", t=t) if x["id"] == 77][0]["status"] == "L")
ok("department + role followed", [x for x in call(f"depts/{d}/members", t=t) if x["id"] == 77][0]["role"] == "ጸሐፊ")
ok("meeting attendance followed", [x for x in call(f"depts/{d}/report?from={today}&to={today}", t=t)["members"] if x["id"] == 77][0]["present"] == 1)
ok("test scores followed", call("mt/grade/4", t=t)["scores"].get(f"{tid}|77") == 44)
r = call("portal/login", "POST", {"id": 77, "code": code}); ok("member logs in with the NEW number and the same code", "token" in r, r)
r = call("students/1002", "PUT", {"full_name": "Auto", "new_id": 77}, t); ok("changing to another member's number is refused", r.get("error") == 400, r)
print(json.dumps({"passed": sum(res), "total": len(res)}))

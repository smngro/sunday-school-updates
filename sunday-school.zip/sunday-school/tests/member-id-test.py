import asyncio, sys, json
from playwright.async_api import async_playwright
URL=sys.argv[1]; res=[]
def ok(n,c,i=""): res.append(bool(c)); print(("PASS " if c else "FAIL ")+n, i)
async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch(executable_path="/usr/bin/google-chrome"); errs=[]
        A = await (await br.new_context(viewport={"width":1366,"height":900})).new_page(); A.on("pageerror", lambda e: errs.append(str(e)))
        await A.goto(URL); await A.evaluate("localStorage.clear()"); await A.reload(); await A.wait_for_timeout(500)
        await A.fill("#login-pin","1234"); await A.keyboard.press("Enter"); await A.wait_for_timeout(800)
        await A.fill("#fp-new","246813"); await A.fill("#fp-new2","246813"); await A.click("#force-pin-form button.primary"); await A.wait_for_timeout(800)
        await A.click("#tabs button[data-tab=students]"); await A.wait_for_timeout(500)
        await A.click("#st-add"); await A.wait_for_timeout(600)
        ok("ID number field in the form, empty for a new member", await A.is_visible("#st-idno") and await A.input_value("#st-idno") == "")
        ok("ID number can't be typed over", await A.get_attribute("#st-idno", "readonly") is not None)
        await A.screenshot(path="/tmp/id-form.png")
        await A.fill("#st-form [name=full_name]", "ቤዛ ተስፋዬ"); await A.click("#st-form button.primary"); await A.wait_for_timeout(500)
        msg = await A.inner_text("#toast"); ok("saving tells the new ID number", "መለያ ቁጥር" in msg and any(ch.isdigit() for ch in msg), msg)
        await A.keyboard.press("Escape"); await A.wait_for_timeout(600)
        row = await A.inner_text("#st-body tr:first-child"); ok("ID number column in the member list", row.split("\t")[1].strip().isdigit(), row.replace("\t"," | "))
        await A.click("#st-body [data-edit]"); await A.wait_for_timeout(700)
        ok("editing shows the member's ID number", (await A.input_value("#st-idno")).isdigit())
        ok("no page errors", not errs, errs); await br.close()
asyncio.run(main()); print(json.dumps({"passed":sum(res),"total":len(res)}))

/* TV / projector display screen (kept in its own file so the page can forbid inline scripts) */
'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const params = new URLSearchParams(location.search);       // optional: ?class=Grade%201  ?date=2026-11-15
let data = null, offset = 0, lastTicker = null;

const pad = n => String(n).padStart(2, '0');
const isAm = () => { try { return (localStorage.getItem('ss_lang') || 'am') === 'am'; } catch (e) { return true; } };
const now = () => new Date(Date.now() + offset);           // follow the SERVER clock
const hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const toMin = t => { if (!t) return null; const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const fmt12 = t => { if (!t) return ''; let [h, m] = t.split(':').map(Number); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; return `${h}:${pad(m)} ${ap}`; };
const range = p => [fmt12(p.start_time), fmt12(p.end_time)].filter(Boolean).join(' – ');
const meta = p => [p.leader && '👤 ' + esc(p.leader), p.location && '📍 ' + esc(p.location), p.class_name && '👥 ' + esc(p.class_name)].filter(Boolean).join('  ·  ');

async function load() {
  try {
    const q = new URLSearchParams();
    if (params.get('class')) q.set('class', params.get('class'));
    if (params.get('date')) q.set('date', params.get('date'));
    if (params.get('key')) q.set('key', params.get('key'));
    const r = await fetch('/api/display?' + q, { cache: 'no-store' });
    data = await r.json();
    offset = new Date(data.server_now).getTime() - Date.now();
    $('#offline').style.display = 'none';
    $('#school').textContent = data.school_name + (params.get('class') ? ' — ' + params.get('class') : '');
    document.title = data.school_name + ' — Display';
    renderTicker();
    render();
  } catch (e) {
    $('#offline').style.display = 'block';
  }
}

function renderTicker() {
  const list = data.announcements;
  const html = list.map(esc).join('<span class="sep"><img class="emblem" src="/img/emblem.webp" alt=""></span>');
  if (html === lastTicker) return;
  lastTicker = html;
  $('#footer').style.display = list.length ? '' : 'none';
  const t = $('#ticker');
  t.innerHTML = html;
  t.style.animationDuration = Math.max(15, t.textContent.length / 6) + 's';
}

function render() {
  const d = now();
  $('#clock').textContent = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const am = isAm(), greg = d.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  $('#gdate').textContent = am ? EthioDate.format(d) : greg;
  $('#edate').textContent = (am ? greg : EthioDate.format(d)) + '  ·  ' + EthioDate.formatTime(d);
  $('#lbl-now').textContent = am ? 'አሁን' : 'Now · አሁን';
  $('#lbl-next').textContent = am ? 'ቀጣይ' : 'Next · ቀጣይ';
  $('#lbl-today').textContent = am ? 'የዛሬ መርሐ ግብር' : "Today's programs · የዛሬ መርሐ ግብር";
  { // next major feast countdown + today's fast (Ethiopian Orthodox calendar)
    const tj = EthioCal.dateToJdn(d), ups = EthioCal.upcoming(tj, { types: ['major', 'holiday'], limit: 3 });
    const nm = e => (am ? e.am : e.en), todayF = ups.filter(e => e.start === tj), nx = ups.find(e => e.start > tj);
    let fh = todayF.length ? `<div class="fn">🎉 ${todayF.map(e => esc(nm(e))).join(' · ')}</div><div class="fd">${am ? 'እንኳን አደረሳችሁ!' : 'Happy feast day!'}</div>` : '';
    if (nx) {
      const ms = EthioCal.jdnToDate(nx.start) - d, dd = Math.floor(ms / 864e5), hh = Math.floor(ms / 36e5) % 24, mm = Math.floor(ms / 6e4) % 60;
      fh += `<div class="fn">${esc(nm(nx))}</div><div class="fd">${EthioDate.format(EthioCal.jdnToDate(nx.start))}</div>
        <div class="fc">⏳ ${am ? `${dd} ቀን ${hh} ሰዓት ${mm} ደቂቃ ቀርቷል` : `${dd} days ${hh} h ${mm} min`}</div>`;
    }
    const fasts = EthioCal.currentFasts(tj), di = EthioCal.dayInfo(tj);
    if (fasts.length) fh += `<div class="ff">✝ ${fasts.map(f => `${esc(nm(f))} — ${am ? `${f.day}ኛ ቀን · ${f.left} ቀን ቀርቷል` : `day ${f.day} · ${f.left} days left`}`).join('<br>')}</div>`;
    else if (di.weekly) fh += `<div class="ff">✝ ${am ? (di.wd === 3 ? 'የረቡዕ ጾም' : 'የዓርብ ጾም') : (di.wd === 3 ? 'Wednesday fast' : 'Friday fast')}</div>`;
    if (di.monthly) fh += `<div class="ff">🕯 ${am ? 'ዛሬ የሚታሰቡት፦ ' + esc(di.monthly[0]) : 'Today: ' + esc(di.monthly[1])}</div>`;
    if (data && data.checkin && data.checkin.open) {
      const until = data.checkin.until.slice(11, 16), link = location.origin.startsWith('http') ? location.origin + '/#me' : '';
      fh = `<div class="fc" style="color:#7CFC9A">📱 ${am ? 'የራስ ክትትል ክፍት ነው — እስከ ' + until : 'Self check-in is open — until ' + until}</div>` +
      (data.checkin.code ? `<div class="room">${am ? 'የክፍል ኮድ' : 'Room code'}: <b>${esc(data.checkin.code)}</b></div>` : '') +
        (link ? `<div class="fd">${esc(link)}</div>` : '') + '<hr style="border-color:rgba(255,255,255,.12)">' + fh;
    }
    $('#feast').innerHTML = fh;
    $('#lbl-feast').textContent = am ? 'ቀጣይ ዐቢይ በዓልና ጾም' : 'Next feast · ቀጣይ በዓል';
  }
  if (!data) return;

  const viewingToday = !params.get('date');
  const cur = viewingToday ? d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60 : -1;
  const progs = data.programs;
  let current = null, next = null;
  progs.forEach(p => {
    const s = toMin(p.start_time), e = toMin(p.end_time) ?? (s !== null ? s + 60 : null);
    p._s = s; p._e = e;
    p._state = s === null ? 'none' : cur >= e ? 'past' : cur >= s ? 'current' : 'future';
    if (p._state === 'current' && !current) current = p;
    if (p._state === 'future' && !next) next = p;
  });

  $('#items').innerHTML = progs.length ? progs.map(p => `
    <div class="item ${p._state}">
      <div class="t">${esc(fmt12(p.start_time)) || '—'}</div>
      <div><div class="n">${esc(p.title)}</div><div class="m">${meta(p)}</div></div>
    </div>`).join('') : `<div class="empty">${am ? 'ዛሬ መርሐ ግብር የለም።' : 'No programs scheduled today.<br>ዛሬ መርሐ ግብር የለም።'}</div>`;

  if (current) {
    const pct = Math.min(100, Math.max(0, 100 * (cur - current._s) / ((current._e - current._s) || 1)));
    $('#now').innerHTML = `<div class="time">${esc(range(current))}</div><h1>${esc(current.title)}</h1>
      <div class="meta">${meta(current)}</div>
      ${current.description ? `<div class="meta" style="margin-top:1vh">${esc(current.description)}</div>` : ''}
      <div class="progress"><i style="width:${pct}%"></i></div>`;
  } else {
    $('#now').innerHTML = `<h1 style="font-size:5vh;color:var(--muted)">${progs.length && !next ? (am ? 'የዛሬ መርሐ ግብር ተጠናቋል' : 'Programs finished for today') : (am ? 'እንኳን ደህና መጡ' : 'Welcome · እንኳን ደህና መጡ')}</h1>`;
  }
  if (next) {
    const mins = Math.round(next._s - cur);
    const cd = am ? (mins >= 60 ? `${Math.floor(mins / 60)} ሰዓት ${mins % 60} ደቂቃ` : `${mins} ደቂቃ`)
    : (mins >= 60 ? `${Math.floor(mins / 60)} h ${mins % 60} min` : `${mins} min`);
    $('#next').innerHTML = `<h2>${esc(next.title)}</h2><div class="meta">${[esc(range(next)), meta(next)].filter(Boolean).join('  ·  ')}</div>
      ${viewingToday ? `<div class="countdown">⏱ ${am ? 'ለመጀመር ' + cd + ' ቀርቷል' : 'starts in ' + cd}</div>` : ''}`;
    $('#next-box').style.display = '';
  } else {
    $('#next-box').style.display = 'none';
  }
}

document.addEventListener('click', () => {
  const el = document.documentElement;
  if (!document.fullscreenElement && el.requestFullscreen) el.requestFullscreen().catch(() => {});
  $('#hint').style.display = 'none';
});
setTimeout(() => ($('#hint').style.display = 'none'), 15000);

load();
setInterval(load, 10000);   // pick up changes made by teachers every 10 seconds
setInterval(render, 1000);  // clock + live progress

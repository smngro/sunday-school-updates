"""For the person who maintains the app: make an update that schools can install.

    python tools/make-release.py              (zip and latest.json are uploaded side by side)

1. Change VERSION in server.py to today's date first (e.g. 2026.12.01). Updates must be newer.
2. Run this. It writes, next to the app folder:
      sunday-school.zip   - the update (upload it to the address you gave)
      latest.json         - version + checksum (put it at a fixed https address)
3. In each school: Settings -> Updates -> Update address = the https address of latest.json.
"""
import hashlib, json, os, re, sys, zipfile

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.dirname(BASE)
SKIP_DIRS = {"__pycache__", "data", "python", ".git"}

version = re.search(r'^VERSION = "([0-9.]+)"', open(os.path.join(BASE, "server.py"), encoding="utf-8").read(), re.M).group(1)
url = sys.argv[1] if len(sys.argv) > 1 else "sunday-school.zip"   # relative = next to latest.json
notes = sys.argv[2] if len(sys.argv) > 2 else ""
zpath = os.path.join(OUT, "sunday-school.zip")
with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
    for folder, dirs, files in os.walk(BASE):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            full = os.path.join(folder, f)
            z.write(full, os.path.join("sunday-school", os.path.relpath(full, BASE)).replace("\\", "/"))
sha = hashlib.sha256(open(zpath, "rb").read()).hexdigest()
with open(os.path.join(OUT, "latest.json"), "w", encoding="utf-8") as f:
    json.dump({"version": version, "url": url, "sha256": sha, "notes": notes}, f, ensure_ascii=False, indent=1)
print(f"version {version}\n{zpath}\n{os.path.join(OUT, 'latest.json')}\nsha256 {sha}")

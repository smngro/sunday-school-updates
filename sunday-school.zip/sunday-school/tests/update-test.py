import urllib.request, urllib.error, json, base64, time, io, zipfile, sys
B=(sys.argv[1].rstrip("/") if len(sys.argv)>1 else "http://127.0.0.1:8095")+"/api/"
def call(p,m="GET",b=None,t=None):
    h={"Content-Type":"application/json"}
    if t: h["X-Token"]=t
    try:
        with urllib.request.urlopen(urllib.request.Request(B+p,data=json.dumps(b).encode() if b is not None else None,headers=h,method=m),timeout=30) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read() or b"{}")
def ok(n,c,i=""): print(("PASS " if c else "FAIL ")+n, i)
st,d=call("login","POST",{"pin":"1234"}); t=d["token"]; st,d=call("pin","POST",{"old":"1234","new":"582913"},t); t=d["token"]
call("settings","POST",{"school_name":"ውሉደ አበው"},t); call("students","POST",{"full_name":"ቤዛ","consent":1},t)
st,d=call("maintenance",t=t); ok("status", st==200 and d["version"]=="2026.11.12.7", d)
st,d=call("maintenance/usb","POST",{},t); ok("usb refused when no drive/folder", st==400, d)
st,d=call("maintenance/settings","POST",{"backup_folder":"/tmp/up/usb","usb_every":7},t); ok("set backup folder", st==200 and d["drives"]==["/tmp/up/usb"], d.get("drives"))
st,d=call("maintenance/usb","POST",{},t); ok("usb backup", st==200, d)
import os; ok("usb files", any(f.endswith(".db") for f in os.listdir("/tmp/up/usb/SundaySchool-Backup")) and os.path.exists("/tmp/up/usb/SundaySchool-Backup/READ-ME.txt"))
st,d=call("maintenance/settings","POST",{"update_url":"http://x/latest.json"},t); ok("http update url refused", st==400, d)
st,d=call("maintenance/check","POST",{},t); ok("check without url explains", st==400, d)
# bad zips
bio=io.BytesIO(); z=zipfile.ZipFile(bio,"w"); z.writestr("sunday-school/server.py",'VERSION = "2099.1.1"\n'); z.writestr("sunday-school/public/index.html","x"); z.writestr("sunday-school/../evil.py","x"); z.close()
st,d=call("maintenance/install","POST",{"zip":base64.b64encode(bio.getvalue()).decode()},t); ok("zip-slip rejected", st==400, d)
st,d=call("maintenance/install","POST",{"zip":base64.b64encode(b"not a zip").decode()},t); ok("non-zip rejected", st==400, d)
same=open("/tmp/up/rel-2026.11.12.8/sunday-school.zip","rb").read()
# install 11.13
st,d=call("maintenance/install","POST",{"zip":base64.b64encode(same).decode()},t); ok("install 2026.11.12.8 accepted", st==200, d)
for i in range(30):
    time.sleep(1)
    try:
        st,d=call("maintenance",t=t)
        if st==200 and d["version"]=="2026.11.12.8": break
    except Exception: pass
ok("restarted on new version", d.get("version")=="2026.11.12.8", d.get("version"))
st,s=call("students",t=t); ok("data + login kept after update", st==200 and s and s[0]["full_name"]=="ቤዛ")
html=urllib.request.urlopen("http://127.0.0.1:8095/").read().decode(); ok("new files served", "v13" in html)
st,d=call("maintenance/install","POST",{"zip":base64.b64encode(same).decode()},t); ok("same version refused", st==400, d)
# broken release -> rollback
br=open("/tmp/up/rel-2026.11.12.9/sunday-school.zip","rb").read()
st,d=call("maintenance/install","POST",{"zip":base64.b64encode(br).decode()},t); ok("install broken 11.14 accepted (it compiles)", st==200, d)
time.sleep(6)                                  # let the old server stop and the broken one fail first
for i in range(30):
    time.sleep(1)
    try:
        st,d=call("maintenance",t=t)
        if st==200: break
    except Exception: pass
ok("rolled back to 11.13", d.get("version")=="2026.11.12.8" and "2026.11.12.9" in (d.get("rolled_back") or ""), (d.get("version"), d.get("rolled_back")))
st,s=call("students",t=t); ok("data intact after rollback", st==200 and s[0]["full_name"]=="ቤዛ")

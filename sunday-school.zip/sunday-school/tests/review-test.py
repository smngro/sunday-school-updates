import urllib.request, urllib.error, json, base64, os, sqlite3, sys, time, subprocess, asyncio
B = sys.argv[1].rstrip("/") + "/api/"; DATA = sys.argv[2]
res = []
def ok(n, c, i=""): res.append(bool(c)); print(("PASS " if c else "FAIL ") + n, i)
def call(p, m="GET", b=None, t=None, raw=False):
    h = {"Content-Type": "application/json"}
    if t: h["X-Token"] = t
    try:
        with urllib.request.urlopen(urllib.request.Request(B + p, data=json.dumps(b).encode() if b is not None else None, headers=h, method=m), timeout=30) as r:
            d = r.read(); return r.status, (d if raw else json.loads(d or b"{}"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")

st, d = call("login", "POST", {"pin": "1234"}); t = d["token"]; st, d = call("pin", "POST", {"old": "1234", "new": "582913"}, t); t = d["token"]
ids = {}
for g, names in [(4, ["ቤዛ", "ናትናኤል"]), (12, ["ዮሐንስ"]), (11, ["ማርታ"])]:
    for n in names: ids[n] = call("students", "POST", {"full_name": n, "grade": g}, t)[1]["id"]
# ---- school year
_, old = call("mt/tests", "POST", {"grade": 4, "title": "Old test", "max_score": 50, "term": "1ኛ ወሰነ ትምህርት", "date": "2026-05-01"}, t)
_, new = call("mt/tests", "POST", {"grade": 4, "title": "New test", "max_score": 50, "term": "1ኛ ወሰነ ትምህርት", "date": "2026-10-20"}, t)
call("mt/scores", "POST", {"scores": [{"test_id": new["id"], "student_id": ids["ቤዛ"], "score": 45}]}, t)
_, d = call("mt/grade/4", t=t)
ok("this school year shows only this year's tests", [x["title"] for x in d["tests"]] == ["New test"] and d["year"] == 2019, (d["year"], [x["title"] for x in d["tests"]]))
ok("years list has both years", d["years"][:2] == [2019, 2018], d["years"])
top = [r for r in d["results"] if r["id"] == ids["ቤዛ"]][0]
ok("old year's test no longer lowers this year's result", top["pct"] == 90.0 and top["max"] == 50, top)
_, d = call("mt/grade/4?year=2018", t=t)
ok("last year's results still viewable", [x["title"] for x in d["tests"]] == ["Old test"])
# migration of tests without a year
db = sqlite3.connect(os.path.join(DATA, "sundayschool.db")); db.execute("UPDATE mt_tests SET year=NULL"); db.commit(); db.close()
# ---- promotion
st, d = call("mt/promote", "POST", {}, t); ok("promotion moves students up", st == 200 and d["moved"] == 3 and d["graduated"] == 1, d)
_, s = call("students", t=t); g = {x["full_name"]: (x["grade"], x["class_name"]) for x in s}
ok("grades after promotion", g["ቤዛ"][0] == 5 and g["ማርታ"][0] == 12 and g["ዮሐንስ"] == (None, "ተመራቂ 2018"), g)
st, d = call("mt/promote", "POST", {}, t); ok("second promotion in same year needs confirmation", st == 409, d)
ok("backup made before promotion", any(f.startswith("before-promotion-") for f in os.listdir(os.path.join(DATA, "backups"))))
# ---- attendance: a save from a page opened earlier must not wipe a phone check-in
today = time.strftime("%Y-%m-%d")
call("attendance", "POST", {"date": today, "records": [{"student_id": ids["ናትናኤል"], "status": "A"}]}, t)   # only the changed row is sent now
_, a = call(f"attendance?date={today}", t=t); m = {x["full_name"]: x["status"] for x in a}
ok("saving one change leaves other marks alone", m["ናትናኤል"] == "A", m)
# ---- USB privacy: a stranger's drive is not used automatically
import importlib.util
os.environ["SS_DATA"] = DATA
spec = importlib.util.spec_from_file_location("srv", sys.argv[3]); srv = importlib.util.module_from_spec(spec); spec.loader.exec_module(srv)
stranger = "/tmp/rv-stranger"; os.makedirs(stranger, exist_ok=True)
srv.usb_targets = lambda c=None: [stranger]
srv.auto_usb_backup()
ok("no automatic copy to an unknown flash drive", not os.path.exists(os.path.join(stranger, "SundaySchool-Backup")))
os.makedirs(os.path.join(stranger, "SundaySchool-Backup"), exist_ok=True); srv.auto_usb_backup()
ok("automatic copy to the registered backup drive", any(f.endswith(".db") for f in os.listdir(os.path.join(stranger, "SundaySchool-Backup"))))
ok("database health check", srv.db_healthy())
# ---- restore
st, blob = call("backup", t=t, raw=True)
call("students", "POST", {"full_name": "added after backup"}, t)
st, d = call("maintenance/restore", "POST", {"db": base64.b64encode(blob).decode()}, t)
ok("restore accepted", st == 200 and d.get("members") == 4, d)
st, l = call("login", "POST", {"pin": "582913"}); t2 = l.get("token")
_, s = call("students", t=t2)
ok("restored data is the backup's (PIN unchanged)", t2 and "added after backup" not in [x["full_name"] for x in s] and len(s) == 4, len(s))
st, d = call("maintenance/restore", "POST", {"db": base64.b64encode(b"hello").decode()}, t2); ok("non-backup file refused", st == 400, d)
_, d = call("mt/grade/4?year=2018", t=t2); ok("tests without a year get it back from their date", [x["title"] for x in d["tests"]] == ["Old test"], d["tests"])
print(json.dumps({"passed": sum(res), "total": len(res)}))

/* Ethiopian calendar (ዓ.ም) conversion — works fully offline. */
const EthioDate = (() => {
  const MONTHS = ['መስከረም', 'ጥቅምት', 'ኅዳር', 'ታኅሣሥ', 'ጥር', 'የካቲት', 'መጋቢት',
                  'ሚያዝያ', 'ግንቦት', 'ሰኔ', 'ሐምሌ', 'ነሐሴ', 'ጳጉሜን'];
  const DAYS = ['እሑድ', 'ሰኞ', 'ማክሰኞ', 'ረቡዕ', 'ሐሙስ', 'ዓርብ', 'ቅዳሜ']; // JS getDay(): 0 = Sunday

  function jdn(y, m, d) {
    const a = Math.floor((14 - m) / 12), yy = y + 4800 - a, mm = m + 12 * a - 3;
    return d + Math.floor((153 * mm + 2) / 5) + 365 * yy + Math.floor(yy / 4)
      - Math.floor(yy / 100) + Math.floor(yy / 400) - 32045;
  }

  function fromDate(date) {
    const off = jdn(date.getFullYear(), date.getMonth() + 1, date.getDate()) - 1723856;
    const r = ((off % 1461) + 1461) % 1461;
    const n = (r % 365) + 365 * Math.floor(r / 1460);
    const year = 4 * Math.floor(off / 1461) + Math.floor(r / 365) - Math.floor(r / 1460);
    return { year, month: Math.floor(n / 30) + 1, day: (n % 30) + 1 };
  }

  function format(date, withDay = true) {
    const e = fromDate(date);
    return (withDay ? DAYS[date.getDay()] + '፣ ' : '') + `${MONTHS[e.month - 1]} ${e.day} ቀን ${e.year} ዓ.ም`;
  }

  /* Ethiopian local time: day starts at 6 AM, e.g. 7:00 AM = ጠዋት 1:00, 4:00 PM = ከሰዓት 10:00 */
  function formatTime(date) {
    const H = date.getHours(), h = ((H + 6) % 12) || 12;
    const part = H >= 6 && H < 12 ? 'ጠዋት' : H >= 12 && H < 18 ? 'ከሰዓት' : H >= 18 ? 'ምሽት' : 'ሌሊት';
    return `${part} ${h}:${String(date.getMinutes()).padStart(2, '0')}`;
  }

  return { fromDate, format, formatTime, MONTHS, DAYS };
})();
if (typeof module !== 'undefined') module.exports = EthioDate;

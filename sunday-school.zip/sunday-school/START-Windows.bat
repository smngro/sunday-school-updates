@echo off
setlocal
title Sunday School Server
cd /d "%~dp0"
echo.
if not exist "%~dp0server.py" (
  echo  ============================================================
  echo   The zip is NOT extracted yet.
  echo.
  echo   1. Close this window and WinRAR / the zip window.
  echo   2. Right-click sunday-school.zip and choose "Extract Here"
  echo      or "Extract All".
  echo   3. Open the new "sunday-school" folder and double-click
  echo      START-Windows.bat from there.
  echo  ============================================================
  echo.
  pause
  exit /b
)

:: ---- find a working Python 3.8 or newer -------------------------------------------
:: 1) a portable Python put in the "python" folder (for PCs where you can't install)
:: 2) the "py" launcher   3) "python" (skipping the fake Microsoft Store shortcut)
set "PYEXE="
set "PYARG="
if exist "%~dp0python\python.exe" (
  "%~dp0python\python.exe" -c "import sys,sqlite3; sys.exit(0 if sys.version_info>=(3,8) else 1)" >nul 2>nul && set "PYEXE=%~dp0python\python.exe"
)
if not defined PYEXE (
  py -3 -c "import sys,sqlite3; sys.exit(0 if sys.version_info>=(3,8) else 1)" >nul 2>nul && (set "PYEXE=py" & set "PYARG=-3")
)
if not defined PYEXE (
  python -c "import sys,sqlite3; sys.exit(0 if sys.version_info>=(3,8) else 1)" >nul 2>nul && set "PYEXE=python"
)
if not defined PYEXE goto nopython

echo  Starting the Sunday School server...
echo.
:: Everything after this is on ONE line on purpose: an update may replace this .bat file
:: while the server runs, and Windows must not read the changed file halfway.
"%PYEXE%" %PYARG% "%~dp0tools\run.py" %* & echo. & pause & exit /b

:nopython
echo  ============================================================
echo   Python 3 (version 3.8 or newer) is not installed.
echo   Python is free and is needed only once.
echo  ============================================================
echo.
where winget >nul 2>nul
if errorlevel 1 goto manual
choice /c YN /m "  Install Python now? (needs internet for about 5 minutes)"
if errorlevel 2 goto manual
winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
echo.
echo  ============================================================
echo   If it says "Successfully installed": CLOSE this window and
echo   double-click START-Windows.bat again.
echo  ============================================================
echo.
pause
exit /b

:manual
echo   1. Open  https://www.python.org/downloads/windows/
echo      and download the "Windows installer (64-bit)".
echo   2. Run it and TICK "Add python.exe to PATH" at the bottom.
echo   3. Double-click START-Windows.bat again.
echo.
echo   No internet here? Copy the Python installer from another
echo   computer with a USB stick (see HANDOVER-GUIDE.txt).
echo  ============================================================
start "" "https://www.python.org/downloads/windows/" >nul 2>nul
echo.
pause
exit /b

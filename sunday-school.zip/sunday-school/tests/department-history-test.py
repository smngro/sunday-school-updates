import urllib.request, urllib.error, json, sys, datetime as dt
B = sys.argv[1].rstrip("/") + "/api/"; res = []
def ok(n, c, i=""): res.append(bool(c)); print(("PASS " if c else "FAIL ") + n, i)
def call(p, m="GET", b=None, t=None):
    h = {"Content-Type": "application/json"}
    if t: h["X-Token"] = t
    try:
        with urllib.request.urlopen(urllib.request.Request(B + p, data=json.dumps(b).encode() if b is not None else None, headers=h, method=m)) as r: return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e: return {"error": e.read().decode()}
t = call("login", "POST", {"pin": "1234"})["token"]; t = call("pin", "POST", {"old": "1234", "new": "582913"}, t)["token"]
d = call("depts", t=t); A, Bd = d[0]["id"], d[1]["id"]
sid = call("students", "POST", {"full_name": "ቤዛ", "class_name": "ጀማሪ", "grade": 3}, t)["id"]
call(f"depts/{A}/members", "POST", {"student_ids": [sid]}, t)
today = dt.date.today().isoformat()
call(f"depts/{A}/attendance", "POST", {"date": today, "records": [{"student_id": sid, "status": "P"}]}, t)
# move to department B, as the member form does
call(f"depts/{A}/members/{sid}", "DELETE", None, t); call(f"depts/{Bd}/members", "POST", {"student_ids": [sid]}, t)
r = call(f"depts/{A}/report?from={today}&to={today}", t=t)
m = [x for x in r["members"] if x["id"] == sid]
ok("old department's report keeps the moved member's meetings", m and m[0]["present"] == 1 and m[0]["former"] == 1, m)
ok("not listed as a current member any more", sid not in [x["id"] for x in call(f"depts/{A}/members", t=t)])
# editing without the class field keeps the stored value
call(f"students/{sid}", "PUT", {"full_name": "ቤዛ ተስፋዬ", "grade": 3}, t)
s = [x for x in call("students", t=t) if x["id"] == sid][0]
ok("editing keeps the old class value", s["class_name"] == "ጀማሪ" and s["full_name"] == "ቤዛ ተስፋዬ", s["class_name"])
print(json.dumps({"passed": sum(res), "total": len(res)}))

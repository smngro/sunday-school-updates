#!/usr/bin/env python3
"""
Sunday School Manager — offline, local-network (LAN) web app.

Runs on Python 3.8+ using ONLY the standard library. No internet needed.

    python server.py          -> serves on port 8080
    python server.py 9000     -> custom port

Then open  http://<this-computer-ip>:8080  on any phone / tablet / PC / TV
connected to the same Wi-Fi or router.
"""
import csv
import datetime as dt
import hashlib
import hmac
import io
import json
import mimetypes

FIXED_TYPES = {".html": "text/html", ".js": "application/javascript", ".css": "text/css", ".json": "application/json",
               ".webmanifest": "application/manifest+json", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
               ".webp": "image/webp", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".txt": "text/plain", ".csv": "text/csv"}
import os
import secrets
import socket
import sqlite3
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

BASE = os.path.dirname(os.path.abspath(__file__))
PUBLIC = os.path.join(BASE, "public")
# Data lives OUTSIDE the app folder, so extracting a new copy or updating the app never starts from zero.
#   Windows: C:\Users\<you>\SundaySchool-Data      Linux/Mac: ~/SundaySchool-Data
# Set the SS_DATA environment variable to use another folder.
DATA = os.environ.get("SS_DATA") or os.path.join(os.path.expanduser("~"), "SundaySchool-Data")
OLD_DATA = os.path.join(BASE, "data")      # where versions before Nov 2026 kept it
BACKUPS = os.path.join(DATA, "backups")
DB_PATH = os.path.join(DATA, "sundayschool.db")
CONF_PATH = os.path.join(DATA, "config.json")
DEFAULT_PIN = "1234"
VERSION = "2026.11.12.3"          # year.month.day of this release; updates must be newer
KEEP_BACKUPS = 30

STUDENT_FIELDS = ["full_name", "christian_name", "gender", "birth_year", "class_name",
                  "parent_name", "phone", "address", "notes", "active", "grade", "birth_date", "consent"]
PROGRAM_FIELDS = ["date", "repeat_weekday", "start_time", "end_time", "title", "leader",
                  "class_name", "location", "description"]
STATUSES = {"P", "L", "A", "E"}  # Present, Late, Absent, Excused

# CSV header aliases -> field names (import is forgiving about headers)
CSV_ALIASES = {
    "full_name": "full_name", "name": "full_name", "full name": "full_name", "ሙሉ ስም": "full_name", "ስም": "full_name",
    "christian_name": "christian_name", "christian name": "christian_name", "baptismal name": "christian_name",
    "የክርስትና ስም": "christian_name",
    "gender": "gender", "sex": "gender", "ፆታ": "gender", "ጾታ": "gender",
    "birth_year": "birth_year", "birth year": "birth_year", "year of birth": "birth_year", "የትውልድ ዘመን": "birth_year",
    "class_name": "class_name", "class": "class_name", "group": "class_name", "ክፍል": "class_name",
    "parent_name": "parent_name", "parent": "parent_name", "guardian": "parent_name", "parent name": "parent_name",
    "ወላጅ": "parent_name",
    "phone": "phone", "telephone": "phone", "mobile": "phone", "ስልክ": "phone",
    "address": "address", "አድራሻ": "address",
    "notes": "notes", "note": "notes", "ማስታወሻ": "notes",
    "active": "active",
    "consent": "consent", "ፈቃድ": "consent",
    "birth_date": "birth_date", "birth date": "birth_date", "date of birth": "birth_date", "የትውልድ ቀን": "birth_date",
    "grade": "grade", "mt grade": "grade", "መሠረተ ትምህርት": "grade", "የመሠረተ ትምህርት ክፍል": "grade",
}
CSV_EXPORT_HEADERS = ["Full name", "Christian name", "Gender", "Birth year", "Class",
                      "Parent", "Phone", "Address", "Notes", "Active", "Grade", "Birth date", "Consent"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY,
  full_name TEXT NOT NULL,
  christian_name TEXT, gender TEXT, birth_year INTEGER, class_name TEXT,
  parent_name TEXT, phone TEXT, address TEXT, notes TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS attendance(
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  status TEXT NOT NULL,
  PRIMARY KEY(student_id, date)
);
CREATE INDEX IF NOT EXISTS idx_att_date ON attendance(date);
CREATE TABLE IF NOT EXISTS programs(
  id INTEGER PRIMARY KEY,
  date TEXT,                 -- one-time program date (YYYY-MM-DD)
  repeat_weekday INTEGER,    -- weekly program: 0=Mon ... 6=Sun (NULL = one-time)
  start_time TEXT, end_time TEXT,
  title TEXT NOT NULL, leader TEXT, class_name TEXT, location TEXT, description TEXT
);
CREATE TABLE IF NOT EXISTS announcements(
  id INTEGER PRIMARY KEY,
  text TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS mt_tests(          -- መሠረተ ትምህርት tests
  id INTEGER PRIMARY KEY,
  grade INTEGER NOT NULL,
  title TEXT NOT NULL, subject TEXT, term TEXT, date TEXT,
  max_score REAL NOT NULL DEFAULT 100
);
CREATE TABLE IF NOT EXISTS mt_scores(
  test_id INTEGER NOT NULL REFERENCES mt_tests(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  score REAL,
  PRIMARY KEY(test_id, student_id)
);
"""
CREATE_DEPTS = """
CREATE TABLE IF NOT EXISTS departments(       -- ክፍላት
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL, leader TEXT, description TEXT,
  active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS dept_attendance(    -- attendance at each department's meetings
  dept_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  date TEXT NOT NULL, status TEXT NOT NULL,
  PRIMARY KEY(dept_id, student_id, date)
);
CREATE TABLE IF NOT EXISTS dept_members(
  dept_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  role TEXT,
  PRIMARY KEY(dept_id, student_id)
);
"""
CREATE_SECURITY = """
CREATE TABLE IF NOT EXISTS sessions(          -- admin + member logins (only a hash of the token is stored)
  token_hash TEXT PRIMARY KEY,
  kind TEXT NOT NULL,                         -- 'admin' or 'member'
  student_id INTEGER,
  created REAL NOT NULL, expires REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS access_codes(      -- one-time codes for members (only a hash is stored)
  id INTEGER PRIMARY KEY,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL, salt TEXT NOT NULL,
  created REAL NOT NULL, expires REAL NOT NULL, used REAL
);
CREATE INDEX IF NOT EXISTS idx_codes_student ON access_codes(student_id);
"""
ADMIN_TTL = 12 * 3600          # admin login lasts 12 hours (renewed while in use)
MEMBER_TTL = 20 * 60           # a member's portal session lasts 20 minutes
CODE_DAYS_DEFAULT = 7          # a one-time code must be used within 7 days
DEFAULT_DEPTS = 22
MIGRATIONS = [("students", "grade", "INTEGER"), ("students", "pw_hash", "TEXT"), ("students", "pw_salt", "TEXT"),
              ("attendance", "by_self", "INTEGER DEFAULT 0"), ("students", "birth_date", "TEXT"),
              ("students", "consent", "INTEGER DEFAULT 0")]


class ApiError(Exception):
    def __init__(self, msg, code=400):
        super().__init__(msg)
        self.code = code


# ---------------------------------------------------------------- config / auth
conf_lock = threading.Lock()
CONF = {}
# Change counter: goes up after every edit, so every open browser can see that
# something changed on another device and refresh itself (live updates).
REV = {"v": secrets.randbelow(1_000_000)}
rev_lock = threading.Lock()


def bump_rev():
    with rev_lock:
        REV["v"] += 1


def local_hash(s):
    """Same tiny hash as the single-file (browser) version — used for passwords imported from it."""
    a, b = 5381, 52711
    for ch in "ssm:" + s:
        c = ord(ch)
        a = ((a * 33) & 0xFFFFFFFF) ^ c
        b = (b * 31 + c) & 0xFFFFFFFF
    def b36(n):
        d = "0123456789abcdefghijklmnopqrstuvwxyz"
        out = ""
        while True:
            n, r = divmod(n, 36)
            out = d[r] + out
            if n == 0:
                return out
    return b36(a) + b36(b)


def check_student_pw(pw, salt, stored):
    if salt and salt.startswith("L:"):            # imported from the single-file version
        return hmac.compare_digest(local_hash(salt[2:] + ":" + pw), stored)
    return hmac.compare_digest(hash_student_pw(pw, salt), stored)


def hash_pin(pin, salt):
    return hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salt.encode(), 120_000).hex()


def save_conf(c):
    tmp = CONF_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(c, f, indent=2)
    os.replace(tmp, CONF_PATH)


def load_conf():
    c = {}
    if os.path.exists(CONF_PATH):
        with open(CONF_PATH, encoding="utf-8") as f:
            c = json.load(f)
    if "secret" not in c or "pin_hash" not in c:
        c.setdefault("secret", secrets.token_hex(32))
        c["pin_salt"] = secrets.token_hex(8)
        c["pin_hash"] = hash_pin(DEFAULT_PIN, c["pin_salt"])
        c["default_pin"] = True
        save_conf(c)
    return c


def token_hash(t):
    return hashlib.sha256(("ssm-session:" + t).encode()).hexdigest()


def new_session(c, kind, student_id=None):
    t = secrets.token_urlsafe(32)
    now = time.time()
    c.execute("INSERT INTO sessions(token_hash, kind, student_id, created, expires) VALUES(?,?,?,?,?)",
              (token_hash(t), kind, student_id, now, now + (ADMIN_TTL if kind == "admin" else MEMBER_TTL)))
    return t


def get_session(c, t, kind):
    if not t:
        return None
    row = c.execute("SELECT * FROM sessions WHERE token_hash=? AND kind=?", (token_hash(t), kind)).fetchone()
    if not row or row["expires"] < time.time():
        return None
    if kind == "admin":     # stay logged in while in use
        c.execute("UPDATE sessions SET expires=? WHERE token_hash=?", (time.time() + ADMIN_TTL, row["token_hash"]))
        c.commit()
    return row


# brute-force protection: too many wrong tries -> locked for a while
FAILS = {}
fail_lock = threading.Lock()


def locked_for(key):
    with fail_lock:
        n, until = FAILS.get(key, (0, 0))
        return max(0, int(until - time.time()))


def record_fail(key, limit, lock_secs):
    with fail_lock:
        n, until = FAILS.get(key, (0, 0))
        n += 1
        FAILS[key] = (0, time.time() + lock_secs) if n >= limit else (n, until)


def clear_fails(key):
    with fail_lock:
        FAILS.pop(key, None)


def hash_code(code, salt):
    return hashlib.pbkdf2_hmac("sha256", code.encode(), salt.encode(), 30_000).hex()


def code_status(c):
    """student_id -> expiry time of their still-unused one-time code"""
    return dict(c.execute("SELECT student_id, MAX(expires) FROM access_codes WHERE used IS NULL AND expires > ? "
                          "GROUP BY student_id", (time.time(),)).fetchall())


def checkin_state(c, reveal=False):
    """Self check-in window. reveal=True also returns the room code (admin screen / TV with display key)."""
    until = get_setting(c, "checkin_until", "")
    try:
        u = dt.datetime.fromisoformat(until)
    except ValueError:
        return {"open": False, "until": None}
    st = {"open": dt.datetime.now() < u, "until": until if dt.datetime.now() < u else None}
    if reveal and st["open"]:
        st["code"] = get_setting(c, "checkin_code", "")
    return st


def display_key(c):
    k = get_setting(c, "display_key", "")
    if not k:
        k = secrets.token_urlsafe(9)
        c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('display_key',?)", (k,))
        c.commit()
    return k


# ---------------------------------------------------------------- database
def db():
    c = sqlite3.connect(DB_PATH, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init_db():
    c = db()
    c.execute("PRAGMA journal_mode=WAL")       # first, before any transaction is open
    c.executescript(SCHEMA)
    c.executescript(CREATE_DEPTS)
    c.executescript(CREATE_SECURITY)
    c.execute("DELETE FROM sessions WHERE expires < ?", (time.time(),))
    if c.execute("SELECT COUNT(*) FROM departments").fetchone()[0] == 0:      # first run: ክፍል 1 … ክፍል 22
        c.executemany("INSERT INTO departments(name, sort) VALUES(?,?)",
                      [(f"ክፍል {i}", i) for i in range(1, DEFAULT_DEPTS + 1)])
    for table, col, typ in MIGRATIONS:          # upgrade databases from older versions
        have = {r[1] for r in c.execute(f"PRAGMA table_info({table})")}
        if col not in have:
            c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
    c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('school_name','ሰንበት ትምህርት ቤት')")
    c.commit()
    c.close()


def snapshot(path):
    src, dst = db(), sqlite3.connect(path)
    with dst:
        src.backup(dst)
    dst.close()
    src.close()


def daily_backup():
    os.makedirs(BACKUPS, exist_ok=True)
    p = os.path.join(BACKUPS, f"sundayschool-{dt.date.today():%Y-%m-%d}.db")
    if not os.path.exists(p):
        snapshot(p)
    files = sorted(f for f in os.listdir(BACKUPS) if f.endswith(".db"))
    for f in files[:-KEEP_BACKUPS]:
        os.remove(os.path.join(BACKUPS, f))



# ---------------------------------------------------------------- USB / folder backups
USB_DIR = "SundaySchool-Backup"
USB_KEEP = 12              # keep the 12 newest copies on the USB stick (about 3 months if weekly)


def usb_targets(c=None):
    """Removable drives (flash disks) that are plugged in now, plus a folder the admin chose."""
    out = []
    chosen = get_setting(c, "backup_folder", "") if c else ""
    if chosen and os.path.isdir(chosen):
        out.append(chosen)
    try:
        if os.name == "nt":
            import ctypes, string
            k = ctypes.windll.kernel32
            mask = k.GetLogicalDrives()
            for i, letter in enumerate(string.ascii_uppercase):
                root = f"{letter}:\\"
                if mask >> i & 1 and k.GetDriveTypeW(root) == 2 and os.path.isdir(root):   # 2 = removable
                    out.append(root)
        else:
            user = os.environ.get("USER", "")
            for base in (f"/media/{user}", f"/run/media/{user}", "/media", "/Volumes"):
                if os.path.isdir(base):
                    for d in sorted(os.listdir(base)):
                        full = os.path.join(base, d)
                        if os.path.ismount(full) and full != "/Volumes/Macintosh HD":
                            out.append(full)
    except Exception:
        pass
    seen = []
    for t in out:
        if t not in seen:
            seen.append(t)
    return seen


def usb_backup(c, target):
    folder = os.path.join(target, USB_DIR)
    os.makedirs(folder, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y-%m-%d_%H%M")
    path = os.path.join(folder, f"sundayschool-{stamp}.db")
    snapshot(path)
    if os.path.exists(CONF_PATH):                      # the admin PIN, so a restore keeps it
        import shutil
        shutil.copy2(CONF_PATH, os.path.join(folder, "config.json"))
    with open(os.path.join(folder, "READ-ME.txt"), "w", encoding="utf-8") as f:
        f.write("Sunday School Manager - backup copies (newest = latest date).\n"
                "TO RESTORE: stop the server, copy the newest sundayschool-....db to\n"
                f"   {DB_PATH}\n"
                "and rename it to sundayschool.db (copy config.json next to it too), then start the server.\n\n"
                "These files contain children's personal data. Keep this USB stick in a locked place.\n"
                "ይህ ፍላሽ የሕፃናትን የግል መረጃ ይዟል፤ በተቆለፈ ቦታ ያስቀምጡት።\n")
    files = sorted(f for f in os.listdir(folder) if f.startswith("sundayschool-") and f.endswith(".db"))
    for f in files[:-USB_KEEP]:
        os.remove(os.path.join(folder, f))
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('usb_last',?)", (now,))
    c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('usb_where',?)", (folder,))
    c.commit()
    return {"ok": True, "where": folder, "file": os.path.basename(path), "when": now}


def usb_days_since(c):
    last = get_setting(c, "usb_last", "")
    if not last:
        return None
    try:
        return (dt.date.today() - dt.date.fromisoformat(last[:10])).days
    except ValueError:
        return None


def auto_usb_backup():
    """Called every hour: if a USB stick (or the chosen folder) is there and the last copy is a week old, copy."""
    c = db()
    try:
        days = usb_days_since(c)
        every = int(get_setting(c, "usb_every", "7") or 7)
        if days is not None and days < every:
            return
        for t in usb_targets(c):
            try:
                r = usb_backup(c, t)
                print(f"\n  Backup copied to {r['where']} ({r['file']})")
                return
            except Exception as e:
                print(f"\n  Could not back up to {t}: {e}")
    finally:
        c.close()


# ---------------------------------------------------------------- updates
# An update is the same zip you install by hand. It can come from the internet (when there is internet)
# or from a file the admin chooses. Data is never touched: it lives in SundaySchool-Data.
UPDATE_PARTS = ("server.py", "public/", "tools/", "single-file-version/")
UPDATE_EXT = (".bat", ".sh", ".txt", ".md", ".csv")
PENDING = os.path.join(DATA, "update-pending.json")
APP_BACKUPS = os.path.join(DATA, "app-backups")


def vtuple(v):
    try:
        return tuple(int(x) for x in str(v).strip().split("."))
    except ValueError:
        return (0,)


def update_allowed(name):
    if name.startswith(UPDATE_PARTS):
        return True
    return "/" not in name and name.endswith(UPDATE_EXT)


def read_update_zip(blob):
    """Check a release zip and return (version, {relative path: bytes})."""
    import zipfile, re
    try:
        z = zipfile.ZipFile(io.BytesIO(blob))
    except zipfile.BadZipFile:
        raise ApiError("This is not a Sunday School update (.zip) file")
    names = [n for n in z.namelist() if not n.endswith("/")]
    roots = [n[: -len("server.py")] for n in names if n.endswith("server.py") and n.count("/") <= 1]
    if len(roots) != 1:
        raise ApiError("This zip does not contain the Sunday School app (server.py missing)")
    root = roots[0]
    files = {}
    for n in names:
        if not n.startswith(root):
            continue
        rel = n[len(root):]
        norm = os.path.normpath(rel).replace("\\", "/")
        if norm.startswith(("../", "/")) or ".." in norm.split("/") or ":" in norm:
            raise ApiError("Unsafe file name in the update: " + n)
        if update_allowed(norm):
            files[norm] = z.read(n)
    if "server.py" not in files or "public/index.html" not in files:
        raise ApiError("This zip is not a complete Sunday School app")
    src = files["server.py"].decode("utf-8", "replace")
    m = re.search(r'^VERSION = "([0-9.]+)"', src, re.M)
    if not m:
        raise ApiError("The update has no version number")
    try:
        compile(src, "server.py", "exec")            # never install a server that can't even start
    except SyntaxError as e:
        raise ApiError(f"The update is damaged (server.py line {e.lineno})")
    return m.group(1), files


def install_update(blob, allow_same=False):
    import zipfile
    version, files = read_update_zip(blob)
    if vtuple(version) < vtuple(VERSION) or (vtuple(version) == vtuple(VERSION) and not allow_same):
        raise ApiError(f"You already have version {VERSION}; this file is version {version}")
    # 1) safety copies: the data and the current app
    os.makedirs(APP_BACKUPS, exist_ok=True)
    snapshot(os.path.join(BACKUPS, f"before-update-{dt.datetime.now():%Y-%m-%d_%H%M%S}.db"))
    keep = os.path.join(APP_BACKUPS, f"app-{VERSION}-{dt.datetime.now():%Y%m%d%H%M%S}.zip")
    with zipfile.ZipFile(keep, "w", zipfile.ZIP_DEFLATED) as zf:
        for folder, _, fs in os.walk(BASE):
            for f in fs:
                full = os.path.join(folder, f)
                rel = os.path.relpath(full, BASE).replace("\\", "/")
                if update_allowed(rel) and "__pycache__" not in rel:
                    zf.write(full, rel)
    olds = sorted(f for f in os.listdir(APP_BACKUPS) if f.endswith(".zip"))
    for f in olds[:-5]:
        os.remove(os.path.join(APP_BACKUPS, f))
    # 2) write the new files (each one replaced in a single step)
    for rel, data in files.items():
        dest = os.path.join(BASE, *rel.split("/"))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        tmp = dest + ".new"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, dest)
    # 3) remember the way back, in case the new version does not start
    with open(PENDING, "w", encoding="utf-8") as f:
        json.dump({"from": VERSION, "to": version, "app_backup": keep, "app_dir": BASE,
                   "when": dt.datetime.now().isoformat(timespec="seconds")}, f)
    try:
        os.remove(os.path.join(DATA, "update-failed.json"))
    except OSError:
        pass
    threading.Timer(1.5, restart_self).start()
    return {"ok": True, "installed": version, "previous": VERSION}


def restart_self():
    print("\n  Update installed. Restarting with the new version...")
    if os.environ.get("SS_LAUNCHER"):
        os._exit(3)                                   # START-Windows.bat / start-linux-mac.sh start it again
    args = [a for a in sys.argv if a != "--no-browser"] + ["--no-browser"]
    os.execv(sys.executable, [sys.executable] + args)


def fetch_url(url, limit=40_000_000):
    import urllib.request
    if not url.lower().startswith("https://"):
        raise ApiError("The update address must start with https://")
    req = urllib.request.Request(url, headers={"User-Agent": f"SundaySchoolManager/{VERSION}"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            data = r.read(limit + 1)
    except Exception as e:
        raise ApiError(f"No internet, or the update address can't be reached ({e.__class__.__name__})", 502)
    if len(data) > limit:
        raise ApiError("The download is too large")
    return data


def check_update(c):
    url = get_setting(c, "update_url", "")
    if not url:
        raise ApiError("No update address is set yet (Settings → Updates)")
    try:
        info = json.loads(fetch_url(url, 200_000).decode("utf-8"))
        latest = str(info["version"])
    except ApiError:
        raise
    except Exception:
        raise ApiError("The update address did not return update information")
    newer = vtuple(latest) > vtuple(VERSION)
    from urllib.parse import urljoin
    zip_url = urljoin(url, str(info.get("url", "") or "sunday-school.zip"))   # may be just "sunday-school.zip"
    return {"current": VERSION, "latest": latest, "newer": newer, "notes": str(info.get("notes", ""))[:2000],
            "url": zip_url, "sha256": info.get("sha256", "")}


def update_status(c):
    pending_failed = ""
    try:          # written by tools/run.py when a new version would not start and the old one was put back
        with open(os.path.join(DATA, "update-failed.json"), encoding="utf-8") as f:
            x = json.load(f)
        pending_failed = f"{x.get('to')} → {x.get('from')} ({x.get('when')})"
    except (OSError, ValueError):
        pass
    return {"version": VERSION, "update_url": get_setting(c, "update_url", ""),
            "usb_last": get_setting(c, "usb_last", ""), "usb_where": get_setting(c, "usb_where", ""),
            "usb_days": usb_days_since(c), "usb_every": int(get_setting(c, "usb_every", "7") or 7),
            "backup_folder": get_setting(c, "backup_folder", ""), "drives": usb_targets(c),
            "data_dir": DATA, "rolled_back": pending_failed}

def backup_loop():
    while True:
        try:
            daily_backup()
        except Exception:
            traceback.print_exc()
        try:
            auto_usb_backup()
        except Exception:
            traceback.print_exc()
        time.sleep(3600)


def address_watch(port):
    """Hotspots often give the computer a NEW address after the internet or Wi-Fi goes off and on.
    Print the new address so people don't keep typing the old one."""
    last = lan_ips()
    while True:
        time.sleep(10)
        try:
            now = lan_ips()
            if now != last:
                print("\n  " + "!" * 58)
                if now:
                    print("  THE NETWORK ADDRESS CHANGED. Phones must now open:")
                    for ip in now:
                        print(f"     http://{ip}:{port}")
                else:
                    print("  No network right now. Connect this computer to the Wi-Fi / hotspot.")
                print("  " + "!" * 58)
                last = now
        except Exception:
            pass


def rows(cur):
    return [dict(r) for r in cur.fetchall()]


def clean(v):
    if isinstance(v, str):
        v = v.strip()
        return v or None
    return v


def valid_date(s, name="date"):
    try:
        dt.date.fromisoformat(s)
        return s
    except Exception:
        raise ApiError(f"invalid {name} (use YYYY-MM-DD)")


def to_int(v, name):
    v = clean(v)
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        raise ApiError(f"{name} must be a number")


def get_setting(c, key, default=""):
    r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def student_values(b):
    v = {k: clean(b.get(k)) for k in STUDENT_FIELDS}
    if not v["full_name"]:
        raise ApiError("Full name is required")
    v["birth_year"] = to_int(v["birth_year"], "Birth year")
    v["active"] = 0 if b.get("active") in (0, "0", False, "false") else 1
    v["grade"] = to_int(v["grade"], "Grade")
    if v["grade"] is not None and not 1 <= v["grade"] <= 12:
        raise ApiError("Grade must be 1-12")
    v["consent"] = 1 if b.get("consent") in (1, "1", True, "true", "yes", "Yes", "አዎ") else 0
    if v["birth_date"]:                       # full birth date (stored G.C.; the app shows it in E.C. too)
        valid_date(v["birth_date"], "birth date")
        v["birth_year"] = int(v["birth_date"][:4])
    return v


def public_student(r):
    d = dict(r)
    d["has_password"] = bool(d.pop("pw_hash", None))
    d.pop("pw_salt", None)
    return d


def hash_student_pw(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt.encode(), 60_000).hex()


def float_or_none(v, name):
    v = clean(v) if isinstance(v, str) else v
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        raise ApiError(f"{name} must be a number")


def mt_test_values(b):
    v = {k: clean(b.get(k)) for k in ("title", "subject", "term", "date")}
    if not v["title"]:
        raise ApiError("Title is required")
    if v["date"]:
        valid_date(v["date"])
    v["grade"] = to_int(b.get("grade"), "Grade")
    if v["grade"] is None or not 1 <= v["grade"] <= 12:
        raise ApiError("Grade must be 1-12")
    v["max_score"] = float_or_none(b.get("max_score"), "Max score") or 100.0
    if v["max_score"] <= 0:
        raise ApiError("Max score must be more than 0")
    return v


def dept_values(b):
    v = {k: clean(b.get(k)) for k in ("name", "leader", "description")}
    if not v["name"]:
        raise ApiError("Name is required")
    v["active"] = 0 if b.get("active") in (0, "0", False, "false") else 1
    return v


def import_single(c, D):
    """Replace all data with a backup (.json) made by the single-file version (SundaySchool.html)."""
    if not isinstance(D, dict) or not isinstance(D.get("students"), list) or not D.get("settings"):
        raise ApiError("This is not a Sunday School backup file")
    snapshot(os.path.join(BACKUPS, f"before-import-{dt.datetime.now():%Y-%m-%d_%H%M%S}.db"))   # safety copy
    for tbl in ("dept_attendance", "dept_members", "departments", "mt_scores", "mt_tests", "attendance", "announcements", "programs", "students"):
        c.execute(f"DELETE FROM {tbl}")
    name = (D.get("settings") or {}).get("school_name")
    if name:
        c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('school_name',?)", (name,))
    n = {"students": 0}
    for st in D.get("students", []):
        cols = ["id"] + STUDENT_FIELDS + ["created_at", "pw_hash", "pw_salt"]
        vals = [st.get("id")] + [st.get(k) for k in STUDENT_FIELDS] + [st.get("created_at"), None, None]
        vals[cols.index("active")] = 0 if st.get("active") in (0, False) else 1
        c.execute(f"INSERT INTO students({','.join(cols)}) VALUES({','.join('?' * len(cols))})", vals)
        n["students"] += 1
    ids = {r[0] for r in c.execute("SELECT id FROM students")}
    for k, status in (D.get("attendance") or {}).items():
        sid, date = k.split("|", 1)
        if int(sid) in ids:
            c.execute("INSERT OR REPLACE INTO attendance(student_id,date,status,by_self) VALUES(?,?,?,?)",
                      (int(sid), date, status, 1 if (D.get("att_self") or {}).get(k) else 0))
    for p in D.get("programs", []):
        cols = ["id"] + PROGRAM_FIELDS
        c.execute(f"INSERT INTO programs({','.join(cols)}) VALUES({','.join('?' * len(cols))})", [p.get(k) for k in cols])
    for a in D.get("announcements", []):
        c.execute("INSERT INTO announcements(id,text,active,created_at) VALUES(?,?,?,?)",
                  (a.get("id"), a.get("text"), 1 if a.get("active") else 0, a.get("created_at")))
    for t in D.get("mt_tests", []):
        c.execute("INSERT INTO mt_tests(id,grade,title,subject,term,date,max_score) VALUES(?,?,?,?,?,?,?)",
                  (t["id"], t["grade"], t["title"], t.get("subject"), t.get("term"), t.get("date"), t.get("max_score") or 100))
    tids = {r[0] for r in c.execute("SELECT id FROM mt_tests")}
    for k, sc in (D.get("mt_scores") or {}).items():
        tid, sid = (int(x) for x in k.split("|"))
        if tid in tids and sid in ids:
            c.execute("INSERT OR REPLACE INTO mt_scores(test_id,student_id,score) VALUES(?,?,?)", (tid, sid, sc))
    if D.get("depts"):
        for d in D["depts"]:
            c.execute("INSERT INTO departments(id,name,leader,description,active,sort) VALUES(?,?,?,?,?,?)",
                      (d["id"], d["name"], d.get("leader"), d.get("description"), 1 if d.get("active", 1) else 0, d.get("sort") or 0))
    else:
        c.executemany("INSERT INTO departments(name, sort) VALUES(?,?)", [(f"ክፍል {i}", i) for i in range(1, DEFAULT_DEPTS + 1)])
    dids = {r[0] for r in c.execute("SELECT id FROM departments")}
    for k, v in (D.get("dept_members") or {}).items():
        did, sid = (int(x) for x in k.split("|"))
        if did in dids and sid in ids:
            c.execute("INSERT OR REPLACE INTO dept_members(dept_id,student_id,role) VALUES(?,?,?)", (did, sid, (v or {}).get("role")))
    for k, st in (D.get("dept_attendance") or {}).items():
        did, sid, date = k.split("|", 2)
        if int(did) in dids and int(sid) in ids:
            c.execute("INSERT OR REPLACE INTO dept_attendance(dept_id,student_id,date,status) VALUES(?,?,?,?)", (int(did), int(sid), date, st))
    return {"ok": True, "students": n["students"],
            "programs": len(D.get("programs", [])), "tests": len(D.get("mt_tests", []))}


def export_all(c):
    """All data as JSON — the same format as SundaySchool.html and the online version (move data anywhere)."""
    D = {"v": 1, "source": "server", "settings": {"school_name": get_setting(c, "school_name")}}
    D["students"] = []
    for r in c.execute("SELECT * FROM students ORDER BY id"):
        d = dict(r); d.pop("pw_hash", None); d.pop("pw_salt", None); D["students"].append(d)
    D["attendance"], D["att_self"] = {}, {}
    for r in c.execute("SELECT * FROM attendance"):
        k = f"{r['student_id']}|{r['date']}"
        D["attendance"][k] = r["status"]
        if r["by_self"]:
            D["att_self"][k] = 1
    D["programs"] = rows(c.execute("SELECT * FROM programs ORDER BY id"))
    D["announcements"] = rows(c.execute("SELECT * FROM announcements ORDER BY id"))
    D["mt_tests"] = rows(c.execute("SELECT * FROM mt_tests ORDER BY id"))
    D["mt_scores"] = {f"{r[0]}|{r[1]}": r[2] for r in c.execute("SELECT test_id, student_id, score FROM mt_scores")}
    D["depts"] = rows(c.execute("SELECT * FROM departments ORDER BY sort, id"))
    D["dept_members"] = {f"{r[0]}|{r[1]}": {"role": r[2]} for r in c.execute("SELECT dept_id, student_id, role FROM dept_members")}
    D["dept_attendance"] = {f"{r[0]}|{r[1]}|{r[2]}": r[3] for r in c.execute("SELECT dept_id, student_id, date, status FROM dept_attendance")}
    ids = [x["id"] for k in ("students", "programs", "announcements", "mt_tests", "depts") for x in D[k]]
    D["nextId"] = (max(ids) if ids else 0) + 1
    return D


def mt_rank(students, tests, scores):
    """Total of all tests (a missing score counts as 0) -> percent -> rank 1,2,2,4…"""
    mx = sum(t["max_score"] for t in tests)
    res = []
    for s in students:
        vals = [scores.get(f"{t['id']}|{s['id']}") for t in tests]
        tot = sum(v or 0 for v in vals)
        res.append({"id": s["id"], "total": round(tot, 2), "max": mx, "taken": sum(v is not None for v in vals),
                    "pct": round(100 * tot / mx, 1) if mx else None, "rank": None})
    if mx:
        prev, rank = None, 0
        for i, r in enumerate(sorted(res, key=lambda r: -r["total"])):
            if r["total"] != prev:
                rank, prev = i + 1, r["total"]
            r["rank"] = rank
    return res


def mt_grade_data(c, grade, term=None):
    studs = [public_student(r) for r in c.execute(
        "SELECT * FROM students WHERE active=1 AND grade=? ORDER BY full_name COLLATE NOCASE", (grade,))]
    all_tests = rows(c.execute("SELECT * FROM mt_tests WHERE grade=? ORDER BY COALESCE(date,''), id", (grade,)))
    terms = sorted({t["term"] for t in all_tests if t["term"]})
    tests = [t for t in all_tests if not term or t["term"] == term]
    scores = {}
    if tests:
        ids = [t["id"] for t in tests]
        for tid, sid, sc in c.execute(
                f"SELECT test_id, student_id, score FROM mt_scores WHERE test_id IN ({','.join('?' * len(ids))})", ids):
            scores[f"{tid}|{sid}"] = sc
    codes = code_status(c)
    for st in studs:
        st["code_until"] = codes.get(st["id"])
    return {"grade": grade, "term": term or "", "terms": terms, "students": studs, "tests": tests,
            "scores": scores, "results": mt_rank(studs, tests, scores)}


def program_values(b):
    v = {k: clean(b.get(k)) for k in PROGRAM_FIELDS}
    if not v["title"]:
        raise ApiError("Title is required")
    v["repeat_weekday"] = to_int(v["repeat_weekday"], "Repeat day")
    if v["repeat_weekday"] is not None:
        if not 0 <= v["repeat_weekday"] <= 6:
            raise ApiError("Repeat day must be 0-6")
        v["date"] = None
    else:
        if not v["date"]:
            raise ApiError("Date is required for a one-time program")
        valid_date(v["date"])
    return v


def programs_for(c, date_str, class_name=None):
    d = dt.date.fromisoformat(date_str)
    sql = ("SELECT * FROM programs WHERE (date=? OR repeat_weekday=?)")
    args = [date_str, d.weekday()]
    if class_name:
        sql += " AND (class_name IS NULL OR class_name='' OR class_name=?)"
        args.append(class_name)
    sql += " ORDER BY COALESCE(start_time,'99:99'), title"
    return rows(c.execute(sql, args))


def lan_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            ips.add(ip)
    except Exception:
        pass
    # 169.254.x.x = "no address from the router/hotspot" - phones can never use it
    return sorted(ip for ip in ips if not ip.startswith(("127.", "169.254.")))


def csv_safe(v):
    """Stop Excel from running a cell as a formula (CSV injection), e.g. a name typed as =HYPERLINK(...)."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v


def csv_bytes(header, data):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(header)
    w.writerows([[csv_safe(x) for x in row] for row in data])
    return buf.getvalue().encode("utf-8-sig")  # BOM so Excel shows Amharic correctly


# ---------------------------------------------------------------- HTTP handler
class Handler(BaseHTTPRequestHandler):
    server_version = "SundaySchool/1.0"

    def log_message(self, fmt, *args):
        pass  # keep the console clean

    # ---- responses
    def send_bytes(self, data, ctype, code=200, filename=None, cache=False):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=300" if cache else "no-store")
        self.send_header("X-Rev", str(REV["v"]))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
                         "img-src 'self' data:; connect-src 'self'; manifest-src 'self'; frame-ancestors 'none'; "
                         "form-action 'self'; base-uri 'none'")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, obj, code=200):
        self.send_bytes(json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                        "application/json; charset=utf-8", code)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 40_000_000:
            raise ApiError("request too large", 413)
        raw = self.rfile.read(n) if n else b""
        try:
            return json.loads(raw.decode("utf-8")) if raw else {}
        except ValueError:
            raise ApiError("invalid JSON")

    def ip(self):
        return self.client_address[0]

    def admin_token(self):
        return self.headers.get("X-Token", "")

    def authed(self, q=None):
        c = db()
        try:
            return get_session(c, self.admin_token(), "admin") is not None
        finally:
            c.close()

    # ---- routing
    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def do_PUT(self):
        self.route("PUT")

    def do_DELETE(self):
        self.route("DELETE")

    def route(self, method):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path.startswith("/api/"):
                parts = [p for p in u.path[5:].split("/") if p]
                return self.api(method, parts, q)
            if method != "GET":
                raise ApiError("not found", 404)
            return self.static(u.path)
        except ApiError as e:
            self.send_json({"error": str(e)}, e.code)
        except sqlite3.IntegrityError as e:
            self.send_json({"error": f"database rule: {e}"}, 400)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            traceback.print_exc()
            self.send_json({"error": f"server error: {e}"}, 500)

    def static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        elif path in ("/display", "/display/"):
            path = "/display.html"
        full = os.path.normpath(os.path.join(PUBLIC, path.lstrip("/")))
        inside = os.path.commonpath([full, PUBLIC]) == PUBLIC
        if not inside or os.path.basename(full).startswith((".", "_")) or not os.path.isfile(full):
            raise ApiError("not found", 404)
        # Fixed table first: on some Windows PCs the registry maps .js to text/plain, and with
        # "nosniff" the browser would then refuse to run the app (blank page).
        ctype = FIXED_TYPES.get(os.path.splitext(full)[1].lower()) or mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "application/json", "application/manifest+json"):
            ctype += "; charset=utf-8"
        with open(full, "rb") as f:
            self.send_bytes(f.read(), ctype)

    # ---- API
    def api(self, m, parts, q):
        r = parts[0] if parts else ""
        sub = parts[1] if len(parts) > 1 else None
        rid = int(sub) if sub and sub.isdigit() else None

        if r == "portal":                                # members: one-time code -> only their own data
            return self.portal(m, sub, q)

        if r == "login" and m == "POST":
            key = "pin:" + self.ip()
            wait = locked_for(key)
            if wait:
                raise ApiError(f"Too many wrong tries. Try again in {wait // 60 + 1} min.", 429)
            pin = str(self.body().get("pin", ""))
            if hmac.compare_digest(hash_pin(pin, CONF["pin_salt"]), CONF["pin_hash"]):
                clear_fails(key)
                c = db()
                try:
                    tok = new_session(c, "admin")
                    c.commit()
                finally:
                    c.close()
                return self.send_json({"token": tok, "default_pin": CONF.get("default_pin", False)})
            record_fail(key, 5, 300)       # 5 wrong PINs -> this device is locked for 5 minutes
            time.sleep(0.8)
            raise ApiError("Wrong PIN", 403)

        if r == "logout" and m == "POST":
            c = db()
            try:
                c.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash(self.admin_token()),))
                c.commit()
            finally:
                c.close()
            return self.send_json({"ok": True})

        if r == "changes" and m == "GET":
            return self.send_json({"v": REV["v"]})

        self.is_admin = self.authed()
        public = m == "GET" and r in ("info", "display")
        if not public and not self.is_admin:
            raise ApiError("login required", 401)
        if CONF.get("default_pin") and m != "GET" and r not in ("pin", "logout"):
            raise ApiError("Change the default PIN 1234 first (Settings)", 403)

        c = db()
        try:
            result = self.dispatch(c, m, r, sub, rid, q)
            c.commit()
        finally:
            c.close()
        if m != "GET":
            bump_rev()          # tell other browsers that data changed
        if result is not None:
            self.send_json(result)

    # ---------------- member portal (one-time code) ----------------
    def portal(self, m, sub, q):
        c = db()
        try:
            if sub == "login" and m == "POST":
                b = self.body()
                try:
                    sid = int(str(b.get("id", "")).strip().lstrip("#"))
                except ValueError:
                    sid = -1
                code = "".join(ch for ch in str(b.get("code", "")) if ch.isalnum())
                for key in ("code:" + str(sid), "codeip:" + self.ip()):
                    wait = locked_for(key)
                    if wait:
                        raise ApiError(f"Too many wrong tries. Try again in {wait // 60 + 1} min.", 429)
                s = c.execute("SELECT * FROM students WHERE id=? AND active=1", (sid,)).fetchone()
                hit = None
                if s:
                    for row in c.execute("SELECT * FROM access_codes WHERE student_id=? AND used IS NULL AND expires>?",
                                         (sid, time.time())):
                        if hmac.compare_digest(hash_code(code, row["salt"]), row["code_hash"]):
                            hit = row
                            break
                if not hit:
                    record_fail("code:" + str(sid), 5, 900)     # 5 wrong codes for one ID -> locked 15 min
                    record_fail("codeip:" + self.ip(), 20, 900)  # 20 wrong codes from one device -> locked 15 min
                    time.sleep(0.8)
                    raise ApiError("Wrong ID number or code, or the code was already used", 403)
                clear_fails("code:" + str(sid))
                c.execute("UPDATE access_codes SET used=? WHERE id=?", (time.time(), hit["id"]))   # ONE-TIME: burn it
                tok = new_session(c, "member", sid)
                c.commit()
                return self.send_json({"token": tok, "minutes": MEMBER_TTL // 60})

            sess = get_session(c, self.headers.get("X-Member", ""), "member")
            if not sess:
                raise ApiError("Your session has ended. Ask the admin for a new one-time code.", 401)
            sid = sess["student_id"]
            s = c.execute("SELECT * FROM students WHERE id=? AND active=1", (sid,)).fetchone()
            if not s:
                raise ApiError("Your session has ended. Ask the admin for a new one-time code.", 401)
            if sub == "logout" and m == "POST":
                c.execute("DELETE FROM sessions WHERE token_hash=?", (sess["token_hash"],))
                c.commit()
                return self.send_json({"ok": True})
            if sub == "checkin" and m == "POST":
                if not checkin_state(c)["open"]:
                    raise ApiError("Self check-in is closed right now", 403)
                wait = locked_for("room:" + str(sid))
                if wait:
                    raise ApiError(f"Too many wrong tries. Try again in {wait // 60 + 1} min.", 429)
                room = "".join(ch for ch in str(self.body().get("room", "")) if ch.isdigit())
                if not hmac.compare_digest(room, get_setting(c, "checkin_code", "")):   # proves you are in the room
                    record_fail("room:" + str(sid), 5, 900)
                    raise ApiError("Wrong room code. Look at the screen or ask the teacher.", 403)
                today = dt.date.today().isoformat()
                c.execute("INSERT OR IGNORE INTO attendance(student_id,date,status,by_self) VALUES(?,?,'P',1)", (sid, today))
                c.commit()
                bump_rev()
                return self.send_json(self.portal_me(c, s, sess, q.get("term")))
            if sub == "me" and m == "GET":
                return self.send_json(self.portal_me(c, s, sess, q.get("term")))
            raise ApiError("not found", 404)
        finally:
            c.close()

    def portal_me(self, c, s, sess, term):
        sid, today = s["id"], dt.date.today()
        mark = c.execute("SELECT status, by_self FROM attendance WHERE student_id=? AND date=?", (sid, today.isoformat())).fetchone()
        since = (today - dt.timedelta(days=90)).isoformat()
        counts = dict(c.execute("SELECT status, COUNT(*) FROM attendance WHERE student_id=? AND date>=? GROUP BY status",
                                (sid, since)).fetchall())
        recent = rows(c.execute("SELECT date, status FROM attendance WHERE student_id=? ORDER BY date DESC LIMIT 8", (sid,)))
        out = {"student": {"id": sid, "full_name": s["full_name"], "christian_name": s["christian_name"],
                           "grade": s["grade"], "class_name": s["class_name"]},
               "school_name": get_setting(c, "school_name"),
               "expires": sess["expires"] - time.time(),
               "checkin": {**checkin_state(c), "today": today.isoformat(),
                           "status": mark["status"] if mark else None, "by_self": bool(mark and mark["by_self"])},
               "attendance": {"since": since, "counts": counts, "recent": recent}, "result": None}
        if s["grade"]:
            data = mt_grade_data(c, s["grade"], clean(term))
            me = next(r for r in data["results"] if r["id"] == sid)
            out["result"] = {"grade": s["grade"], "term": data["term"], "terms": data["terms"], "of": len(data["students"]),
                             "tests": [{"title": t["title"], "subject": t["subject"], "term": t["term"], "date": t["date"],
                                        "max_score": t["max_score"], "score": data["scores"].get(f"{t['id']}|{sid}")}
                                       for t in data["tests"]],
                             "total": me["total"], "max": me["max"], "pct": me["pct"], "rank": me["rank"]}
        return out

    def dispatch(self, c, m, r, sub, rid, q):
        # ---------- info / settings
        if r == "info":
            out = {"school_name": get_setting(c, "school_name")}
            if self.is_admin:       # network details and PIN status only for the admin
                out.update({"ips": lan_ips(), "port": self.server.server_address[1],
                            "default_pin": CONF.get("default_pin", False),
                            "code_days": int(get_setting(c, "code_days", str(CODE_DAYS_DEFAULT)) or CODE_DAYS_DEFAULT)})
            return out

        if r == "settings" and m == "POST":
            b = self.body()
            name = clean(b.get("school_name"))
            if name:
                c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('school_name',?)", (name,))
            if b.get("code_days") not in (None, ""):
                days = to_int(b.get("code_days"), "Days")
                if not 1 <= days <= 365:
                    raise ApiError("Days must be 1-365")
                c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('code_days',?)", (str(days),))
            return {"ok": True}

        if r == "sessions" and sub == "revoke" and m == "POST":     # log out every other device
            c.execute("DELETE FROM sessions WHERE token_hash<>?", (token_hash(self.admin_token()),))
            return {"ok": True}

        if r == "pin" and m == "POST":
            b = self.body()
            old, new = str(b.get("old", "")), str(b.get("new", ""))
            if not hmac.compare_digest(hash_pin(old, CONF["pin_salt"]), CONF["pin_hash"]):
                raise ApiError("Current PIN is wrong", 403)
            if len(new) < 6:
                raise ApiError("New PIN must be at least 6 characters")
            if new in ("123456", "000000", "111111", "654321", "123123") or new == old:
                raise ApiError("Choose a less obvious PIN")
            with conf_lock:
                CONF["pin_salt"] = secrets.token_hex(8)
                CONF["pin_hash"] = hash_pin(new, CONF["pin_salt"])
                CONF["default_pin"] = False
                save_conf(CONF)
            c.execute("DELETE FROM sessions WHERE kind='admin'")     # logs out every other device
            return {"ok": True, "token": new_session(c, "admin")}

        # ---------- one-time codes for members
        if r == "codes" and m == "POST":
            days = int(get_setting(c, "code_days", str(CODE_DAYS_DEFAULT)) or CODE_DAYS_DEFAULT)
            now, out = time.time(), []
            ids = [int(x) for x in self.body().get("student_ids", [])]
            for sid in ids:
                st = c.execute("SELECT id, full_name FROM students WHERE id=? AND active=1", (sid,)).fetchone()
                if not st:
                    continue
                c.execute("DELETE FROM access_codes WHERE student_id=? AND used IS NULL", (sid,))   # older codes stop working
                code = f"{secrets.randbelow(900000) + 100000}"
                salt = secrets.token_hex(8)
                c.execute("INSERT INTO access_codes(student_id, code_hash, salt, created, expires) VALUES(?,?,?,?,?)",
                          (sid, hash_code(code, salt), salt, now, now + days * 86400))
                out.append({"id": sid, "full_name": st["full_name"], "code": code,
                            "expires": dt.datetime.fromtimestamp(now + days * 86400).strftime("%Y-%m-%d %H:%M")})
            return out

        # ---------- self check-in window (members mark their own attendance)
        if r == "checkin":
            if m == "POST":
                minutes = to_int(self.body().get("minutes"), "Minutes") or 0
                until = (dt.datetime.now() + dt.timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M:%S") if minutes > 0 else ""
                c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('checkin_until',?)", (until,))
                if minutes > 0:      # a new 4-digit room code each time check-in is opened
                    c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('checkin_code',?)", (f"{secrets.randbelow(9000) + 1000}",))
            return {**checkin_state(c, reveal=True), "display_key": display_key(c)}

        # ---------- classes
        if r == "classes":
            cur = c.execute("""SELECT DISTINCT class_name FROM students WHERE class_name IS NOT NULL AND class_name<>''
                               UNION SELECT DISTINCT class_name FROM programs WHERE class_name IS NOT NULL AND class_name<>''
                               ORDER BY 1""")
            return [x[0] for x in cur.fetchall()]

        # ---------- students
        if r == "students":
            if m == "GET":
                sql, args = "SELECT * FROM students WHERE 1=1", []
                if q.get("inactive") != "1":
                    sql += " AND active=1"
                if q.get("class"):
                    sql += " AND class_name=?"
                    args.append(q["class"])
                if q.get("q"):
                    like = f"%{q['q']}%"
                    sql += " AND (full_name LIKE ? OR christian_name LIKE ? OR parent_name LIKE ? OR phone LIKE ?)"
                    args += [like] * 4
                if q.get("grade"):
                    sql += " AND grade=?"
                    args.append(q["grade"])
                sql += " ORDER BY class_name COLLATE NOCASE, full_name COLLATE NOCASE"
                out = [public_student(r) for r in c.execute(sql, args)]
                depts = {}
                for sid, name in c.execute("SELECT dm.student_id, d.name FROM dept_members dm JOIN departments d ON d.id=dm.dept_id "
                                           "ORDER BY d.sort, d.id"):
                    depts.setdefault(sid, []).append(name)
                codes = code_status(c)
                for st in out:
                    st["depts"] = depts.get(st["id"], [])
                    st["code_until"] = codes.get(st["id"])
                return out
            if m == "POST":
                v = student_values(self.body())
                cur = c.execute(f"INSERT INTO students({','.join(v)}) VALUES({','.join('?' * len(v))})",
                                list(v.values()))
                return {"id": cur.lastrowid}
            if m == "PUT" and rid:
                v = student_values(self.body())
                c.execute(f"UPDATE students SET {','.join(k + '=?' for k in v)} WHERE id=?", [*v.values(), rid])
                return {"ok": True}
            if m == "DELETE" and rid:
                c.execute("DELETE FROM students WHERE id=?", (rid,))
                return {"ok": True}

        # ---------- መሠረተ ትምህርት (grades 1-12)
        if r == "mt":
            parts = self.path.split("?")[0].split("/")[3:]   # after /api/mt/
            what = parts[0] if parts else ""
            arg = parts[1] if len(parts) > 1 else ""
            if what == "grades" and m == "GET":
                counts = dict(c.execute("SELECT grade, COUNT(*) FROM students WHERE active=1 AND grade IS NOT NULL GROUP BY grade").fetchall())
                tests = dict(c.execute("SELECT grade, COUNT(*) FROM mt_tests GROUP BY grade").fetchall())
                return [{"grade": g, "students": counts.get(g, 0), "tests": tests.get(g, 0)} for g in range(1, 13)]
            if what == "grade" and arg.isdigit() and m == "GET":
                return mt_grade_data(c, int(arg), q.get("term"))
            if what == "tests":
                if m == "POST":
                    v = mt_test_values(self.body())
                    cur = c.execute(f"INSERT INTO mt_tests({','.join(v)}) VALUES({','.join('?' * len(v))})", list(v.values()))
                    return {"id": cur.lastrowid}
                if m == "PUT" and arg.isdigit():
                    v = mt_test_values(self.body())
                    c.execute(f"UPDATE mt_tests SET {','.join(k + '=?' for k in v)} WHERE id=?", [*v.values(), int(arg)])
                    return {"ok": True}
                if m == "DELETE" and arg.isdigit():
                    c.execute("DELETE FROM mt_tests WHERE id=?", (int(arg),))
                    return {"ok": True}
            if what == "scores" and m == "POST":
                n = 0
                for rec in self.body().get("scores", []):
                    tid, sid = int(rec["test_id"]), int(rec["student_id"])
                    sc = float_or_none(rec.get("score"), "Score")
                    t = c.execute("SELECT max_score FROM mt_tests WHERE id=?", (tid,)).fetchone()
                    if not t:
                        continue
                    if sc is None:
                        c.execute("DELETE FROM mt_scores WHERE test_id=? AND student_id=?", (tid, sid))
                    else:
                        if sc < 0 or sc > t[0]:
                            raise ApiError(f"Score must be between 0 and {t[0]:g}")
                        c.execute("INSERT OR REPLACE INTO mt_scores(test_id,student_id,score) VALUES(?,?,?)", (tid, sid, sc))
                        n += 1
                return {"ok": True, "saved": n}
        # ---------- ክፍላት (departments) and their members
        if r == "depts":
            parts = self.path.split("?")[0].split("/")[3:]   # after /api/depts/
            did = int(parts[0]) if parts and parts[0].isdigit() else None
            if did is None:
                if m == "GET":
                    return rows(c.execute("""SELECT d.*, (SELECT COUNT(*) FROM dept_members dm JOIN students s ON s.id=dm.student_id
                                             WHERE dm.dept_id=d.id AND s.active=1) AS count
                                             FROM departments d ORDER BY d.active DESC, d.sort, d.id"""))
                if m == "POST":
                    v = dept_values(self.body())
                    v["sort"] = (c.execute("SELECT COALESCE(MAX(sort),0) FROM departments").fetchone()[0] or 0) + 1
                    cur = c.execute(f"INSERT INTO departments({','.join(v)}) VALUES({','.join('?' * len(v))})", list(v.values()))
                    return {"id": cur.lastrowid}
            elif len(parts) == 1:
                if m == "PUT":
                    v = dept_values(self.body())
                    c.execute(f"UPDATE departments SET {','.join(k + '=?' for k in v)} WHERE id=?", [*v.values(), did])
                    return {"ok": True}
                if m == "DELETE":
                    c.execute("DELETE FROM departments WHERE id=?", (did,))
                    return {"ok": True}
            elif parts[1] == "attendance":
                if m == "GET":
                    date = valid_date(q.get("date") or dt.date.today().isoformat())
                    return rows(c.execute("""SELECT s.id, s.full_name, s.christian_name, dm.role, da.status
                        FROM dept_members dm JOIN students s ON s.id=dm.student_id
                        LEFT JOIN dept_attendance da ON da.dept_id=dm.dept_id AND da.student_id=s.id AND da.date=?
                        WHERE dm.dept_id=? AND s.active=1 ORDER BY s.full_name COLLATE NOCASE""", (date, did)))
                if m == "POST":
                    b = self.body()
                    date = valid_date(b.get("date") or "")
                    n = 0
                    for rec in b.get("records", []):
                        sid, st = int(rec["student_id"]), (rec.get("status") or "").upper()
                        if st in STATUSES:
                            c.execute("INSERT OR REPLACE INTO dept_attendance(dept_id,student_id,date,status) VALUES(?,?,?,?)",
                                      (did, sid, date, st))
                            n += 1
                        else:
                            c.execute("DELETE FROM dept_attendance WHERE dept_id=? AND student_id=? AND date=?", (did, sid, date))
                    return {"ok": True, "saved": n}
            elif parts[1] == "report" and m == "GET":
                frm = valid_date(q.get("from") or "2000-01-01", "from")
                to = valid_date(q.get("to") or dt.date.today().isoformat(), "to")
                data = rows(c.execute("""SELECT s.id, s.full_name, s.christian_name, dm.role,
                        COALESCE(SUM(da.status='P'),0) present, COALESCE(SUM(da.status='L'),0) late,
                        COALESCE(SUM(da.status='A'),0) absent, COALESCE(SUM(da.status='E'),0) excused, COUNT(da.status) marked
                    FROM dept_members dm JOIN students s ON s.id=dm.student_id
                    LEFT JOIN dept_attendance da ON da.dept_id=dm.dept_id AND da.student_id=s.id AND da.date BETWEEN ? AND ?
                    WHERE dm.dept_id=? AND s.active=1 GROUP BY s.id ORDER BY s.full_name COLLATE NOCASE""", (frm, to, did)))
                meetings = [r[0] for r in c.execute("SELECT DISTINCT date FROM dept_attendance WHERE dept_id=? AND date BETWEEN ? AND ? "
                                                     "ORDER BY date DESC", (did, frm, to))]
                return {"from": frm, "to": to, "sessions": len(meetings), "meetings": meetings, "members": data}
            elif parts[1] == "members":
                sid = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None
                if m == "GET":
                    out = []
                    codes = code_status(c)
                    for row in c.execute("""SELECT s.*, dm.role FROM dept_members dm JOIN students s ON s.id=dm.student_id
                                            WHERE dm.dept_id=? AND s.active=1 ORDER BY s.full_name COLLATE NOCASE""", (did,)):
                        out.append({**public_student(row), "code_until": codes.get(row["id"])})
                    return out
                if m == "POST":
                    n = 0
                    for x in self.body().get("student_ids", []):
                        n += c.execute("INSERT OR IGNORE INTO dept_members(dept_id, student_id) VALUES(?,?)", (did, int(x))).rowcount
                    return {"ok": True, "added": n}
                if m == "PUT" and sid:
                    c.execute("UPDATE dept_members SET role=? WHERE dept_id=? AND student_id=?",
                              (clean(self.body().get("role")), did, sid))
                    return {"ok": True}
                if m == "DELETE" and sid:
                    c.execute("DELETE FROM dept_members WHERE dept_id=? AND student_id=?", (did, sid))
                    return {"ok": True}

        # ---------- attendance
        if r == "attendance":
            if m == "GET":
                date = valid_date(q.get("date") or dt.date.today().isoformat())
                sql = """SELECT s.id, s.full_name, s.christian_name, s.class_name, s.grade, a.status, a.by_self
                         FROM students s LEFT JOIN attendance a ON a.student_id=s.id AND a.date=?
                         WHERE s.active=1"""
                args = [date]
                if q.get("class"):
                    sql += " AND s.class_name=?"
                    args.append(q["class"])
                g = q.get("grade")
                if g == "none":
                    sql += " AND s.grade IS NULL"
                elif g and g.isdigit():
                    sql += " AND s.grade=?"
                    args.append(int(g))
                sql += " ORDER BY s.grade IS NULL, s.grade, s.full_name COLLATE NOCASE"
                return rows(c.execute(sql, args))
            if m == "POST":
                b = self.body()
                date = valid_date(b.get("date") or "")
                n = 0
                for rec in b.get("records", []):
                    sid, st = int(rec["student_id"]), (rec.get("status") or "").upper()
                    if st in STATUSES:
                        old = c.execute("SELECT status FROM attendance WHERE student_id=? AND date=?", (sid, date)).fetchone()
                        if not old or old[0] != st:     # keep the 📱 mark if the admin didn't change it
                            c.execute("INSERT OR REPLACE INTO attendance(student_id,date,status,by_self) VALUES(?,?,?,0)",
                                      (sid, date, st))
                        n += 1
                    else:
                        c.execute("DELETE FROM attendance WHERE student_id=? AND date=?", (sid, date))
                return {"ok": True, "saved": n}

        if r == "report":
            frm = valid_date(q.get("from") or "2000-01-01", "from")
            to = valid_date(q.get("to") or dt.date.today().isoformat(), "to")
            cls = q.get("class")
            g = q.get("grade")
            gsql = " AND s.grade IS NULL" if g == "none" else (" AND s.grade=?" if g and g.isdigit() else "")
            gargs = [int(g)] if g and g.isdigit() else []
            sql = """SELECT s.id, s.full_name, s.christian_name, s.class_name, s.grade,
                       COALESCE(SUM(a.status='P'),0) present, COALESCE(SUM(a.status='L'),0) late,
                       COALESCE(SUM(a.status='A'),0) absent, COALESCE(SUM(a.status='E'),0) excused,
                       COUNT(a.status) marked
                     FROM students s LEFT JOIN attendance a ON a.student_id=s.id AND a.date BETWEEN ? AND ?
                     WHERE s.active=1"""
            args = [frm, to]
            if cls:
                sql += " AND s.class_name=?"
                args.append(cls)
            sql += gsql
            args += gargs
            sql += " GROUP BY s.id ORDER BY s.grade IS NULL, s.grade, s.full_name COLLATE NOCASE"
            data = rows(c.execute(sql, args))
            dsql = "SELECT COUNT(DISTINCT a.date) FROM attendance a JOIN students s ON s.id=a.student_id WHERE a.date BETWEEN ? AND ?"
            dargs = [frm, to]
            if cls:
                dsql += " AND s.class_name=?"
                dargs.append(cls)
            dsql += gsql
            dargs += gargs
            return {"from": frm, "to": to, "sessions": c.execute(dsql, dargs).fetchone()[0], "students": data}

        # ---------- programs
        if r == "programs":
            if m == "GET":
                if q.get("date"):
                    return programs_for(c, valid_date(q["date"]), q.get("class"))
                return rows(c.execute("""SELECT * FROM programs ORDER BY
                          repeat_weekday IS NULL, COALESCE(date,''), COALESCE(start_time,'99:99'), title"""))
            if m == "POST":
                v = program_values(self.body())
                cur = c.execute(f"INSERT INTO programs({','.join(v)}) VALUES({','.join('?' * len(v))})",
                                list(v.values()))
                return {"id": cur.lastrowid}
            if m == "PUT" and rid:
                v = program_values(self.body())
                c.execute(f"UPDATE programs SET {','.join(k + '=?' for k in v)} WHERE id=?", [*v.values(), rid])
                return {"ok": True}
            if m == "DELETE" and rid:
                c.execute("DELETE FROM programs WHERE id=?", (rid,))
                return {"ok": True}

        # ---------- announcements
        if r == "announcements":
            if m == "GET":
                return rows(c.execute("SELECT * FROM announcements ORDER BY active DESC, id DESC"))
            if m == "POST":
                text = clean(self.body().get("text"))
                if not text:
                    raise ApiError("Text is required")
                return {"id": c.execute("INSERT INTO announcements(text) VALUES(?)", (text,)).lastrowid}
            if m == "PUT" and rid:
                b = self.body()
                text = clean(b.get("text"))
                if not text:
                    raise ApiError("Text is required")
                c.execute("UPDATE announcements SET text=?, active=? WHERE id=?",
                          (text, 1 if b.get("active", 1) else 0, rid))
                return {"ok": True}
            if m == "DELETE" and rid:
                c.execute("DELETE FROM announcements WHERE id=?", (rid,))
                return {"ok": True}

        # ---------- public display feed
        if r == "display":
            now = dt.datetime.now()
            date = q.get("date") or now.date().isoformat()
            return {
                "school_name": get_setting(c, "school_name"),
                "server_now": now.strftime("%Y-%m-%dT%H:%M:%S"),
                "date": valid_date(date),
                "programs": programs_for(c, date, q.get("class")),
                "checkin": checkin_state(c, reveal=bool(q.get("key")) and hmac.compare_digest(q.get("key", ""), display_key(c))),
                "announcements": [x[0] for x in c.execute(
                    "SELECT text FROM announcements WHERE active=1 ORDER BY id DESC").fetchall()],
            }

        # ---------- CSV import / export, backup
        if r == "import" and sub == "students" and m == "POST":
            text = self.body().get("csv", "")
            reader = csv.DictReader(io.StringIO(text.lstrip("﻿")))
            added, skipped, dupes = 0, 0, 0
            norm = lambda x: " ".join((x or "").split()).casefold()
            seen = {(norm(r[0]), norm(r[1])) for r in c.execute("SELECT full_name, christian_name FROM students")}
            for raw in reader:
                rec = {}
                for k, val in raw.items():
                    if k is None:
                        continue
                    field = CSV_ALIASES.get(k.strip().lower()) or CSV_ALIASES.get(k.strip())
                    if field:
                        rec[field] = val
                if not clean(rec.get("full_name")):
                    skipped += 1
                    continue
                key = (norm(rec.get("full_name")), norm(rec.get("christian_name")))
                if key in seen:                       # same name + Christian name = already in the list
                    dupes += 1
                    continue
                seen.add(key)
                try:
                    v = student_values(rec)
                except ApiError:
                    rec["birth_year"] = None
                    rec["birth_date"] = None
                    v = student_values(rec)
                c.execute(f"INSERT INTO students({','.join(v)}) VALUES({','.join('?' * len(v))})",
                          list(v.values()))
                added += 1
            return {"added": added, "skipped": skipped, "duplicates": dupes}

        if r == "export" and m == "GET" and sub == "all.json":
            data = json.dumps(export_all(c), ensure_ascii=False, indent=1).encode("utf-8")
            self.send_bytes(data, "application/json; charset=utf-8", filename=f"sundayschool-data-{dt.date.today()}.json")
            return None

        if r == "export" and m == "GET":
            if sub == "students.csv":
                data = c.execute("""SELECT full_name, christian_name, gender, birth_year, class_name,
                    parent_name, phone, address, notes, active, grade, birth_date, consent FROM students
                    ORDER BY class_name COLLATE NOCASE, full_name COLLATE NOCASE""").fetchall()
                self.send_bytes(csv_bytes(CSV_EXPORT_HEADERS, [list(x) for x in data]),
                                "text/csv; charset=utf-8", filename="students.csv")
                return None
            if sub == "attendance.csv":
                frm = valid_date(q.get("from") or "2000-01-01", "from")
                to = valid_date(q.get("to") or dt.date.today().isoformat(), "to")
                sql = """SELECT a.date, s.grade, s.full_name, s.christian_name, a.status
                         FROM attendance a JOIN students s ON s.id=a.student_id WHERE a.date BETWEEN ? AND ?"""
                args = [frm, to]
                if q.get("class"):
                    sql += " AND s.class_name=?"
                    args.append(q["class"])
                g = q.get("grade")
                if g == "none":
                    sql += " AND s.grade IS NULL"
                elif g and g.isdigit():
                    sql += " AND s.grade=?"
                    args.append(int(g))
                sql += " ORDER BY a.date, s.grade, s.full_name"
                names = {"P": "Present", "L": "Late", "A": "Absent", "E": "Excused"}
                data = [[d, gr or "", fn, cn, names.get(st, st)] for d, gr, fn, cn, st in c.execute(sql, args).fetchall()]
                self.send_bytes(csv_bytes(["Date", "Grade", "Full name", "Christian name", "Status"], data),
                                "text/csv; charset=utf-8", filename=f"attendance_{frm}_to_{to}.csv")
                return None

        if r == "import" and sub == "single" and m == "POST":
            return import_single(c, self.body().get("data") or {})

        # ---------- backups to USB / folder, and updates
        if r == "maintenance" and m == "GET":
            return update_status(c)
        if r == "maintenance" and sub == "settings" and m == "POST":
            b = self.body()
            if "update_url" in b:
                u = clean(b.get("update_url"))
                if u and not u.lower().startswith("https://"):
                    raise ApiError("The update address must start with https://")
                c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('update_url',?)", (u,))
            if "backup_folder" in b:
                f = clean(b.get("backup_folder"))
                if f and not os.path.isdir(f):
                    raise ApiError("That folder does not exist on this computer")
                c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('backup_folder',?)", (f,))
            if b.get("usb_every") not in (None, ""):
                n = to_int(b.get("usb_every"), "Days")
                if not 1 <= n <= 60:
                    raise ApiError("Days must be 1-60")
                c.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('usb_every',?)", (str(n),))
            c.commit()
            return update_status(c)
        if r == "maintenance" and sub == "usb" and m == "POST":
            targets = usb_targets(c)
            if not targets:
                raise ApiError("No USB flash drive found. Plug one in (or choose a backup folder) and try again.")
            return usb_backup(c, targets[0])
        if r == "maintenance" and sub == "check" and m == "POST":
            return check_update(c)
        if r == "maintenance" and sub == "install" and m == "POST":
            b = self.body()
            if b.get("zip"):                       # a file the admin chose
                import base64
                try:
                    blob = base64.b64decode(b["zip"], validate=True)
                except Exception:
                    raise ApiError("The file could not be read")
                return install_update(blob)
            info = check_update(c)                 # from the internet
            if not info["newer"]:
                raise ApiError(f"You already have the newest version ({VERSION})")
            if not info["url"] or not info["sha256"]:
                raise ApiError("The update information is incomplete (url / sha256)")
            blob = fetch_url(info["url"])
            if hashlib.sha256(blob).hexdigest().lower() != info["sha256"].lower():
                raise ApiError("The downloaded update is damaged or not genuine (checksum differs). Nothing was changed.")
            return install_update(blob)

        if r == "backup" and m == "GET":
            tmp = os.path.join(DATA, f"_download_{secrets.token_hex(4)}.db")
            try:
                snapshot(tmp)
                with open(tmp, "rb") as f:
                    blob = f.read()
            finally:
                if os.path.exists(tmp):
                    os.remove(tmp)
            self.send_bytes(blob, "application/octet-stream",
                            filename=f"sundayschool-backup-{dt.date.today()}.db")
            return None

        raise ApiError("not found", 404)


# ---------------------------------------------------------------- main

def adopt_old_data():
    """First start of this version: bring over data from an older copy that kept it in ./data."""
    if os.path.exists(DB_PATH) or not os.path.exists(os.path.join(OLD_DATA, "sundayschool.db")):
        return
    import shutil
    try:
        src = sqlite3.connect(os.path.join(OLD_DATA, "sundayschool.db"))
        dst = sqlite3.connect(DB_PATH)
        src.backup(dst); dst.close(); src.close()          # safe copy even of a WAL database
        if os.path.exists(os.path.join(OLD_DATA, "config.json")) and not os.path.exists(CONF_PATH):
            shutil.copy2(os.path.join(OLD_DATA, "config.json"), CONF_PATH)
        print(f"  Moved your existing data from {OLD_DATA}")
    except Exception as e:
        print(f"  Could not move old data from {OLD_DATA}: {e}")

def main():
    global CONF
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    port = int(args[0]) if args else int(os.environ.get("PORT", 8080))
    os.makedirs(DATA, exist_ok=True)
    adopt_old_data()
    CONF = load_conf()
    init_db()
    daily_backup()
    threading.Thread(target=backup_loop, daemon=True).start()
    threading.Thread(target=address_watch, args=(port,), daemon=True).start()

    httpd = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    httpd.daemon_threads = True
    if os.path.exists(PENDING):                       # an update was just installed and it starts fine
        try:
            os.remove(PENDING)
        except OSError:
            pass
    line = "=" * 62
    print(line)
    print("  SUNDAY SCHOOL MANAGER is running (no internet needed)")
    print(line)
    print(f"  On this computer : http://localhost:{port}")
    for ip in lan_ips():
        print(f"  On the network   : http://{ip}:{port}")
        print(f"  TV / projector   : http://{ip}:{port}/display")
    if not lan_ips():
        print("  On the network   : (none yet) - connect this computer to the Wi-Fi / hotspot;")
        print("                     the address will be shown here when it connects.")
    if not lan_ips():
        print("  On the network   : (not connected to any Wi-Fi / hotspot yet - connect, then restart)")
    print("  Use the address that matches the Wi-Fi/hotspot the phones are on (it can change).")
    if CONF.get("default_pin"):
        print(f"\n  Default PIN is {DEFAULT_PIN} -> change it in Settings!")
    print(f"\n  Your data is saved in: {DATA}")
    print("  (outside the app folder, so a new copy of the app keeps the same data)")
    print("\n  Keep this window open. Press Ctrl+C to stop.")
    print(line)
    if "--no-browser" not in sys.argv:          # open the app on this computer automatically
        import webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()

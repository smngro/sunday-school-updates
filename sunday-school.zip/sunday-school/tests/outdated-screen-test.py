import asyncio, sys, json
from playwright.async_api import async_playwright
URL=sys.argv[1]; res=[]
def ok(n,c,i=""): res.append(bool(c)); print(("PASS " if c else "FAIL ")+n, i)
async def main():
    async with async_playwright() as p:
        br = await p.chromium.launch(executable_path="/usr/bin/google-chrome"); errs=[]
        A = await (await br.new_context(viewport={"width":1366,"height":900})).new_page(); A.on("pageerror", lambda e: errs.append(str(e)))
        await A.goto(URL); await A.evaluate("localStorage.clear()"); await A.reload(); await A.wait_for_timeout(500)
        await A.fill("#login-pin","1234"); await A.keyboard.press("Enter"); await A.wait_for_timeout(800)
        await A.fill("#fp-new","246813"); await A.fill("#fp-new2","246813"); await A.click("#force-pin-form button.primary"); await A.wait_for_timeout(800)
        await A.evaluate("async () => { for (const n of ['ሀ','ለ']) { const id = (await api('students', {method:'POST', body:{full_name:n}})).id; const d = await api('depts'); await api(`depts/${d[0].id}/members`, {method:'POST', body:{student_ids:[id]}}); } }")
        # Sunday-school attendance screen opened, then the ID of 'ሀ' is changed elsewhere
        await A.click("#tabs button[data-tab=attendance]"); await A.wait_for_timeout(800)
        await A.evaluate("async () => { const s = (await api('students')).find(x => x.full_name === 'ሀ'); await fetch('/api/students/' + s.id, {method:'PUT', headers:{'Content-Type':'application/json','X-Token':TOKEN}, body: JSON.stringify({full_name:'ሀ', new_id: 900})}); }") if URL.startswith("http") else \
            await A.evaluate("async () => { const s = (await api('students')).find(x => x.full_name === 'ሀ'); await api('students/' + s.id, {method:'PUT', body:{full_name:'ሀ', new_id: 900}}); }")
        rows = A.locator(".att-row"); n = await rows.count()
        for i in range(n): await rows.nth(i).locator("button[data-s='P']").click()
        await A.click("#at-save"); await A.wait_for_timeout(1200)
        st = await A.evaluate("async () => (await api('attendance?date=' + today() + '&grade=')).map(s => [s.full_name, s.status])")
        ok("the other members' marks are saved", ['ለ', 'P'] in st, st)
        ok("the list reloads with the new number", await A.evaluate("att.some(s => s.id === 900)"))
        # department meeting screen, same situation
        await A.click("#tabs button[data-tab=depts]"); await A.wait_for_timeout(700)
        await A.click("#dp-views [data-dview=attendance]"); await A.wait_for_timeout(700)
        await A.evaluate("async () => { const s = (await api('students')).find(x => x.full_name === 'ለ'); await api('students/' + s.id, {method:'PUT', body:{full_name:'ለ', new_id: 901}}); }")
        rows = A.locator("#dp-body .att-row"); n = await rows.count()
        for i in range(n): await rows.nth(i).locator("button[data-ds='P']").click()
        await A.click("#dp-save"); await A.wait_for_timeout(1200)
        rep = await A.evaluate("async () => { const d = (await api('depts'))[0]; return (await api(`depts/${d.id}/report?from=${today()}&to=${today()}`)).members.map(m => [m.full_name, m.present]); }")
        ok("department meeting: other marks saved", ['ሀ', 1] in rep, rep)
        ok("no page errors", not errs, errs); await br.close()
asyncio.run(main()); print(json.dumps({"passed":sum(res),"total":len(res)}))

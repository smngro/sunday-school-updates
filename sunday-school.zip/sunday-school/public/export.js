/* Sunday School Manager — export tables to Excel (.xlsx), Spreadsheet (.ods), Word (.docx) or CSV.
   Runs fully in the browser, offline, with no libraries. Works in all versions (Wi-Fi, single file, phone).

   XExport.save(format, doc)
     doc = { title, subtitle, file, sections: [ { name, headers: [...], rows: [[...], ...], totals: [...]? } ] }
     A cell may be a string, a number, or null. */
const XExport = (() => {
  'use strict';

  /* ---------- tiny ZIP writer (stored, no compression) ---------- */
  const CRC = (() => { const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
    return t; })();
  const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  const enc = new TextEncoder();
  function zip(files) {                       // files: [[name, string|Uint8Array], ...]
    const parts = [], central = []; let off = 0;
    const d = new Date(), dosT = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1),
          dosD = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    for (const [name, content] of files) {
      const data = typeof content === 'string' ? enc.encode(content) : content, nm = enc.encode(name), crc = crc32(data);
      const h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true);
      h.setUint16(10, dosT, true); h.setUint16(12, dosD, true); h.setUint32(14, crc, true);
      h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, nm.length, true); h.setUint16(28, 0, true);
      parts.push(new Uint8Array(h.buffer), nm, data);
      const c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true);
      c.setUint16(10, 0, true); c.setUint16(12, dosT, true); c.setUint16(14, dosD, true); c.setUint32(16, crc, true);
      c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, nm.length, true);
      c.setUint32(42, off, true);
      central.push(new Uint8Array(c.buffer), nm);
      off += 30 + nm.length + data.length;
    }
    const csize = central.reduce((a, x) => a + x.length, 0), e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true);
    e.setUint32(12, csize, true); e.setUint32(16, off, true);
    return new Blob([...parts, ...central, new Uint8Array(e.buffer)]);
  }

  const x = v => String(v ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
  const isNum = v => typeof v === 'number' && isFinite(v);
  const allRows = s => [...s.rows, ...(s.totals ? [s.totals] : [])];

  /* ---------- Excel (.xlsx) ---------- */
  const colName = i => { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  function sheetNames(sections) {
    const used = new Set();
    return sections.map((s, i) => {
      let n = String(s.name || `Sheet ${i + 1}`).replace(/[\[\]:*?\/\\]/g, ' ').trim().slice(0, 31) || `Sheet ${i + 1}`, b = n, k = 2;
      while (used.has(n.toLowerCase())) n = b.slice(0, 27) + ' (' + k++ + ')';
      used.add(n.toLowerCase()); return n;
    });
  }
  function xlsx(doc) {
    const names = sheetNames(doc.sections), files = [];
    const cell = (r, c, v, st) => isNum(v) ? `<c r="${colName(c)}${r}"${st ? ` s="${st}"` : ''}><v>${v}</v></c>`
      : (v === null || v === undefined || v === '') ? '' : `<c r="${colName(c)}${r}" t="inlineStr"${st ? ` s="${st}"` : ''}><is><t xml:space="preserve">${x(v)}</t></is></c>`;
    doc.sections.forEach((s, si) => {
      const rows = [], ncol = s.headers.length;
      rows.push(`<row r="1">${cell(1, 0, doc.title, 2)}</row>`);
      rows.push(`<row r="2">${cell(2, 0, [doc.subtitle, s.title].filter(Boolean).join(' — '), 3)}</row>`);
      rows.push(`<row r="4">${s.headers.map((h, c) => cell(4, c, h, 1)).join('')}</row>`);
      s.rows.forEach((r, i) => rows.push(`<row r="${5 + i}">${r.map((v, c) => cell(5 + i, c, v, 0)).join('')}</row>`));
      if (s.totals) { const rn = 5 + s.rows.length; rows.push(`<row r="${rn}">${s.totals.map((v, c) => cell(rn, c, v, 4)).join('')}</row>`); }
      const widths = s.headers.map((h, c) => Math.min(50, Math.max(5, ...[h, ...allRows(s).map(r => r[c])].map(v => String(v ?? '').length + 2))));
      files.push([`xl/worksheets/sheet${si + 1}.xml`, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetViews><sheetView workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
<cols>${widths.map((w, c) => `<col min="${c + 1}" max="${c + 1}" width="${w}" customWidth="1"/>`).join('')}</cols>
<sheetData>${rows.join('')}</sheetData>
${ncol && s.rows.length ? `<autoFilter ref="A4:${colName(ncol - 1)}${4 + s.rows.length}"/>` : ''}
<pageSetup orientation="${ncol > 7 ? 'landscape' : 'portrait'}"/>
</worksheet>`]);
    });
    files.unshift(
      ['[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
${names.map((n, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}
</Types>`],
      ['_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`],
      ['xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>${names.map((n, i) => `<sheet name="${x(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets>
</workbook>`],
      ['xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${names.map((n, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}
<Relationship Id="rId${names.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`],
      ['xl/styles.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4"><font><sz val="11"/><name val="Nyala"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Nyala"/></font>
<font><b/><sz val="15"/><color rgb="FF6A0F23"/><name val="Nyala"/></font><font><b/><sz val="11"/><name val="Nyala"/></font></fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF6A0F23"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF3D1"/></patternFill></fill></fills>
<borders count="2"><border/><border><left style="thin"><color rgb="FFBBBBBB"/></left><right style="thin"><color rgb="FFBBBBBB"/></right><top style="thin"><color rgb="FFBBBBBB"/></top><bottom style="thin"><color rgb="FFBBBBBB"/></bottom></border></borders>
<cellStyleXfs count="1"><xf/></cellStyleXfs>
<cellXfs count="5"><xf fontId="0" borderId="1" applyBorder="1"/><xf fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1"/>
<xf fontId="2" applyFont="1"/><xf fontId="3" applyFont="1"/><xf fontId="3" fillId="3" borderId="1" applyFont="1" applyFill="1" applyBorder="1"/></cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`]);
    return zip(files);
  }

  /* ---------- OpenDocument spreadsheet (.ods): LibreOffice, Google Sheets, WPS ---------- */
  function ods(doc) {
    const names = sheetNames(doc.sections);
    const cell = (v, st) => {
      const sa = st ? ` table:style-name="${st}"` : '';
      if (isNum(v)) return `<table:table-cell${sa} office:value-type="float" office:value="${v}"><text:p>${v}</text:p></table:table-cell>`;
      if (v === null || v === undefined || v === '') return `<table:table-cell${sa}/>`;
      return `<table:table-cell${sa} office:value-type="string"><text:p>${x(v)}</text:p></table:table-cell>`;
    };
    const tables = doc.sections.map((s, i) => `<table:table table:name="${x(names[i])}">
<table:table-column table:style-name="co1" table:number-columns-repeated="${Math.max(1, s.headers.length)}"/>
<table:table-row>${cell(doc.title, 'ti')}</table:table-row>
<table:table-row>${cell([doc.subtitle, s.title].filter(Boolean).join(' — '))}</table:table-row>
<table:table-row>${cell('')}</table:table-row>
<table:table-row>${s.headers.map(h => cell(h, 'hd')).join('')}</table:table-row>
${s.rows.map(r => `<table:table-row>${r.map(v => cell(v)).join('')}</table:table-row>`).join('\n')}
${s.totals ? `<table:table-row>${s.totals.map(v => cell(v, 'tt')).join('')}</table:table-row>` : ''}
</table:table>`).join('\n');
    const content = `<?xml version="1.0" encoding="UTF-8"?>
<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0"
 xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" office:version="1.2">
<office:automatic-styles>
<style:style style:name="co1" style:family="table-column"><style:table-column-properties style:column-width="1.6in"/></style:style>
<style:style style:name="ti" style:family="table-cell"><style:text-properties fo:font-size="15pt" fo:font-weight="bold" fo:color="#6a0f23"/></style:style>
<style:style style:name="hd" style:family="table-cell"><style:table-cell-properties fo:background-color="#6a0f23"/><style:text-properties fo:font-weight="bold" fo:color="#ffffff"/></style:style>
<style:style style:name="tt" style:family="table-cell"><style:table-cell-properties fo:background-color="#fff3d1"/><style:text-properties fo:font-weight="bold"/></style:style>
</office:automatic-styles>
<office:body><office:spreadsheet>${tables}</office:spreadsheet></office:body></office:document-content>`;
    return zip([
      ['mimetype', 'application/vnd.oasis.opendocument.spreadsheet'],
      ['META-INF/manifest.xml', `<?xml version="1.0" encoding="UTF-8"?>
<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">
<manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.spreadsheet"/>
<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>
</manifest:manifest>`],
      ['content.xml', content]]);
  }

  /* ---------- Word (.docx): tables with a title, ready to print ---------- */
  function docx(doc) {
    const maxCols = Math.max(...doc.sections.map(s => s.headers.length), 1), land = maxCols > 6;
    const run = (v, o = {}) => `<w:r><w:rPr><w:rFonts w:ascii="Nyala" w:hAnsi="Nyala" w:cs="Nyala" w:eastAsia="Nyala"/>${o.b ? '<w:b/>' : ''}${o.color ? `<w:color w:val="${o.color}"/>` : ''}<w:sz w:val="${o.sz || 20}"/></w:rPr><w:t xml:space="preserve">${x(v)}</w:t></w:r>`;
    const para = (v, o = {}) => `<w:p><w:pPr><w:spacing w:before="${o.before || 0}" w:after="${o.after ?? 80}"/>${o.jc ? `<w:jc w:val="${o.jc}"/>` : ''}${o.keep ? '<w:keepNext/>' : ''}</w:pPr>${v === '' ? '' : run(v, o)}</w:p>`;
    const tc = (v, o = {}) => `<w:tc><w:tcPr>${o.fill ? `<w:shd w:val="clear" w:color="auto" w:fill="${o.fill}"/>` : ''}<w:tcMar><w:left w:w="60" w:type="dxa"/><w:right w:w="60" w:type="dxa"/></w:tcMar></w:tcPr>${para(v ?? '', { ...o, after: 0, jc: isNum(v) ? 'center' : undefined })}</w:tc>`;
    const border = '<w:top w:val="single" w:sz="4" w:color="999999"/><w:left w:val="single" w:sz="4" w:color="999999"/><w:bottom w:val="single" w:sz="4" w:color="999999"/><w:right w:val="single" w:sz="4" w:color="999999"/><w:insideH w:val="single" w:sz="4" w:color="BBBBBB"/><w:insideV w:val="single" w:sz="4" w:color="BBBBBB"/>';
    const small = maxCols > 9 ? 16 : 18;
    let body = para(doc.title, { b: true, sz: 32, color: '6A0F23', after: 40 }) + (doc.subtitle ? para(doc.subtitle, { sz: 20, color: '555555', after: 200 }) : '');
    doc.sections.forEach(s => {
      if (doc.sections.length > 1 || s.title) body += para(s.title || s.name, { b: true, sz: 26, before: 240, after: 100, keep: true });
      body += `<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblBorders>${border}</w:tblBorders><w:tblLayout w:type="autofit"/></w:tblPr>
<w:tr><w:trPr><w:tblHeader/></w:trPr>${s.headers.map(h => tc(h, { b: true, color: 'FFFFFF', fill: '6A0F23', sz: small })).join('')}</w:tr>
${s.rows.map(r => `<w:tr><w:trPr><w:cantSplit/></w:trPr>${r.map(v => tc(v, { sz: small })).join('')}</w:tr>`).join('')}
${s.totals ? `<w:tr>${s.totals.map(v => tc(v, { b: true, fill: 'FFF3D1', sz: small })).join('')}</w:tr>` : ''}
</w:tbl>`;
      if (!s.rows.length) body += para('—');
    });
    const pg = land ? '<w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/>' : '<w:pgSz w:w="11906" w:h="16838"/>';
    const document = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body}
<w:sectPr>${pg}<w:pgMar w:top="900" w:right="800" w:bottom="900" w:left="800" w:header="500" w:footer="500" w:gutter="0"/></w:sectPr></w:body></w:document>`;
    return zip([
      ['[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`],
      ['_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`],
      ['word/document.xml', document]]);
  }

  /* ---------- CSV (Excel opens it too) ---------- */
  function csv(doc) {
    const cellv = v => { let s = String(v ?? ''); if (!isNum(v) && /^[=+\-@\t\r]/.test(s)) s = "'" + s;
      return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    const out = [[doc.title], [doc.subtitle || '']];
    doc.sections.forEach(s => { out.push([], [s.title || s.name], s.headers, ...allRows(s)); });
    return new Blob(['﻿' + out.map(r => r.map(cellv).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
  }

  const TYPES = {
    xlsx: [xlsx, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
    ods: [ods, 'application/vnd.oasis.opendocument.spreadsheet'],
    docx: [docx, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
    csv: [csv, 'text/csv'],
  };
  function save(format, doc) {
    const [fn, type] = TYPES[format];
    const blob = new Blob([fn(doc)], { type });
    const name = (doc.file || 'export').replace(/[\\/:*?"<>|]+/g, '-') + '.' + format;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    return name;
  }
  return { save, build: (format, doc) => TYPES[format][0](doc) };
})();
if (typeof module !== 'undefined') module.exports = XExport;

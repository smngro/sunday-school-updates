'use strict';
/* Sunday School Manager — admin / teacher app (vanilla JS, no internet needed) */

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const isoDate = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const today = () => isoDate(new Date());
const LETTERS = { en: { P: 'P', L: 'L', A: 'A', E: 'E' }, am: { P: 'ተ', L: 'ዘ', A: 'ቀ', E: 'ፈ' } };
const STATUS = { P: 'Present', L: 'Late', A: 'Absent', E: 'Excused' };
const WEEKDAY = { 0: 'Monday', 1: 'Tuesday', 2: 'Wednesday', 3: 'Thursday', 4: 'Friday', 5: 'Saturday', 6: 'Sunday' };

let TOKEN = '';
try { TOKEN = localStorage.getItem('ss_token') || ''; } catch (e) { /* storage blocked */ }
const store = t => { TOKEN = t; try { localStorage.setItem('ss_token', t); } catch (e) {} };

/* ---------------- helpers ---------------- */
function toast(msg, bad = false) {
  const t = $('#toast');
  t.textContent = I18N.t(msg);
  t.className = 'show' + (bad ? ' bad' : '');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.className = ''), 2600);
}

async function api(path, opts = {}) {
  const o = { method: opts.method || 'GET', headers: { 'X-Token': TOKEN } };
  if (opts.body !== undefined) {
    o.headers['Content-Type'] = 'application/json';
    o.body = JSON.stringify(opts.body);
  }
  let r;
  try { r = await fetch('/api/' + path, o); }
  catch (e) { toast('Cannot reach the server. Is it still running?', true); throw e; }
  const d = await r.json().catch(() => ({}));
  const rv = r.headers.get('X-Rev');
  if (rv) {                                   // our own edits don't trigger a refresh…
    if (live.rev !== null && rv !== live.rev) refreshSchoolName();   // …but keep the name in the header up to date
    live.rev = rv;
  }
  if (r.status === 401) { showLogin(); throw new Error('login required'); }
  if (r.status === 403 && /default PIN/.test(d.error || '')) { forcePin(); throw new Error(d.error); }
  if (r.status === 409) throw new Error(d.error || r.statusText);
  if (!r.ok) { toast(d.error || r.statusText, true); throw new Error(d.error || r.statusText); }
  return d;
}

function formData(form) {
  const o = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    o[el.name] = el.type === 'checkbox' ? (el.checked ? 1 : 0) : el.value;
  }
  return o;
}

function fillForm(form, data) {
  for (const el of form.elements) {
    if (!el.name) continue;
    const v = data[el.name];
    if (el.type === 'checkbox') el.checked = v === undefined ? el.defaultChecked : !!v;   // consent must never be ticked by default
    else el.value = v ?? '';
  }
}

function download(path) { fetchDownload(path); }
async function fetchDownload(path) {
  const r = await fetch('/api/' + path, { headers: { 'X-Token': TOKEN } });
  if (r.status === 401) return showLogin();
  if (!r.ok) return toast('Download failed', true);
  const name = ((r.headers.get('Content-Disposition') || '').match(/filename="([^"]+)"/) || [])[1] || 'download';
  const a = document.createElement('a');
  a.href = URL.createObjectURL(await r.blob()); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 3000);
}

const age = y => (y ? new Date().getFullYear() - y : '');
function ageOf(s) {                                  // exact age from the full birth date when we have it
  if (s.birth_date) {
    const b = new Date(s.birth_date + 'T12:00'), n = new Date();
    let a = n.getFullYear() - b.getFullYear();
    if (n.getMonth() < b.getMonth() || (n.getMonth() === b.getMonth() && n.getDate() < b.getDate())) a--;
    return a;
  }
  return age(s.birth_year);
}
const ecBirth = s => (s.birth_date ? EthioDate.format(new Date(s.birth_date + 'T12:00'), false) : '');
const timeRange = p => [p.start_time, p.end_time].filter(Boolean).join(' – ');


/* Forms: handle the submit BUTTON click instead of the form "submit" event.
   Some file viewers / app previews block form submission, which made Log in do nothing. */
function onSubmit(form, handler) {
  form.addEventListener('submit', e => e.preventDefault());
  const run = e => {
    e.preventDefault();
    if (form.reportValidity && !form.reportValidity()) return;
    // the error message is already shown by api(); keep the form open so it can be corrected
    Promise.resolve(handler({ target: form, preventDefault() {} })).catch(err => console.warn(err && err.message));
  };
  $$('button:not([type=button])', form).forEach(btn => btn.addEventListener('click', run));
  $$('input', form).forEach(inp => inp.addEventListener('keydown', e => { if (e.key === 'Enter') run(e); }));
}

/* Confirm box that also works where window.confirm() is blocked */
function askConfirm(msg) {
  return new Promise(resolve => {
    let d = $('#ask-dlg');
    if (!d) {
      d = document.createElement('dialog'); d.id = 'ask-dlg';
      d.innerHTML = '<p id="ask-msg" style="white-space:pre-line;margin:0 0 16px"></p><div class="row"><span class="spacer"></span>' +
        '<button type="button" class="btn" id="ask-no">Cancel</button><button type="button" class="btn primary" id="ask-yes">OK</button></div>';
      document.body.appendChild(d);
    }
    $('#ask-msg').textContent = I18N.t(msg);
    const done = v => { d.close(); resolve(v); };
    $('#ask-yes').onclick = () => done(true);
    $('#ask-no').onclick = () => done(false);
    d.oncancel = () => resolve(false);
    d.showModal();
  });
}

/* ---------------- login ---------------- */
function showLogin() {
  $('#login').hidden = false;
  setTimeout(() => $('#login-pin').focus(), 50);
}

onSubmit($('#login-form'), async e => {
  e.preventDefault();
  $('#login-err').textContent = '';
  try {
    const r = await fetch('/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: $('#login-pin').value })
    });
    const d = await r.json();
    if (!r.ok) { $('#login-err').textContent = I18N.t(d.error || 'Login failed'); return; }
    store(d.token);
    $('#login').hidden = true;
    $('#login-pin').value = '';
    start();
    if (d.default_pin) forcePin();
  } catch (err) { $('#login-err').textContent = I18N.t('Cannot reach the server'); }
});

$('#logout').onclick = async () => { try { await fetch('/api/logout', { method: 'POST', headers: { 'X-Token': TOKEN } }); } catch (e) {} store(''); showLogin(); };

/* ---------------- first login: the default PIN must be replaced ---------------- */
function forcePin() {
  if ($('#force-pin-dlg').open) return;
  $('#fp-err').textContent = ''; $('#fp-new').value = ''; $('#fp-new2').value = '';
  $('#force-pin-dlg').showModal();
  setTimeout(() => $('#fp-new').focus(), 50);
}
$('#force-pin-dlg').addEventListener('cancel', e => e.preventDefault());     // can't be skipped with Esc
onSubmit($('#force-pin-form'), async () => {
  $('#fp-err').textContent = '';
  if ($('#fp-new').value !== $('#fp-new2').value) { $('#fp-err').textContent = t('New PINs do not match'); return; }
  const r = await fetch('/api/pin', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Token': TOKEN },
    body: JSON.stringify({ old: '1234', new: $('#fp-new').value }) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { $('#fp-err').textContent = t(d.error || 'Error'); return; }
  store(d.token);
  $('#force-pin-dlg').close(); $('#pin-warning').hidden = true;
  toast('PIN changed ✓ (other devices must log in again)');
});

/* ---------------- tabs ---------------- */
const loaders = {};
function openTab(name) {
  $$('#tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  $$('.tab').forEach(s => s.classList.toggle('active', s.id === 'tab-' + name));
  try { localStorage.setItem('ss_tab', name); } catch (e) {}
  loaders[name] && loaders[name]();
}
$$('#tabs button').forEach(b => (b.onclick = () => openTab(b.dataset.tab)));
document.addEventListener('click', e => {
  const g = e.target.closest('[data-goto]');
  if (g) { e.preventDefault(); openTab(g.dataset.goto); }
  if (e.target.closest('[data-print]')) { prepPrint(); window.print(); }
  if (e.target.closest('[data-close]')) e.target.closest('dialog').close();
});

function prepPrint() {
  const school = $('#school-name').textContent;
  if ($('#mt-print-title')) $('#mt-print-title').textContent = `${school} — መሠረተ ትምህርት — ${gradeLabel(mt.grade)} — ${semLabel(mt.term)}`;
}
/* print only one element (e.g. password slips) */
function printOnly(html) {
  $('#print-area').innerHTML = html;
  document.body.classList.add('print-area-mode');
  const done = () => { document.body.classList.remove('print-area-mode'); window.removeEventListener('afterprint', done); };
  window.addEventListener('afterprint', done);
  window.print();
  setTimeout(done, 1500);
}
const gradeLabel = g => (I18N.lang === 'am' ? `${g}ኛ ክፍል` : `Grade ${g}`);

/* ---------------- classes ---------------- */
async function loadClasses() {
  const list = await api('classes');
  $$('.class-select').forEach(sel => {
    const v = sel.value;
    sel.innerHTML = '<option value="">All classes</option>' +
      list.map(c => `<option>${esc(c)}</option>`).join('');
    sel.value = list.includes(v) ? v : '';
  });
  $('#class-list').innerHTML = list.map(c => `<option value="${esc(c)}">`).join('');
}

/* ================= STUDENTS ================= */
let students = [];
async function loadStudents() {
  const p = new URLSearchParams({
    q: $('#st-search').value, class: $('#st-class').value,
    inactive: $('#st-inactive').checked ? 1 : 0
  });
  students = await api('students?' + p);
  const cls = $('#st-class').value;
  $('#st-print-title').textContent = `${$('#school-name').textContent} — ${I18N.t('Member list')}${cls ? ' — ' + cls : ''}`;
  $('#st-count').textContent = I18N.t(students.length === 1 ? '{n} member' : '{n} members', { n: students.length });
  $('#st-body').innerHTML = students.map((s, i) => `
    <tr class="${s.active ? '' : 'inactive'}">
      <td>${i + 1}</td>
      <td><b>${s.id}</b></td>
      <td data-noi18n><b>${esc(s.full_name)}</b>${s.consent ? '' : ` <span class="no-consent" title="${t('No consent recorded')}">⚠</span>`}</td>
      <td data-noi18n>${esc(s.christian_name)}</td>
      <td>${s.grade ? esc(gradeLabel(s.grade)) : ''}</td>
      <td data-noi18n>${(s.depts || []).map(d => `<span class="chip">${esc(d)}</span>`).join(' ')}</td>
      <td>${esc(s.gender)}</td>
      <td title="${esc(ecBirth(s))}">${ageOf(s)}${s.birth_date ? `<div class="muted small">${esc(ecBirth(s))}</div>` : ''}</td>
      <td>${s.phone ? `<a href="tel:${esc(s.phone)}">${esc(s.phone)}</a>` : ''}</td>
      <td class="no-print">${codeBadge(s)} <button class="btn small" data-code="${s.id}" title="${t('New one-time code')}">🔑</button> <button class="btn small" data-edit="${s.id}">Edit</button></td>
    </tr>`).join('') || '<tr><td colspan="10" class="empty">No members yet — click “+ Add member” or import a CSV.</td></tr>';
}
loaders.students = () => loadClasses().then(loadStudents);

let searchTimer;
$('#st-search').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadStudents, 250); };
$('#st-class').onchange = loadStudents;
$('#st-inactive').onchange = loadStudents;

/* Birth date picker: day / Ethiopian month / E.C. year  ⇄  Gregorian date */
function bdInit() {
  $('#bd-day').innerHTML = '<option value="">ቀን</option>' + Array.from({ length: 30 }, (_, i) => `<option>${i + 1}</option>`).join('');
  $('#bd-month').innerHTML = '<option value="">ወር</option>' + EthioDate.MONTHS.map((m, i) => `<option value="${i + 1}">${m}</option>`).join('');
}
function bdShow(iso) {                                 // put a G.C. date into the E.C. boxes
  const f = $('#st-form');
  if (iso) {
    const e = EthioDate.fromDate(new Date(iso + 'T12:00'));
    $('#bd-day').value = e.day; $('#bd-month').value = e.month; $('#bd-year').value = e.year; $('#bd-gc').value = iso;
  } else { $('#bd-day').value = ''; $('#bd-month').value = ''; $('#bd-year').value = ''; $('#bd-gc').value = ''; }
  f.elements.birth_date.value = iso || '';
  bdInfo();
}
function bdFromEC() {                                  // E.C. boxes changed -> work out the G.C. date
  const f = $('#st-form'), d = +$('#bd-day').value, m = +$('#bd-month').value, y = +$('#bd-year').value;
  if (d && m && y >= 1900) {
    const max = EthioCal.monthLength(y, m);
    if (d > max) { $('#bd-info').textContent = t('{m} {y} has only {n} days', { m: EthioDate.MONTHS[m - 1], y, n: max }); f.elements.birth_date.value = ''; return; }
    const g = EthioCal.jdnToG(EthioCal.eToJdn(y, m, d)), iso = `${g.y}-${pad(g.m)}-${pad(g.d)}`;
    f.elements.birth_date.value = iso; $('#bd-gc').value = iso; f.elements.birth_year.value = g.y;
  } else if (y >= 1900 && !d && !m) {                 // only the E.C. year is known
    f.elements.birth_date.value = ''; $('#bd-gc').value = ''; f.elements.birth_year.value = y + 8;
  } else { f.elements.birth_date.value = ''; }
  bdInfo();
}
function bdInfo() {
  const f = $('#st-form'), iso = f.elements.birth_date.value;
  if (iso) {
    const g = new Date(iso + 'T12:00');
    $('#bd-info').textContent = `${EthioDate.format(g)} · ${g.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })} · ${t('Age')}: ${ageOf({ birth_date: iso })}`;
  } else if (f.elements.birth_year.value) $('#bd-info').textContent = `≈ ${f.elements.birth_year.value} G.C. · ${t('Age')}: ≈${age(+f.elements.birth_year.value)}`;
  else $('#bd-info').textContent = '';
}
['#bd-day', '#bd-month'].forEach(sel => ($(sel).onchange = bdFromEC));
$('#bd-year').oninput = bdFromEC;
$('#bd-gc').onchange = () => { const v = $('#bd-gc').value; bdShow(v); if (v) $('#st-form').elements.birth_year.value = +v.slice(0, 4); };

let editingStudent = null, studentDefaults = null, stDeptBefore = '';
async function fillDeptSelect(sel) {                    // the department list in the member form
  const list = (await api('depts')).filter(d => d.active || d.id == sel);
  $('#st-dept').innerHTML = '<option value="">—</option>' + list.map(d => `<option value="${d.id}">${esc(d.name)}</option>`).join('');
  $('#st-dept').value = sel ? String(sel) : '';
}
const reloadCurrent = () => { const cur = $('#tabs button.active'); if (cur && loaders[cur.dataset.tab]) loaders[cur.dataset.tab](); };
function openStudent(s, defaults) {
  editingStudent = s ? s.id : null;
  studentDefaults = defaults || null;
  const inMt = $('#tab-mt').classList.contains('active');   // Members tab says “member”, መሠረተ ትምህርት says “student”
  $('#st-dlg-title').textContent = s ? (inMt ? 'Edit student' : 'Edit member') : (inMt ? 'Add student' : 'Add member');
  fillForm($('#st-form'), s || { active: 1, ...(defaults || {}) });
  stDeptBefore = s ? ((s.dept_ids || [])[0] || '') : (defaults && defaults._dept) || '';
  fillDeptSelect(stDeptBefore);
  $('#st-idno').value = s ? s.id : '';                    // automatic, but the admin may type another free number
  const more = s && (s.depts || []).length > 1 ? s.depts.slice(1) : [];
  $('#st-dept-more').textContent = more.length ? `${t('Also in')}: ${more.join(', ')} (${t('change these in the Departments tab')})` : '';
  bdShow(s && s.birth_date ? s.birth_date : '');
  if (s && !s.birth_date && s.birth_year) { $('#st-form').elements.birth_year.value = s.birth_year; bdInfo(); }
  $('#st-del').hidden = !s;
  $('#st-dlg').showModal();
  setTimeout(() => $('#st-form [name=full_name]').focus(), 30);   // start with the name; the ID box is optional
}
$('#st-add').onclick = () => openStudent(null);
$('#st-body').addEventListener('click', e => {
  const k = e.target.closest('[data-code]');
  if (k) { const m = students.find(x => x.id == k.dataset.code); return issueCodes([m]); }
  const b = e.target.closest('[data-edit]');
  if (b) openStudent(students.find(s => s.id == b.dataset.edit));
});
onSubmit($('#st-form'), async e => {
  e.preventDefault();
  const body = formData(e.target), dept = body._dept; delete body._dept;
  const typed = $('#st-idno').value.trim();               // ID number: automatic, or typed by the admin
  if (!editingStudent && typed) body.id = typed;
  if (editingStudent && typed && +typed !== editingStudent) {
    if (!(await askConfirm(t('Change the ID number from {a} to {b}? Attendance, results and departments stay with the member. The member must log in with the NEW number, and old printed slips stop working.', { a: editingStudent, b: typed })))) return;
    body.new_id = typed;
  }
  let id = editingStudent;
  if (editingStudent) { const r = await api('students/' + editingStudent, { method: 'PUT', body }); if (r.id) id = r.id; }
  else id = (await api('students', { method: 'POST', body })).id;
  if (String(dept || '') !== String(stDeptBefore || '')) {  // department changed in the form
    if (stDeptBefore && editingStudent) await api(`depts/${stDeptBefore}/members/${id}`, { method: 'DELETE' });
    if (dept) await api(`depts/${dept}/members`, { method: 'POST', body: { student_ids: [id] } });
  }
  $('#st-dlg').close();
  toast(editingStudent ? t('Saved ✓') : `${t('Saved ✓')} — ${t('ID number')}: ${id}`, false);
  if (!editingStudent) { const d = studentDefaults; setTimeout(() => openStudent(null, d), 150); } // quick entry of the next student
  reloadCurrent();
});
$('#st-del').onclick = async () => {
  if (!(await askConfirm('Delete this member and all their records?\n(Tip: untick “Active member” instead to keep history.)'))) return;
  await api('students/' + editingStudent, { method: 'DELETE' });
  $('#st-dlg').close();
  toast('Deleted');
  reloadCurrent();
};
$('#st-codes').onclick = () => issueCodes(students.filter(s => s.active));
$('#st-import').onchange = async e => {
  const f = e.target.files[0];
  if (!f) return;
  const text = await f.text();
  e.target.value = '';
  const r = await api('import/students', { method: 'POST', body: { csv: text } });
  toast(I18N.t('Imported {n} member(s)', { n: r.added }) + (r.skipped ? I18N.t(', skipped {n} without a name', { n: r.skipped }) : '') +
    (r.duplicates ? I18N.t(', {n} already in the list (not added again)', { n: r.duplicates }) : ''));
  loaders.students();
};

/* ================= GRADE LIST (መሠረተ ትምህርት 1–12) used by attendance & reports ================= */
const gradeName = g => (g == null ? t('No grade') : gradeLabel(g));
function fillGradeSelects() {
  $$('.grade-select').forEach(sel => {
    const v = sel.value;
    sel.innerHTML = `<option value="">${t('All grades (1–12)')}</option>` +
      Array.from({ length: 12 }, (_, i) => `<option value="${i + 1}">${esc(gradeLabel(i + 1))}</option>`).join('') +
      `<option value="none">${t('No grade')}</option>`;
    sel.value = v;
  });
}
const gradeQuery = sel => $(sel).value;
const gradeTitle = sel => ($(sel).value ? (($(sel).value === 'none') ? t('No grade') : gradeLabel(+$(sel).value)) : t('All grades (1–12)'));

/* ================= ATTENDANCE ================= */
let att = [];
async function loadAttendance() {
  const p = new URLSearchParams({ date: $('#at-date').value, grade: gradeQuery('#at-grade') });
  att = await api('attendance?' + p);
  att.forEach(s => (s._o = s.status || null));          // what the server had, to send only real changes
  const d = new Date($('#at-date').value + 'T12:00');
  $('#at-print-title').textContent = `${I18N.t('Attendance')} — ${$('#at-date').value} (${EthioDate.format(d, false)}) — ${gradeTitle('#at-grade')}`;
  renderAttendance();
}
function renderAttendance() {
  const groups = {};                                   // one section per grade
  att.forEach(s => { const k = s.grade == null ? 'none' : s.grade; (groups[k] = groups[k] || []).push(s); });
  const showHeads = !$('#at-grade').value;
  let html = '';
  Object.keys(groups).sort((a, b) => (a === 'none') - (b === 'none') || a - b).forEach(k => {
    const list = groups[k], here = list.filter(s => s.status === 'P' || s.status === 'L').length;
    if (showHeads) html += `<div class="group-head grade-head"><span>📘 ${esc(gradeName(k === 'none' ? null : +k))}</span>
      <span class="small muted" data-g="${k}">${t('{p} of {n} present', { p: here, n: list.length })}</span></div>`;
    html += list.map((s, n) => { const i = att.indexOf(s);
      return `<div class="att-row ${s.status ? 's-' + s.status : ''}" data-i="${i}">
      <span class="att-no">${n + 1}</span>
      <div class="att-name" data-noi18n><b>${esc(s.full_name)}${s.by_self ? ' <span title="checked in by phone">📱</span>' : ''}</b><span class="muted">${esc(s.christian_name)}</span></div>
      <div class="seg">${Object.keys(STATUS).map(k2 =>
        `<button type="button" class="st-${k2} ${s.status === k2 ? 'on' : ''}" data-s="${k2}" title="${I18N.t(STATUS[k2])}">${LETTERS[I18N.lang][k2]}</button>`).join('')}</div>
      <div class="print-only">${s.status ? I18N.t(STATUS[s.status]) : '☐'}</div>
    </div>`; }).join('');
  });
  $('#at-list').innerHTML = html || `<p class="empty">${t('No students in this grade yet.')}</p>`;
  updateSummary();
}
function updateSummary() {
  const c = { P: 0, L: 0, A: 0, E: 0, '': 0 };
  att.forEach(s => c[s.status || '']++);
  $('#at-summary').innerHTML =
    `<span class="pill">${esc(gradeTitle('#at-grade'))}</span>` +
    `<span class="pill p">${t('Present')} ${c.P}</span><span class="pill l">${t('Late')} ${c.L}</span>` +
    `<span class="pill a">${t('Absent')} ${c.A}</span><span class="pill e">${t('Excused')} ${c.E}</span>` +
    `<span class="pill">${t('Not marked')} ${c['']}</span><span class="pill">${t('Total')} ${att.length}</span>`;
  $$('[data-g]').forEach(el => { const k = el.dataset.g, list = att.filter(s => String(s.grade == null ? 'none' : s.grade) === k);
    el.textContent = t('{p} of {n} present', { p: list.filter(s => s.status === 'P' || s.status === 'L').length, n: list.length }); });
}
$('#at-list').addEventListener('click', e => {
  const b = e.target.closest('[data-s]');
  if (!b) return;
  const row = b.closest('.att-row');
  const s = att[row.dataset.i];
  s.status = s.status === b.dataset.s ? null : b.dataset.s;
  row.className = 'att-row' + (s.status ? ' s-' + s.status : '');
  $$('button', row).forEach(x => x.classList.toggle('on', x.dataset.s === s.status));
  updateSummary();
});
$('#at-all').onclick = () => { att.forEach(s => { if (!s.status) s.status = 'P'; }); renderAttendance(); };
async function saveAttendance() {
  const r = await api('attendance', {
    method: 'POST',
    body: { date: $('#at-date').value, records: att.filter(s => (s.status || null) !== s._o).map(s => ({ student_id: s.id, status: s.status || '' })) }
  });
  att.forEach(s => (s._o = s.status || null));
  toast('Attendance saved ✓');
  if (r.skipped) { toast(t('{n} member(s) were removed or got a new ID number on another device. The list is reloaded.', { n: r.skipped }), true); loadAttendance(); }
}
$('#at-save').onclick = saveAttendance;
$('#at-save2').onclick = saveAttendance;
$('#at-date').onchange = loadAttendance;
$('#at-grade').onchange = loadAttendance;
loaders.attendance = () => loadCheckin().then(loadAttendance);
async function loadCheckin(state) {
  const st = state || await api('checkin');
  $('#ci-state').innerHTML = st.open
    ? `🟢 <b>${t('Self check-in is OPEN')}</b> — ${t('until')} ${esc(st.until.slice(11, 16))}`
    : `🔒 ${t('Self check-in is closed')}`;
  $('#ci-code').hidden = !st.open || !st.code;
  if (st.open && st.code) {
    const tv = location.origin.startsWith('http') ? `${location.origin}/display?key=${encodeURIComponent(st.display_key || '')}` : '';
    $('#ci-code').innerHTML = `${t('Room code')}: <b class="room-code">${esc(st.code)}</b> <span class="muted small">— ${t('Show it on the screen or write it on the board. Members need it to check in, so they must be in the room.')}</span>` +
      (tv ? `<div class="small muted">${t('TV link that shows the code')}: <code>${esc(tv)}</code></div>` : '');
  }
  $('#ci-close').hidden = !st.open;
}
$$('[data-ci]').forEach(b => (b.onclick = async () => { await loadCheckin(await api('checkin', { method: 'POST', body: { minutes: +b.dataset.ci } })); }));
$('#ci-close').onclick = async () => loadCheckin(await api('checkin', { method: 'POST', body: { minutes: 0 } }));

/* ================= REPORTS (by grade) ================= */
const pctOf = s => { const base = s.marked - (s.excused || 0);        // excused absences don't count against anyone
  return base > 0 ? Math.round(100 * (s.present + s.late) / base) : null; };
const barHtml = pct => (pct === null ? '<span class="muted">—</span>'
  : `<div class="bar ${pct >= 75 ? 'good' : pct >= 50 ? 'mid' : 'low'}"><i style="width:${pct}%"></i><span>${pct}%</span></div>`);
async function runReport() {
  const p = new URLSearchParams({ from: $('#rp-from').value, to: $('#rp-to').value, grade: gradeQuery('#rp-grade') });
  const r = await api('report?' + p);
  $('#rp-print-title').textContent = `${t('Attendance report')} ${r.from} → ${r.to} — ${gradeTitle('#rp-grade')}`;
  $('#rp-summary').innerHTML = `<span class="pill">${esc(gradeTitle('#rp-grade'))}</span><span class="pill">${t('{n} attendance day(s) recorded', { n: r.sessions })}</span>` +
    `<span class="pill">${t('{n} students', { n: r.students.length })}</span>`;
  const groups = {};
  r.students.forEach(s => { const k = s.grade == null ? 'none' : s.grade; (groups[k] = groups[k] || []).push(s); });
  let html = '';
  Object.keys(groups).sort((a, b) => (a === 'none') - (b === 'none') || a - b).forEach(k => {
    const list = groups[k];
    const tot = list.reduce((a, s) => ({ pl: a.pl + s.present + s.late, m: a.m + s.marked, P: a.P + s.present, L: a.L + s.late, A: a.A + s.absent, E: a.E + s.excused }), { pl: 0, m: 0, P: 0, L: 0, A: 0, E: 0 });
    const avg = tot.m - tot.E > 0 ? Math.round(100 * tot.pl / (tot.m - tot.E)) : null;
    html += `<tr class="grade-row"><td colspan="3">📘 <b>${esc(gradeName(k === 'none' ? null : +k))}</b> <span class="muted small">· ${t('{n} students', { n: list.length })}</span></td>
      <td>${tot.P}</td><td>${tot.L}</td><td>${tot.A}</td><td>${tot.E}</td><td>${barHtml(avg)}</td></tr>`;
    html += list.map((s, n) => `<tr><td>${n + 1}</td><td data-noi18n><b>${esc(s.full_name)}</b> <span class="muted">${esc(s.christian_name)}</span></td>
      <td>${s.id}</td><td>${s.present}</td><td>${s.late}</td><td>${s.absent}</td><td>${s.excused}</td><td>${barHtml(pctOf(s))}</td></tr>`).join('');
  });
  $('#rp-body').innerHTML = html || '<tr><td colspan="8" class="empty">No data</td></tr>';
}
$('#rp-run').onclick = runReport;
$('#rp-grade').onchange = runReport;
$('#rp-export').onclick = () => download('export/attendance.csv?' +
  new URLSearchParams({ from: $('#rp-from').value, to: $('#rp-to').value, grade: gradeQuery('#rp-grade') }));
loaders.reports = runReport;

/* ================= PROGRAMS ================= */
let programs = [];
function progCard(p) {
  const when = p.repeat_weekday !== null ? t(`Every ${WEEKDAY[p.repeat_weekday]}`) :
    (I18N.lang === 'am' ? `${EthioDate.format(new Date(p.date + 'T12:00'), false)} · ${p.date}` : `${p.date} · ${EthioDate.format(new Date(p.date + 'T12:00'), false)}`);
  return `<div class="prog" data-edit="${p.id}">
    <div class="prog-time">${esc(timeRange(p) || '—')}</div>
    <div class="prog-body"><b data-noi18n>${esc(p.title)}</b>
      <div class="muted small">${esc(when)}${p.leader ? ' · 👤 ' + esc(p.leader) : ''}${p.location ? ' · 📍 ' + esc(p.location) : ''}${p.class_name ? ' · 👥 ' + esc(p.class_name) : ''}</div>
      ${p.description ? `<div class="small">${esc(p.description)}</div>` : ''}</div>
  </div>`;
}
async function loadPrograms() {
  programs = await api('programs');
  const showPast = $('#pg-past').checked, t = today();
  const weekly = programs.filter(p => p.repeat_weekday !== null)
    .sort((a, b) => ((a.repeat_weekday + 1) % 7) - ((b.repeat_weekday + 1) % 7) || (a.start_time || '').localeCompare(b.start_time || ''));
  const once = programs.filter(p => p.repeat_weekday === null && (showPast || p.date >= t));
  $('#pg-weekly').innerHTML = weekly.map(progCard).join('') || '<p class="empty">No weekly programs.</p>';
  $('#pg-once').innerHTML = once.map(progCard).join('') || '<p class="empty">No upcoming one-time programs.</p>';
  loadDay();
}
async function loadDay() {
  const d = $('#pg-day').value;
  const list = await api('programs?date=' + d);
  const dd = new Date(d + 'T12:00');
  $('#pg-day-title').innerHTML = I18N.lang === 'am' ? `${t('Schedule')} — ${EthioDate.format(dd)}<div class="muted small">${dd.toDateString()}</div>`
    : `Schedule — ${dd.toDateString()}<div class="muted small">${EthioDate.format(dd)}</div>`;
  $('#pg-day-list').innerHTML = list.map(progCard).join('') || '<p class="empty">Nothing scheduled.</p>';
}
let editingProgram = null;
function openProgram(p) {
  editingProgram = p ? p.id : null;
  $('#pg-dlg-title').textContent = p ? 'Edit program' : 'Add program';
  fillForm($('#pg-form'), p || { repeat_weekday: '', date: $('#pg-day').value });
  $('#pg-del').hidden = !p;
  toggleDate();
  $('#pg-dlg').showModal();
}
function toggleDate() { $('#pg-date-wrap').hidden = $('#pg-repeat').value !== ''; }
$('#pg-repeat').onchange = toggleDate;
$('#pg-add').onclick = () => openProgram(null);
$('#tab-programs').addEventListener('click', e => {
  const b = e.target.closest('[data-edit]');
  if (b) openProgram(programs.find(p => p.id == b.dataset.edit));
});
onSubmit($('#pg-form'), async e => {
  e.preventDefault();
  const body = formData(e.target);
  if (editingProgram) await api('programs/' + editingProgram, { method: 'PUT', body });
  else await api('programs', { method: 'POST', body });
  $('#pg-dlg').close();
  toast('Saved ✓');
  loaders.programs();
});
$('#pg-del').onclick = async () => {
  if (!(await askConfirm('Delete this program?'))) return;
  await api('programs/' + editingProgram, { method: 'DELETE' });
  $('#pg-dlg').close();
  loaders.programs();
};
$('#pg-past').onchange = loadPrograms;
$('#pg-day').onchange = loadDay;
loaders.programs = () => loadClasses().then(loadPrograms);

/* ================= ANNOUNCEMENTS ================= */
let anns = [];
async function loadAnnouncements() {
  anns = await api('announcements');
  $('#an-list').innerHTML = anns.map(a => `
    <div class="prog ${a.active ? '' : 'inactive'}">
      <div class="prog-body"><span data-noi18n>${esc(a.text)}</span><div class="muted small">${esc(a.created_at)}</div></div>
      <label class="chk"><input type="checkbox" data-toggle="${a.id}" ${a.active ? 'checked' : ''}> On screen</label>
      <button class="btn small danger" data-del="${a.id}">✕</button>
    </div>`).join('') || '<p class="empty">No announcements.</p>';
}
onSubmit($('#an-form'), async e => {
  e.preventDefault();
  await api('announcements', { method: 'POST', body: { text: $('#an-text').value } });
  $('#an-text').value = '';
  loadAnnouncements();
});
$('#an-list').addEventListener('click', async e => {
  const t = e.target.closest('[data-toggle]'), d = e.target.closest('[data-del]');
  if (t) {
    const a = anns.find(x => x.id == t.dataset.toggle);
    await api('announcements/' + a.id, { method: 'PUT', body: { text: a.text, active: t.checked ? 1 : 0 } });
    loadAnnouncements();
  }
  if (d && (await askConfirm('Delete this announcement?'))) {
    await api('announcements/' + d.dataset.del, { method: 'DELETE' });
    loadAnnouncements();
  }
});
loaders.announcements = loadAnnouncements;

/* ================= SETTINGS ================= */
async function loadSettings() {
  const i = await api('info');
  $('#set-school').value = i.school_name;
  if (i.code_days) $('#set-code-days').value = i.code_days;
  const host = location.port ? `:${location.port}` : '';
  const bases = i.online ? [location.origin] : (i.ips && i.ips.length ? i.ips : [location.hostname]).map(ip => `http://${ip}${host}`);
  $('#set-urls').innerHTML = bases.map(b => `<div><b>App:</b> <code>${b}</code><br><b>Members:</b> <code>${b}/#me</code><br><b>Display (TV):</b> <code>${b}/display</code></div>`).join('');
  const help = $('[data-html="connect-help"],[data-html="connect-help-online"]');
  if (help && i.online) { help.dataset.html = 'connect-help-online'; help.innerHTML = I18N.HTML['connect-help-online'][I18N.lang]; }
  document.body.classList.toggle('is-online', !!i.online);
  if ($('#mt-card')) { $('#mt-card').hidden = !!i.online; if (!i.online) loadMaint(); }
}
onSubmit($('#set-name'), async e => {
  e.preventDefault();
  await api('settings', { method: 'POST', body: { school_name: $('#set-school').value } });
  setSchool($('#set-school').value);
  toast('Saved ✓');
});
onSubmit($('#set-pin'), async e => {
  e.preventDefault();
  if ($('#pin-new').value !== $('#pin-new2').value) return toast('New PINs do not match', true);
  if ($('#pin-new').value.length < 6) return toast('New PIN must be at least 6 characters', true);
  const r = await api('pin', { method: 'POST', body: { old: $('#pin-old').value, new: $('#pin-new').value } });
  store(r.token);
  e.target.reset();
  $('#pin-warning').hidden = true;
  toast('PIN changed ✓ (other devices must log in again)');
});
$('#set-backup').onclick = () => download('backup');
onSubmit($('#set-sec'), async () => {
  await api('settings', { method: 'POST', body: { code_days: $('#set-code-days').value } });
  toast('Saved ✓');
});
$('#set-revoke').onclick = async () => {
  if (!(await askConfirm('Log out every other device that is logged in as admin?'))) return;
  await api('sessions/revoke', { method: 'POST', body: {} }); toast('Other devices were logged out');
};
if ($('#set-export-json')) $('#set-export-json').onclick = () => download('export/all.json');
if ($('#set-import-json')) $('#set-import-json').onchange = async e => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  let data;
  try { data = JSON.parse(await f.text()); } catch (err) { return toast('That file is not a backup (.json)', true); }
  if (!(await askConfirm('Replace ALL data on this server with the data from this file?\n(A safety copy of the current data is saved first.)'))) return;
  const r = await api('import/single', { method: 'POST', body: { data } });
  toast(t('Imported: {s} members, {p} programs, {t} tests', { s: r.students, p: r.programs, t: r.tests }));
  setTimeout(() => location.reload(), 1500);
};
loaders.settings = loadSettings;

/* ================= EXPORT: Excel / Word / Spreadsheet / CSV (built in the browser, offline) ================= */
const xp = { kind: null };
const H = list => list.map(h => t(h));
const school = () => $('#school-name').textContent.trim();
const stampNow = () => { const d = new Date(); return `${EthioDate.format(d, false)} · ${isoDate(d)}`; };
const yesNo = v => t(v ? 'Yes' : 'No');
const numOr = v => (v === null || v === undefined || v === '' ? '' : (isNaN(+v) ? v : +v));
const pctVal = s => { const p = pctOf(s); return p === null ? '' : p; };
const gradeKey = s => (s.grade == null ? 'none' : String(s.grade));
const sortedKeys = groups => Object.keys(groups).sort((a, b) => (a === 'none') - (b === 'none') || a - b);
function byGrade(list) { const g = {}; list.forEach(s => (g[gradeKey(s)] = g[gradeKey(s)] || []).push(s)); return g; }
const gName = k => gradeName(k === 'none' ? null : +k);

const EXPORTS = {
  members: {
    what: () => `${t('Members')} — ${$('#st-class').value || t('All classes')}${$('#st-search').value ? ' — “' + $('#st-search').value + '”' : ''}`,
    scopes: () => [['list', t('The list shown now (one table)')], ['grades', t('Grouped by Meserete Timhirt grade (one table per grade)')]],
    async build(scope) {
      const head = H(['#', 'ID number', 'Full name', 'Christian name', 'Gender', 'Birth date (E.C.)', 'Age', 'Grade', 'Departments', 'Parent / guardian', 'Phone', 'Address', 'Consent', 'Active']);
      const row = (s, i) => [i + 1, s.id, s.full_name, s.christian_name || '', s.gender ? t(s.gender) : '', ecBirth(s), numOr(ageOf(s)),
        s.grade ? gradeLabel(s.grade) : '', (s.depts || []).join(', '), s.parent_name || '', s.phone || '', s.address || '', yesNo(s.consent), yesNo(s.active)];
      const sections = scope === 'grades'
        ? sortedKeys(byGrade(students)).map(k => ({ name: gName(k), title: gName(k), headers: head, rows: byGrade(students)[k].map(row) }))
        : [{ name: t('Members'), headers: head, rows: students.map(row) }];
      return { title: `${school()} — ${t('Member list')}`, subtitle: `${EXPORTS.members.what()} · ${stampNow()}`, file: `members-${today()}`, sections };
    },
  },
  depts: {
    what: () => { const d = dp.list.find(x => x.id === dp.id); return `${t('Departments')}${d ? ' — ' + d.name : ''}`; },
    scopes: () => { const d = dp.list.find(x => x.id === dp.id);
      return [['this', `${t('This department')}: ${d ? d.name : ''} — ${t('members and meeting report')} (${$('#dp-from').value} → ${$('#dp-to').value})`],
              ['all', t('All departments (members, one table per department)')]]; },
    async build(scope) {
      const mhead = H(['#', 'Full name', 'Christian name', 'Role', 'Phone', 'Class / group']);
      const mrow = (m, i) => [i + 1, m.full_name, m.christian_name || '', m.role || '', m.phone || '', m.class_name || ''];
      if (scope === 'all') {
        const list = dp.list, sections = [{ name: t('Summary'), title: t('All departments'), headers: H(['#', 'Department', 'Leader', 'Members', 'Active']),
          rows: list.map((d, i) => [i + 1, d.name, d.leader || '', d.count, yesNo(d.active)]),
          totals: ['', t('Total'), '', list.reduce((a, d) => a + d.count, 0), ''] }];
        for (const d of list) sections.push({ name: d.name, title: d.name + (d.leader ? ` — ${t('Leader')}: ${d.leader}` : ''), headers: mhead, rows: (await api(`depts/${d.id}/members`)).map(mrow) });
        return { title: `${school()} — ${t('Departments')}`, subtitle: stampNow(), file: `departments-${today()}`, sections };
      }
      const d = dp.list.find(x => x.id === dp.id); if (!d) throw new Error(t('Choose a department first'));
      const members = await api(`depts/${d.id}/members`);
      const r = await api(`depts/${d.id}/report?` + new URLSearchParams({ from: $('#dp-from').value, to: $('#dp-to').value }));
      const tot = r.members.reduce((a, m) => ({ P: a.P + m.present, L: a.L + m.late, A: a.A + m.absent, E: a.E + m.excused, m: a.m + m.marked }), { P: 0, L: 0, A: 0, E: 0, m: 0 });
      return { title: `${school()} — ${d.name}`, subtitle: `${d.leader ? t('Leader') + ': ' + d.leader + ' · ' : ''}${stampNow()}`, file: `department-${d.name}-${today()}`, sections: [
        { name: t('Members'), title: t('Members'), headers: mhead, rows: members.map(mrow) },
        { name: t('Meeting report'), title: `${t('Meeting report')} ${r.from} → ${r.to} · ${t('{n} meetings recorded', { n: r.sessions })}`,
          headers: H(['#', 'Full name', 'Christian name', 'Role', 'Present', 'Late', 'Absent', 'Excused', 'Attendance %']),
          rows: r.members.map((m, i) => [i + 1, m.full_name, m.christian_name || '', m.former ? t('Former member') : (m.role || ''), m.present, m.late, m.absent, m.excused, pctVal(m)]),
          totals: ['', t('Total'), '', '', tot.P, tot.L, tot.A, tot.E, tot.m - tot.E > 0 ? Math.round(100 * (tot.P + tot.L) / (tot.m - tot.E)) : ''] }] };
    },
  },
  mt: {
    what: () => `መሠረተ ትምህርት — ${mt.data ? mt.data.year + ' ዓ.ም — ' : ''}${semLabel(mt.term)}`,
    scopes: () => [['this', `${t('This grade')}: ${gradeLabel(mt.grade)} (${t('results with every test score, and the student list')})`], ['all', t('All grades 1–12 (one table per grade, plus a summary)')]],
    async build(scope) {
      const results = (g, d) => {
        const by = Object.fromEntries(d.students.map(s => [s.id, s]));
        const rows = [...d.results].sort((a, b) => (a.rank ?? 1e9) - (b.rank ?? 1e9) || by[a.id].full_name.localeCompare(by[b.id].full_name));
        return { name: gradeLabel(g), title: `${gradeLabel(g)} — ${semLabel(d.term)} · ${t('{n} tests', { n: d.tests.length })}`,
          headers: [...H(['Rank', 'ID number', 'Full name', 'Christian name']), ...d.tests.map(x => `${x.title} (/${x.max_score})`), ...H(['Total', 'Out of', 'Average %', 'Tests taken'])],
          rows: rows.map(r => { const s = by[r.id];
            return [r.rank ?? '', s.id, s.full_name, s.christian_name || '', ...d.tests.map(x => numOr(d.scores[x.id + '|' + s.id])), r.total, r.max, r.pct, `${r.taken} / ${d.tests.length}`]; }) };
      };
      const term = new URLSearchParams({ term: mt.term, year: mt.year });
      if (scope === 'all') {
        const grades = (await api('mt/grades')).filter(g => g.students > 0), sections = [], summary = [];
        for (const g of grades) {
          const d = await api(`mt/grade/${g.grade}?` + term), sec = results(g.grade, d);
          const avg = d.results.length && d.tests.length ? Math.round(d.results.reduce((a, r) => a + r.pct, 0) / d.results.length) : '';
          const top = d.tests.length ? d.results.find(r => r.rank === 1) : null, topS = top && d.students.find(s => s.id === top.id);
          summary.push([gradeLabel(g.grade), d.students.length, d.tests.length, avg, topS ? topS.full_name : '']);
          sections.push(sec);
        }
        sections.unshift({ name: t('Summary'), title: `${t('Summary')} — ${semLabel(mt.term)}`, headers: H(['Grade', 'Students', 'Tests', 'Average %', 'First rank']), rows: summary,
          totals: [t('Total'), summary.reduce((a, r) => a + r[1], 0), '', '', ''] });
        return { title: `${school()} — መሠረተ ትምህርት`, subtitle: `${mt.data ? mt.data.year + ' ዓ.ም · ' : ''}${semLabel(mt.term)} · ${stampNow()}`, file: `meserete-timhirt-all-${today()}`, sections };
      }
      const d = await api(`mt/grade/${mt.grade}?` + term);
      return { title: `${school()} — መሠረተ ትምህርት — ${gradeLabel(mt.grade)}`, subtitle: `${d.year} ዓ.ም · ${semLabel(mt.term)} · ${stampNow()}`, file: `meserete-timhirt-grade-${mt.grade}-${today()}`, sections: [
        results(mt.grade, d),
        { name: t('Students'), title: t('Students'), headers: H(['#', 'ID number', 'Full name', 'Christian name', 'Gender']),
          rows: d.students.map((s, i) => [i + 1, s.id, s.full_name, s.christian_name || '', s.gender ? t(s.gender) : '']) }] };
    },
  },
  attendance: {
    what: () => `${t('Attendance')} — ${$('#at-date').value} (${EthioDate.format(new Date($('#at-date').value + 'T12:00'), false)})`,
    scopes: () => [['this', `${t('Shown now')}: ${gradeTitle('#at-grade')}`], ['all', t('All grades 1–12 (one table per grade, plus a summary)')]],
    async build(scope) {
      const list = scope === 'all' && $('#at-grade').value ? await api('attendance?' + new URLSearchParams({ date: $('#at-date').value, grade: '' })) : att;
      const groups = byGrade(list), keys = sortedKeys(groups), summary = [];
      const sections = keys.map(k => { const g = groups[k], c = { P: 0, L: 0, A: 0, E: 0, '': 0 }; g.forEach(s => c[s.status || '']++);
        summary.push([gName(k), g.length, c.P, c.L, c.A, c.E, c['']]);
        return { name: gName(k), title: gName(k), headers: H(['#', 'Full name', 'Christian name', 'Status', 'Checked in by phone']),
          rows: g.map((s, i) => [i + 1, s.full_name, s.christian_name || '', s.status ? t(STATUS[s.status]) : '', s.by_self ? t('Yes') : '']),
          totals: ['', t('Total'), '', `${t('Present')} ${c.P} · ${t('Late')} ${c.L} · ${t('Absent')} ${c.A} · ${t('Excused')} ${c.E}`, ''] }; });
      if (keys.length > 1) sections.unshift({ name: t('Summary'), title: t('Summary'), headers: H(['Grade', 'Students', 'Present', 'Late', 'Absent', 'Excused', 'Not marked']), rows: summary,
        totals: [t('Total'), ...[1, 2, 3, 4, 5, 6].map(i => summary.reduce((a, r) => a + r[i], 0))] });
      return { title: `${school()} — ${t('Attendance')}`, subtitle: `${EXPORTS.attendance.what()} · ${scope === 'all' ? t('All grades (1–12)') : gradeTitle('#at-grade')}`, file: `attendance-${$('#at-date').value}`, sections };
    },
  },
  reports: {
    what: () => `${t('Attendance report')} ${$('#rp-from').value} → ${$('#rp-to').value}`,
    scopes: () => [['this', `${t('Shown now')}: ${gradeTitle('#rp-grade')}`], ['all', t('All grades 1–12 (one table per grade, plus a summary)')]],
    async build(scope) {
      const r = await api('report?' + new URLSearchParams({ from: $('#rp-from').value, to: $('#rp-to').value, grade: scope === 'all' ? '' : gradeQuery('#rp-grade') }));
      const groups = byGrade(r.students), keys = sortedKeys(groups), summary = [];
      const sections = keys.map(k => { const g = groups[k];
        const tot = g.reduce((a, s) => ({ P: a.P + s.present, L: a.L + s.late, A: a.A + s.absent, E: a.E + s.excused, m: a.m + s.marked }), { P: 0, L: 0, A: 0, E: 0, m: 0 });
        const avg = tot.m - tot.E > 0 ? Math.round(100 * (tot.P + tot.L) / (tot.m - tot.E)) : '';
        summary.push([gName(k), g.length, tot.P, tot.L, tot.A, tot.E, avg]);
        return { name: gName(k), title: gName(k), headers: H(['#', 'Full name', 'Christian name', 'ID number', 'Present', 'Late', 'Absent', 'Excused', 'Attendance %']),
          rows: g.map((s, i) => [i + 1, s.full_name, s.christian_name || '', s.id, s.present, s.late, s.absent, s.excused, pctVal(s)]),
          totals: ['', t('Total'), '', '', tot.P, tot.L, tot.A, tot.E, avg] }; });
      if (keys.length > 1) sections.unshift({ name: t('Summary'), title: t('Summary'), headers: H(['Grade', 'Students', 'Present', 'Late', 'Absent', 'Excused', 'Attendance %']), rows: summary });
      return { title: `${school()} — ${t('Attendance report')}`, subtitle: `${r.from} → ${r.to} · ${t('{n} attendance day(s) recorded', { n: r.sessions })} · ${scope === 'all' ? t('All grades (1–12)') : gradeTitle('#rp-grade')}`,
        file: `attendance-report-${r.from}-to-${r.to}`, sections };
    },
  },
};
function openExport(kind) {
  xp.kind = kind;
  const e = EXPORTS[kind];
  $('#exp-what').textContent = e.what();
  $('#exp-scope').innerHTML = e.scopes().map(([v, label], i) =>
    `<label class="chk exp-opt"><input type="radio" name="exp-scope" value="${v}" ${i === 0 ? 'checked' : ''}> <span data-noi18n>${esc(label)}</span></label>`).join('');
  $('#exp-dlg').showModal();
}
$$('#exp-dlg [data-fmt]').forEach(b => (b.onclick = async () => {
  const scope = ($('#exp-scope input:checked') || {}).value;
  $$('#exp-dlg [data-fmt]').forEach(x => (x.disabled = true));
  try {
    const doc = await EXPORTS[xp.kind].build(scope);
    const name = XExport.save(b.dataset.fmt, doc);
    $('#exp-dlg').close();
    toast(`${t('Saved')}: ${name}`);
  } catch (err) { toast(err.message || String(err), true); }
  finally { $$('#exp-dlg [data-fmt]').forEach(x => (x.disabled = false)); }
}));
$('#st-export').onclick = () => openExport('members');
$('#dp-export').onclick = () => openExport('depts');
$('#mt-export').onclick = () => openExport('mt');
$('#at-export').onclick = () => openExport('attendance');
$('#rp-xport').onclick = () => openExport('reports');


/* ================= BACKUP TO USB + UPDATES (computer / Wi-Fi version) ================= */
function usbLine(st) {
  if (!st.usb_last) return `<b style="color:var(--a)">${t('Never backed up to a USB flash drive yet.')}</b>`;
  const old = st.usb_days !== null && st.usb_days > 14;
  return `${t('Last USB backup')}: <b${old ? ' style="color:var(--a)"' : ''}>${esc(st.usb_last)}</b>` +
    ` (${st.usb_days ? t('{n} days ago', { n: st.usb_days }) : t('today')})<br><span class="muted">${esc(st.usb_where)}</span>`;
}
async function loadMaint() {
  const st = await api('maintenance');
  $('#usb-state').innerHTML = usbLine(st) + '<br>' + (st.drives.length
    ? `🟢 ${t('USB / folder found')}: <code>${st.drives.map(esc).join(', ')}</code>`
    : `⚪ ${t('No USB flash drive plugged in now.')}`) +
    `<div class="muted">${t('Your data folder')}: <code>${esc(st.data_dir)}</code></div>`;
  $('#usb-every').value = st.usb_every; $('#usb-folder').value = st.backup_folder || '';
  $('#upd-url').value = st.update_url || '';
  $('#upd-state').innerHTML = `${t('This version')}: <b>${esc(st.version)}</b>` +
    (st.rolled_back ? `<div class="err">${t('The last update did not start, so the previous version was put back')}: ${esc(st.rolled_back)}</div>` : '');
}
$('#usb-now') && ($('#usb-now').onclick = async () => {
  const r = await api('maintenance/usb', { method: 'POST' });
  toast(t('Backup copied to USB ✓'));
  $('#usb-warning').hidden = true;
  loadMaint();
});
$('#usb-form') && onSubmit($('#usb-form'), async e => {
  e.preventDefault();
  await api('maintenance/settings', { method: 'POST', body: { usb_every: $('#usb-every').value, backup_folder: $('#usb-folder').value } });
  toast('Saved ✓'); loadMaint();
});
$('#upd-form') && onSubmit($('#upd-form'), async e => {
  e.preventDefault();
  await api('maintenance/settings', { method: 'POST', body: { update_url: $('#upd-url').value } });
  toast('Saved ✓'); loadMaint();
});
function waitForRestart(version) {
  $('#upd-result').innerHTML = `⏳ ${t('Installing and restarting… the page reloads by itself.')}`;
  let tries = 0;
  const poll = setInterval(async () => {
    tries++;
    try {
      const r = await fetch('/api/maintenance', { headers: { 'X-Token': TOKEN } });
      if (r.ok) { const d = await r.json(); if (d.version === version || tries > 40) { clearInterval(poll); location.reload(); } }
    } catch (e) { /* still restarting */ }
  }, 1500);
}
$('#upd-check') && ($('#upd-check').onclick = async () => {
  $('#upd-result').textContent = t('Checking…');
  let r;
  try { r = await api('maintenance/check', { method: 'POST' }); } catch (e) { $('#upd-result').textContent = t(e.message); return; }
  if (!r.newer) { $('#upd-result').innerHTML = `✅ ${t('You have the newest version')} (${esc(r.current)})`; return; }
  $('#upd-result').innerHTML = `🆕 ${t('New version')}: <b>${esc(r.latest)}</b>${r.notes ? `<div class="muted">${esc(r.notes)}</div>` : ''}
    <button class="btn primary" id="upd-go" style="margin-top:6px">⬆ ${t('Install now')}</button>`;
  $('#upd-go').onclick = async () => {
    if (!(await askConfirm(t('Install version {v}? Your data is kept, and a copy of everything is saved first. The app restarts for a few seconds.', { v: r.latest })))) return;
    const res = await api('maintenance/install', { method: 'POST' });
    waitForRestart(res.installed);
  };
});
$('#upd-file') && ($('#upd-file').onchange = async e => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  if (!(await askConfirm(t('Install the update from "{f}"? Your data is kept, and a copy of everything is saved first.', { f: f.name })))) return;
  const b64 = await new Promise((ok, bad) => { const rd = new FileReader(); rd.onload = () => ok(String(rd.result).split(',')[1]); rd.onerror = bad; rd.readAsDataURL(f); });
  $('#upd-result').textContent = t('Checking…');
  try {
    const res = await api('maintenance/install', { method: 'POST', body: { zip: b64 } });
    waitForRestart(res.installed);
  } catch (err) { $('#upd-result').textContent = t(err.message); }
});
$('#restore-db') && ($('#restore-db').onchange = async e => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  if (!(await askConfirm(t('Replace ALL current data with the backup "{f}"? A copy of the current data is saved first.', { f: f.name })))) return;
  const b64 = await new Promise((ok, bad) => { const rd = new FileReader(); rd.onload = () => ok(String(rd.result).split(',')[1]); rd.onerror = bad; rd.readAsDataURL(f); });
  const r = await api('maintenance/restore', { method: 'POST', body: { db: b64 } });
  toast(t('Restored ✓ ({n} members). Please log in again.', { n: r.members }));
  setTimeout(() => location.reload(), 1800);
});
// remind the admin when there has been no USB copy for two weeks
async function usbReminder() {
  if (!$('#mt-card')) return;
  try {
    const st = await api('maintenance');
    const due = !st.usb_last || (st.usb_days !== null && st.usb_days > 14);
    $('#usb-warning').hidden = !due;
    if (due) $('#usb-warning').innerHTML = `💾 ${t(st.usb_last ? 'No USB backup for more than two weeks. Plug in a flash drive and click' : 'No USB backup yet. Plug in a flash drive and click')} <a href="#" data-goto="settings">${t('Back up to USB now')}</a>.
      <button type="button" class="banner-x" id="usb-x" title="${t('Close')}" aria-label="${t('Close')}">✕</button>`;
    if (due) $('#usb-x').onclick = () => { $('#usb-warning').hidden = true; };   // hidden until the app is opened again
  } catch (e) {}
}




/* ================= ክፍላት — DEPARTMENTS (22 by default, editable) ================= */
const dp = { id: null, list: [], members: [], view: 'members', att: [] };
try { dp.id = +localStorage.getItem('ss_dept') || null; } catch (e) {}

async function loadDeptList() {
  dp.list = await api('depts');
  if (!dp.list.some(d => d.id === dp.id)) dp.id = dp.list.length ? dp.list[0].id : null;
  $('#dp-list').innerHTML = `<div class="gl-title">ክፍላት <span class="muted small">(${dp.list.filter(d => d.active).length})</span></div>` +
    dp.list.map(d => `<button data-dept="${d.id}" class="${d.id === dp.id ? 'on' : ''} ${d.active ? '' : 'off'}" title="${esc(d.name)}">
      <span class="dn" data-noi18n>${esc(d.name)}</span><span class="n">${d.count}</span></button>`).join('') +
    `<button class="add-dept" id="dp-new-dept">+ ${t('Add department')}</button>`;
}
async function loadDept() {
  const d = dp.list.find(x => x.id === dp.id);
  if (!d) { $('#dp-title').textContent = ''; $('#dp-body').innerHTML = ''; return; }
  dp.members = await api(`depts/${d.id}/members`);
  $('#dp-title').innerHTML = `<span data-noi18n>${esc(d.name)}</span>${d.active ? '' : ` <span class="tag">${t('Inactive')}</span>`}`;
  $('#dp-sub').innerHTML = [d.leader ? `${t('Leader')}: <b data-noi18n>${esc(d.leader)}</b>` : '', d.description ? `<span data-noi18n>${esc(d.description)}</span>` : '']
    .filter(Boolean).join(' · ');
  $('#dp-print-title').textContent = `${$('#school-name').textContent} — ${d.name}${d.leader ? ' — ' + t('Leader') + ': ' + d.leader : ''}` +
    (dp.view === 'attendance' ? ` — ${t('Meeting attendance')} ${$('#dp-date').value}` : dp.view === 'report' ? ` — ${t('Meeting report')} ${$('#dp-from').value} → ${$('#dp-to').value}` : '');
  $$('#dp-views button').forEach(b => b.classList.toggle('on', b.dataset.dview === dp.view));
  $$('[data-dfor]').forEach(el => (el.hidden = el.dataset.dfor !== dp.view));
  if (dp.view === 'attendance') return deptAttendance(d);
  if (dp.view === 'report') return deptReport(d);
  renderDeptMembers();
}
function roleOptions(cur) {                           // the department's roles (edited in "Edit department")
  const roles = rolesOf(dp.list.find(x => x.id === dp.id));
  const list = cur && !roles.includes(cur) ? [...roles, cur] : roles;
  return `<option value="">—</option>` + list.map(r => `<option ${r === cur ? 'selected' : ''}>${esc(r)}</option>`).join('');
}
function renderDeptMembers() {
  const q = $('#dp-search').value.trim().toLowerCase();
  const list = dp.members.filter(m => !q || [m.full_name, m.christian_name, m.phone, m.role].some(x => (x || '').toLowerCase().includes(q)));
  $('#dp-body').innerHTML = `<div class="count">${t(dp.members.length === 1 ? '{n} member' : '{n} members', { n: dp.members.length })}</div>
    <div class="table-wrap"><table class="grid"><thead><tr><th>#</th><th>Full name</th><th>Christian name</th><th>Role</th><th>Phone</th><th>Class</th><th class="no-print"></th></tr></thead><tbody>` +
    (list.map((m, i) => `<tr><td>${i + 1}</td><td data-noi18n><b>${esc(m.full_name)}</b></td><td data-noi18n>${esc(m.christian_name)}</td>
      <td><select class="role-in no-print-border" data-role="${m.id}" data-noi18n>${roleOptions(m.role)}</select><span class="print-only" data-noi18n>${esc(m.role || '')}</span></td>
      <td>${m.phone ? `<a href="tel:${esc(m.phone)}">${esc(m.phone)}</a>` : ''}</td><td data-noi18n>${esc(m.class_name)}</td>
      <td class="no-print"><button class="btn small" data-edit-m="${m.id}">Edit</button> <button class="btn small danger" data-rm="${m.id}" title="${t('Remove')}">✕</button></td></tr>`).join('') ||
      `<tr><td colspan="7" class="empty">${t('No members in this department yet. Click “+ Add members”.')}</td></tr>`) + '</tbody></table></div>';
  $$('.role-in').forEach(inp => inp.classList.add('role-print-hide'));
}
loaders.depts = () => loadClasses().then(loadDeptList).then(loadDept);

$('#dp-list').addEventListener('click', e => {
  if (e.target.closest('#dp-new-dept')) return openDept(null);
  const b = e.target.closest('[data-dept]'); if (!b) return;
  dp.id = +b.dataset.dept;
  try { localStorage.setItem('ss_dept', dp.id); } catch (err) {}
  $$('#dp-list [data-dept]').forEach(x => x.classList.toggle('on', x === b));
  $('#dp-search').value = '';
  loadDept();
});
$('#dp-search').oninput = renderDeptMembers;
$('#dp-views').addEventListener('click', e => { const b = e.target.closest('[data-dview]'); if (b) { dp.view = b.dataset.dview; loadDept(); } });

/* department MEETING attendance (separate from Sunday-school attendance) */
async function deptAttendance(d) {
  dp.att = await api(`depts/${d.id}/attendance?date=${$('#dp-date').value}`);
  dp.att.forEach(m => (m._o = m.status || null));
  renderDeptAtt();
}
function renderDeptAtt() {
  const c = { P: 0, L: 0, A: 0, E: 0, '': 0 };
  dp.att.forEach(m => c[m.status || '']++);
  const dd = new Date($('#dp-date').value + 'T12:00');
  $('#dp-body').innerHTML = `<div class="summary"><span class="pill">📅 ${esc(EthioDate.format(dd))}</span>
      <span class="pill p">${t('Present')} ${c.P}</span><span class="pill l">${t('Late')} ${c.L}</span><span class="pill a">${t('Absent')} ${c.A}</span>
      <span class="pill e">${t('Excused')} ${c.E}</span><span class="pill">${t('Not marked')} ${c['']}</span><span class="pill">${t('Total')} ${dp.att.length}</span></div>
    <div class="att-list">` + (dp.att.map((m, i) => `<div class="att-row ${m.status ? 's-' + m.status : ''}" data-di="${i}">
      <span class="att-no">${i + 1}</span>
      <div class="att-name" data-noi18n><b>${esc(m.full_name)}</b><span class="muted">${esc([m.role, m.christian_name].filter(Boolean).join(' · '))}</span></div>
      <div class="seg">${Object.keys(STATUS).map(k => `<button type="button" class="st-${k} ${m.status === k ? 'on' : ''}" data-ds="${k}" title="${t(STATUS[k])}">${LETTERS[I18N.lang][k]}</button>`).join('')}</div>
      <div class="print-only">${m.status ? t(STATUS[m.status]) : '☐'}</div></div>`).join('') ||
      `<p class="empty">${t('No members in this department yet. Click “+ Add members”.')}</p>`) + '</div>';
}
$('#dp-body').addEventListener('click', e => {
  const b = e.target.closest('[data-ds]'); if (!b) return;
  const m = dp.att[b.closest('[data-di]').dataset.di];
  m.status = m.status === b.dataset.ds ? null : b.dataset.ds;
  live.dirty = true;
  renderDeptAtt();
});
$('#dp-all').onclick = () => { dp.att.forEach(m => { if (!m.status) m.status = 'P'; }); live.dirty = true; renderDeptAtt(); };
$('#dp-save').onclick = async () => {
  const r = await api(`depts/${dp.id}/attendance`, { method: 'POST', body: { date: $('#dp-date').value, records: dp.att.filter(m => (m.status || null) !== m._o).map(m => ({ student_id: m.id, status: m.status || '' })) } });
  dp.att.forEach(m => (m._o = m.status || null));
  live.dirty = false;
  toast('Attendance saved ✓');
  if (r.skipped) { toast(t('{n} member(s) were removed or got a new ID number on another device. The list is reloaded.', { n: r.skipped }), true); loadDept(); }
};
$('#dp-date').onchange = () => loadDept();

/* department MEETING report */
async function deptReport(d) {
  const r = await api(`depts/${d.id}/report?` + new URLSearchParams({ from: $('#dp-from').value, to: $('#dp-to').value }));
  const tot = r.members.reduce((a, m) => ({ pl: a.pl + m.present + m.late, mk: a.mk + m.marked - m.excused }), { pl: 0, mk: 0 });
  $('#dp-body').innerHTML = `<div class="summary"><span class="pill">${t('{n} meetings recorded', { n: r.sessions })}</span>
      <span class="pill">${t('{n} members', { n: r.members.length })}</span>
      <span class="pill">${t('Average')}: ${tot.mk ? Math.round(100 * tot.pl / tot.mk) + '%' : '—'}</span></div>
    <div class="table-wrap"><table class="grid"><thead><tr><th>#</th><th>Full name</th><th>Role</th><th>Present</th><th>Late</th><th>Absent</th><th>Excused</th><th>Attendance</th></tr></thead><tbody>` +
    (r.members.map((m, i) => `<tr><td>${i + 1}</td><td data-noi18n><b>${esc(m.full_name)}</b> <span class="muted">${esc(m.christian_name || '')}</span></td>
      <td>${m.former ? `<span class="muted small">${t('Former member')}</span>` : `<span data-noi18n>${esc(m.role || '')}</span>`}</td><td>${m.present}</td><td>${m.late}</td><td>${m.absent}</td><td>${m.excused}</td><td>${barHtml(pctOf(m))}</td></tr>`).join('') ||
      `<tr><td colspan="8" class="empty">${t('No data')}</td></tr>`) + '</tbody></table></div>' +
    (r.meetings.length ? `<p class="small muted">${t('Meeting dates')}: ${r.meetings.map(x => esc(EthioDate.format(new Date(x + 'T12:00'), false))).join(' · ')}</p>` : '');
}
$('#dp-run').onclick = () => loadDept();
$('#dp-body').addEventListener('change', async e => {
  const r = e.target.closest('[data-role]'); if (!r) return;
  await api(`depts/${dp.id}/members/${r.dataset.role}`, { method: 'PUT', body: { role: r.value } });
  const m = dp.members.find(x => x.id == r.dataset.role); if (m) m.role = r.value;
  toast('Saved ✓');
});
$('#dp-body').addEventListener('click', async e => {
  const rm = e.target.closest('[data-rm]'), ed = e.target.closest('[data-edit-m]');
  if (rm) {
    const m = dp.members.find(x => x.id == rm.dataset.rm);
    if (!(await askConfirm(t('Remove from this department?') + '\n' + m.full_name))) return;
    await api(`depts/${dp.id}/members/${m.id}`, { method: 'DELETE' });
    toast('Removed'); loaders.depts();
  }
  if (ed) openStudent(dp.members.find(x => x.id == ed.dataset.editM));
});
$('#dp-new').onclick = () => openStudent(null, { class_name: '', _dept: dp.id });

/* department edit / add */
let editingDept = null;
const DEFAULT_ROLES = ['ሰብሳቢ', 'ምክትል ሰብሳቢ', 'ጸሐፊ', 'ገንዘብ ያዥ', 'ሒሳብ ሹም', 'አስተባባሪ', 'አባል'];
const rolesOf = d => (d && d.roles ? d.roles.split('\n').filter(Boolean) : DEFAULT_ROLES);   // a department's own roles
function openDept(d) {
  editingDept = d ? d.id : null;
  $('#dept-dlg-title').textContent = d ? 'Edit department' : 'Add department';
  fillForm($('#dept-form'), d ? { ...d, roles: rolesOf(d).join('\n') } : { name: `ክፍል ${dp.list.length + 1}`, active: 1, roles: DEFAULT_ROLES.join('\n') });
  $('#dept-del').hidden = !d;
  $('#dept-dlg').showModal();
}
$('#dp-edit').onclick = () => openDept(dp.list.find(x => x.id === dp.id));
onSubmit($('#dept-form'), async e => {
  const body = formData(e.target);
  if (editingDept) await api('depts/' + editingDept, { method: 'PUT', body });
  else { const r = await api('depts', { method: 'POST', body }); dp.id = r.id; }
  $('#dept-dlg').close(); toast('Saved ✓'); loaders.depts();
});
$('#dept-del').onclick = async () => {
  if (!(await askConfirm('Delete this department? (Members are not deleted.)'))) return;
  await api('depts/' + editingDept, { method: 'DELETE' });
  $('#dept-dlg').close(); toast('Deleted'); dp.id = null; loaders.depts();
};

/* pick existing members to add */
let pickAll = [];
async function openPick() {
  const inDept = new Set(dp.members.map(m => m.id));
  pickAll = (await api('students')).filter(s => !inDept.has(s.id));
  $('#pick-search').value = ''; $('#pick-all').checked = false;
  renderPick();
  $('#pick-dlg').showModal();
  setTimeout(() => $('#pick-search').focus(), 50);
}
function renderPick() {
  const q = $('#pick-search').value.trim().toLowerCase(), cls = $('#pick-class').value;
  const list = pickAll.filter(s => (!cls || s.class_name === cls) &&
    (!q || [s.full_name, s.christian_name, s.phone].some(x => (x || '').toLowerCase().includes(q))));
  const was = new Set($$('#pick-list input:checked').map(i => +i.value));
  $('#pick-list').innerHTML = list.map(s => `<label class="pick-row"><input type="checkbox" value="${s.id}" ${was.has(s.id) ? 'checked' : ''}>
    <span data-noi18n><b>${esc(s.full_name)}</b> <span class="muted">${esc(s.christian_name || '')}</span></span>
    <span class="muted small" data-noi18n>${esc(s.class_name || '')}</span></label>`).join('') ||
    `<p class="empty">${t(pickAll.length ? 'No match.' : 'Everyone is already in this department.')}</p>`;
  updatePickBtn();
}
function updatePickBtn() { $('#pick-ok').textContent = `${t('Add selected')} (${$$('#pick-list input:checked').length})`; }
$('#dp-add').onclick = openPick;
$('#pick-search').oninput = renderPick;
$('#pick-class').onchange = renderPick;
$('#pick-list').addEventListener('change', updatePickBtn);
$('#pick-all').onchange = () => { $$('#pick-list input').forEach(i => (i.checked = $('#pick-all').checked)); updatePickBtn(); };
$('#pick-ok').onclick = async () => {
  const ids = $$('#pick-list input:checked').map(i => +i.value);
  if (!ids.length) return $('#pick-dlg').close();
  const r = await api(`depts/${dp.id}/members`, { method: 'POST', body: { student_ids: ids } });
  $('#pick-dlg').close(); toast(t('{n} added', { n: r.added })); loaders.depts();
};

/* ================= SEMESTERS (ወሰነ ትምህርት) ================= */
const SEM1 = '1ኛ ወሰነ ትምህርት', SEM2 = '2ኛ ወሰነ ትምህርት', SEMS = [SEM1, SEM2];
const semLabel = v => (v === SEM1 ? t('First semester') : v === SEM2 ? t('Second semester') : v ? v : t('Whole year'));
function currentSemester() {            // Ethiopian school year: Meskerem–Tir = 1st, Yekatit–Sene (and summer) = 2nd
  const m = EthioDate.fromDate(new Date()).month;
  return m <= 5 ? SEM1 : SEM2;
}
const semList = terms => [...SEMS, ...(terms || []).filter(x => !SEMS.includes(x))];

/* ================= መሠረተ ትምህርት (Grades 1–12) ================= */
const mt = { grade: 1, view: 'students', term: null, year: '', data: null };   // year '' = this school year
try { mt.grade = +localStorage.getItem('ss_mt_grade') || 1; mt.term = localStorage.getItem('ss_mt_term'); } catch (e) {}
if (mt.term === null) mt.term = currentSemester();

async function loadMtGrades() {
  const list = await api('mt/grades');
  $('#mt-grades').innerHTML = `<div class="gl-title">መሠረተ ትምህርት</div>` + list.map(g =>
    `<button data-grade="${g.grade}" class="${g.grade === mt.grade ? 'on' : ''}">${esc(gradeLabel(g.grade))}<span class="n">${g.students}</span></button>`).join('');
}
async function loadMt() {
  const d = mt.data = await api(`mt/grade/${mt.grade}?` + new URLSearchParams({ term: mt.term, year: mt.year }));
  $('#mt-title').textContent = `${gradeLabel(mt.grade)} · ${d.year} ዓ.ም`;
  $('#mt-year').innerHTML = d.years.map(y => `<option value="${y}" ${y === d.year ? 'selected' : ''}>${t('School year')} ${y} ዓ.ም</option>`).join('');
  $('#mt-sem').innerHTML = [...semList(d.terms), ''].map(x =>
    `<button type="button" data-term="${esc(x)}" class="${x === mt.term ? 'on' : ''}">${x === SEM1 ? '①' : x === SEM2 ? '②' : x ? '•' : 'Σ'} ${esc(semLabel(x))}</button>`).join('');
  $('#subject-list').innerHTML = [...new Set(d.tests.map(x => x.subject).filter(Boolean))].map(x => `<option value="${esc(x)}">`).join('');
  $$('#mt-views button').forEach(b => b.classList.toggle('on', b.dataset.view === mt.view));
  $$('[data-for]').forEach(b => (b.hidden = b.dataset.for !== mt.view));
  ({ students: mtStudents, scores: mtScores, ranks: mtRanks })[mt.view](d);
}
loaders.mt = () => loadMtGrades().then(loadMt);

function mtStudents(d) {
  $('#mt-body').innerHTML = `<div class="count">${t(d.students.length === 1 ? '{n} student' : '{n} students', { n: d.students.length })}</div>
  <div class="table-wrap"><table class="grid"><thead><tr><th>#</th><th>ID number</th><th>Full name</th><th>Christian name</th><th>Gender</th><th>One-time code</th><th class="no-print"></th></tr></thead><tbody>` +
  (d.students.map((s, i) => `<tr><td>${i + 1}</td><td><b>${s.id}</b></td><td data-noi18n><b>${esc(s.full_name)}</b></td><td data-noi18n>${esc(s.christian_name)}</td>
    <td>${esc(s.gender)}</td><td>${codeBadge(s)}</td>
    <td class="no-print"><button class="btn small" data-pw="${s.id}">🔑 ${t('New code')}</button> <button class="btn small" data-st="${s.id}">Edit</button></td></tr>`).join('') ||
    `<tr><td colspan="7" class="empty">${t('No students in this grade yet. Click “+ Add student”, or open a student and choose their grade.')}</td></tr>`) +
  '</tbody></table></div>';
}

function mtScores(d) {
  if (!d.tests.length) {
    $('#mt-body').innerHTML = `<p class="empty">${t('No tests yet. Click “+ Add test” to create the first one.')}</p>`;
    return;
  }
  $('#mt-body').innerHTML = `<div class="table-wrap"><table class="grid"><thead><tr><th>#</th><th>Full name</th>` +
    d.tests.map(x => `<th class="test-head" data-test="${x.id}" title="${t('Click to edit')}"><span data-noi18n>${esc(x.title)}</span>
      <small>${t('out of {n}', { n: x.max_score })}${x.term ? ' · ' + esc(semLabel(x.term)) : ''}${x.date ? ' · ' + esc(x.date) : ''}</small></th>`).join('') +
    `<th>Total</th></tr></thead><tbody>` +
    (d.students.map((s, i) => `<tr><td>${i + 1}</td><td data-noi18n><b>${esc(s.full_name)}</b></td>` +
      d.tests.map(x => { const v = d.scores[x.id + '|' + s.id]; return `<td><input class="score-in" type="number" min="0" max="${x.max_score}" step="0.5"
        data-t="${x.id}" data-s="${s.id}" value="${v ?? ''}"></td>`; }).join('') +
      `<td><b data-total="${s.id}"></b></td></tr>`).join('') ||
      `<tr><td colspan="${d.tests.length + 3}" class="empty">${t('No students in this grade yet.')}</td></tr>`) +
    '</tbody></table></div><p class="muted small">' + t('Leave a box empty if the student did not take the test (it counts as 0 in the ranking).') + '</p>';
  updateTotals();
}
function updateTotals() {
  const d = mt.data, max = d.tests.reduce((a, x) => a + x.max_score, 0);
  d.students.forEach(s => {
    let tot = 0;
    $$(`.score-in[data-s="${s.id}"]`).forEach(inp => {
      const v = parseFloat(inp.value), mx = +inp.max;
      inp.classList.toggle('bad', inp.value !== '' && (isNaN(v) || v < 0 || v > mx));
      if (!isNaN(v)) tot += v;
    });
    const el = $(`[data-total="${s.id}"]`); if (el) el.textContent = `${Math.round(tot * 100) / 100} / ${max}`;
  });
}

function mtRanks(d) {
  const by = Object.fromEntries(d.students.map(s => [s.id, s]));
  const rows = [...d.results].sort((a, b) => (a.rank ?? 1e9) - (b.rank ?? 1e9) || by[a.id].full_name.localeCompare(by[b.id].full_name));
  if (!d.tests.length) { $('#mt-body').innerHTML = `<p class="empty">${t('No tests yet. Click “+ Add test” to create the first one.')}</p>`; return; }
  const medal = r => (r === 1 ? '🥇' : r === 2 ? '🥈' : r === 3 ? '🥉' : '');
  const year = !d.term;                         // whole year: show 1st and 2nd semester side by side
  const semTot = (sid, sem) => { const ts = d.tests.filter(x => x.term === sem);
    if (!ts.length) return null;
    const got = ts.reduce((a, x) => a + (d.scores[x.id + '|' + sid] ?? 0), 0), mx = ts.reduce((a, x) => a + x.max_score, 0);
    return `${Math.round(got * 100) / 100} / ${mx} <span class="muted small">(${Math.round(1000 * got / mx) / 10}%)</span>`; };
  $('#mt-body').innerHTML = `<div class="summary"><span class="pill sem-pill">${esc(semLabel(d.term))}</span><span class="pill">${t('{n} tests', { n: d.tests.length })}</span>
    <span class="pill">${t('{n} students', { n: d.students.length })}</span></div>
    <div class="table-wrap"><table class="grid"><thead><tr><th>Rank</th><th>ID number</th><th>Full name</th><th>Christian name</th>` +
    (year ? `<th>${t('First semester')}</th><th>${t('Second semester')}</th><th>${t('Year total')}</th>` : '<th>Total</th>') +
    `<th>Average</th><th>Tests taken</th></tr></thead><tbody>` +
    rows.map(r => { const s = by[r.id], cls = r.pct >= 75 ? 'good' : r.pct >= 50 ? 'mid' : 'low';
      return `<tr class="${r.rank <= 3 ? 'top' + r.rank : ''}"><td><span class="rank-num">${r.rank ?? '—'}</span> <span class="medal">${medal(r.rank)}</span></td>
      <td>${s.id}</td><td data-noi18n><b>${esc(s.full_name)}</b></td><td data-noi18n>${esc(s.christian_name)}</td>
      ${year ? `<td>${semTot(r.id, SEM1) ?? '—'}</td><td>${semTot(r.id, SEM2) ?? '—'}</td>` : ''}
      <td><b>${r.total} / ${r.max}</b></td><td><div class="bar ${cls}"><i style="width:${r.pct}%"></i><span>${r.pct}%</span></div></td>
      <td>${r.taken} / ${d.tests.length}</td></tr>`; }).join('') + '</tbody></table></div>';
}

$('#mt-grades').addEventListener('click', e => {
  const b = e.target.closest('[data-grade]'); if (!b) return;
  mt.grade = +b.dataset.grade;
  try { localStorage.setItem('ss_mt_grade', mt.grade); } catch (err) {}
  $$('#mt-grades button').forEach(x => x.classList.toggle('on', x === b));
  loadMt();
});
$('#mt-views').addEventListener('click', e => { const b = e.target.closest('[data-view]'); if (b) { mt.view = b.dataset.view; loadMt(); } });
$('#mt-sem').addEventListener('click', e => {
  const b = e.target.closest('[data-term]'); if (!b) return;
  mt.term = b.dataset.term;
  try { localStorage.setItem('ss_mt_term', mt.term); } catch (err) {}
  loadMt();
});
$('#mt-year').onchange = () => { const y = +$('#mt-year').value; mt.year = y === mt.data.years[0] ? '' : String(y); loadMt(); };
$('#mt-promote').onclick = async () => {
  const msg = t('New school year: every active student moves up one grade (1→2 … 11→12). Grade 12 students become graduates (no grade). Last year\'s tests and results stay saved under last year. A backup is made first. Do this ONCE, in Meskerem. Continue?');
  if (!(await askConfirm(msg))) return;
  let r;
  try { r = await api('mt/promote', { method: 'POST', body: {} }); }
  catch (e) {
    if (!/already moved up/.test(e.message) || !(await askConfirm(t(e.message)))) return;
    r = await api('mt/promote', { method: 'POST', body: { force: 1 } });
  }
  toast(t('{n} students moved up, {g} graduated', { n: r.moved, g: r.graduated }));
  loaders.mt();
};
$('#mt-add-student').onclick = () => openStudent(null, { grade: mt.grade, class_name: '' });
$('#mt-body').addEventListener('input', e => { if (e.target.classList.contains('score-in')) updateTotals(); });
$('#mt-body').addEventListener('click', e => {
  const st = e.target.closest('[data-st]'), pw = e.target.closest('[data-pw]'), th = e.target.closest('[data-test]');
  if (st) api('students?inactive=1&grade=' + mt.grade).then(l => openStudent(l.find(x => x.id == st.dataset.st)));
  if (pw) issueCodes([mt.data.students.find(x => x.id == pw.dataset.pw)]);
  if (th) openTest(mt.data.tests.find(x => x.id == th.dataset.test));
});
$('#mt-save').onclick = async () => {
  if ($$('.score-in.bad').length) return toast('Some scores are higher than the maximum — please fix the red boxes', true);
  const scores = $$('.score-in').map(i => ({ test_id: +i.dataset.t, student_id: +i.dataset.s, score: i.value === '' ? null : i.value }));
  await api('mt/scores', { method: 'POST', body: { scores } });
  toast('Scores saved ✓');
  loadMt();
};

/* tests */
let editingTest = null;
function openTest(x) {
  editingTest = x ? x.id : null;
  $('#test-dlg-title').textContent = x ? 'Edit test' : 'Add test';
  fillForm($('#test-form'), x || { max_score: 100, term: mt.term || currentSemester(), date: today(), year: mt.data ? mt.data.year : '' });
  $('#test-del').hidden = !x;
  $('#test-dlg').showModal();
}
$('#mt-add-test').onclick = () => openTest(null);
onSubmit($('#test-form'), async e => {
  const body = { ...formData(e.target), grade: mt.grade };
  if (editingTest) await api('mt/tests/' + editingTest, { method: 'PUT', body });
  else await api('mt/tests', { method: 'POST', body });
  $('#test-dlg').close(); toast('Saved ✓'); loaders.mt();
});
$('#test-del').onclick = async () => {
  if (!(await askConfirm('Delete this test and all its scores?'))) return;
  await api('mt/tests/' + editingTest, { method: 'DELETE' });
  $('#test-dlg').close(); toast('Deleted'); loaders.mt();
};

/* ================= ONE-TIME CODES (members use them once to see their own data) ================= */
const fmtUntil = sec => new Date(sec * 1000).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
function codeBadge(s) {
  return s.code_until ? `<span class="pw-yes" title="${t('Unused code, valid until')} ${fmtUntil(s.code_until)}">🔑 ${fmtUntil(s.code_until)}</span>` : '';
}
async function issueCodes(list) {
  list = list.filter(Boolean);
  if (!list.length) return toast('No members to create codes for', true);
  const msg = list.length === 1 ? t('Create a new one-time code for {name}?', { name: list[0].full_name })
                                : t('Create new one-time codes for {n} members?', { n: list.length });
  if (!(await askConfirm(msg + '\n' + t('Any older unused code for them stops working.')))) return;
  const out = await api('codes', { method: 'POST', body: { student_ids: list.map(x => x.id) } });
  showSlips(out);
  reloadCurrent();
}
$('#mt-gen').onclick = () => issueCodes(mt.data.students);
$('#dp-codes').onclick = () => issueCodes(dp.members);
function portalLink() {
  return location.origin.startsWith('http') ? location.origin + '/#me' : '';
}
function slipsHtml(list) {
  const school = $('#school-name').textContent, link = portalLink();
  return list.map(x => `<div class="slip"><div class="s-school">${esc(school)}</div>
    <div class="s-name">${esc(x.full_name)}</div>
    <div>${t('ID number')}: <code>${x.id}</code></div><div>${t('One-time code')}: <code>${esc(x.code)}</code></div>
    <div class="small">${t('Works only once · use before')} ${esc(x.expires)}</div>
    ${link ? `<div class="small muted">${esc(link)}</div>` : ''}</div>`).join('');
}
function showSlips(list) {
  $('#slips').innerHTML = slipsHtml(list);
  $('#slips-print').onclick = () => printOnly(`<div class="slips">${slipsHtml(list)}</div>`);
  $('#slips-dlg').showModal();
}

/* ================= MEMBER PORTAL — one-time code, own results & own attendance only ================= */
const portal = { token: '', term: '', timer: null };      // kept in memory only: closing the page logs out
function openPortal() {
  $('#portal').hidden = false; $('#portal-form').hidden = false; $('#portal-result').hidden = true;
  $('#pt-err').textContent = ''; $('#pt-pw').value = '';
  setTimeout(() => $('#pt-id').focus(), 50);
}
async function closePortal() {
  if (portal.token) { try { await fetch('/api/portal/logout', { method: 'POST', headers: { 'X-Member': portal.token } }); } catch (e) {} }
  portal.token = ''; clearTimeout(portal.timer);
  $('#portal-result').innerHTML = ''; $('#pt-pw').value = '';
  $('#portal').hidden = true;
  if (/^#(me|result)$/.test(location.hash)) history.replaceState(null, '', location.pathname + location.search);
}
async function portalCall(path, method = 'GET', body) {
  const r = await fetch('/api/portal/' + path, { method, headers: { 'X-Member': portal.token, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401) { portalEnded(d.error); throw new Error('ended'); }
  if (!r.ok) throw new Error(d.error || 'Error');
  return d;
}
function portalEnded(msg) {
  portal.token = '';
  $('#portal-result').hidden = true; $('#portal-form').hidden = false;
  $('#pt-err').textContent = t(msg || 'Your session has ended. Ask the admin for a new one-time code.');
}
const ST_NAME = { P: 'Present', L: 'Late', A: 'Absent', E: 'Excused' };
function renderMe(d) {
  const ci = d.checkin, r = d.result, c = d.attendance.counts;
  const medal = r && (r.rank === 1 ? '🥇' : r.rank === 2 ? '🥈' : r.rank === 3 ? '🥉' : '🎓');
  const untilTxt = ci.until ? ci.until.slice(11, 16) : '';
  let check;
  if (ci.status) check = `<div class="ci-done">✅ ${t('Your attendance today')}: <b>${t(ST_NAME[ci.status])}</b>${ci.by_self ? ' 📱' : ''}</div>`;
  else if (ci.open) check = `<label>${t('Room code (on the screen / board)')}<input id="pt-room" inputmode="numeric" maxlength="4" autocomplete="off" class="room-in"></label>
      <button type="button" class="btn primary wide ci-btn" id="pt-checkin">✋ ${t("I'm here — mark my attendance")}</button>
      <div class="small muted" style="text-align:center">${t('Check-in is open until')} ${esc(untilTxt)}</div>`;
  else check = `<div class="ci-closed">🔒 ${t('Self check-in is closed right now')}</div>`;
  $('#portal-result').innerHTML = `
    <div class="res-head"><div class="small">${esc(d.school_name)}</div>
      <div class="rn" data-noi18n>${esc(d.student.full_name)}</div>
      <div class="small" data-noi18n>${esc(d.student.christian_name || '')} · ${t('ID number')} ${d.student.id}</div></div>
    <h3>✅ ${t('Attendance')}</h3>${check}
    <div class="summary" style="margin-top:8px"><span class="pill p">${t('Present')} ${c.P || 0}</span><span class="pill l">${t('Late')} ${c.L || 0}</span>
      <span class="pill a">${t('Absent')} ${c.A || 0}</span><span class="pill e">${t('Excused')} ${c.E || 0}</span></div>
    <div class="small muted">${t('Last 3 months')}</div>
    ${r ? `<h3>📘 መሠረተ ትምህርት · ${esc(gradeLabel(r.grade))}</h3>
      <div class="seg-toggle pt-sem">${[...semList(r.terms), ''].map(x => `<button type="button" data-pt-term="${esc(x)}" class="${x === r.term ? 'on' : ''}">${esc(semLabel(x))}</button>`).join('')}</div>
      ${!r.term && r.tests.length ? `<div class="summary" style="margin-top:8px">${SEMS.map(sm => { const ts = r.tests.filter(x => x.term === sm); if (!ts.length) return '';
          const got = ts.reduce((a, x) => a + (x.score ?? 0), 0), mx = ts.reduce((a, x) => a + x.max_score, 0);
          return `<span class="pill">${esc(semLabel(sm))}: <b>${Math.round(got * 100) / 100} / ${mx}</b></span>`; }).join('')}</div>` : ''}
      ${r.tests.length ? `<div class="res-rank">
        <div>${t('Rank')}<b>${medal} ${r.rank ?? '—'}</b><span class="small">${t('out of {n} students', { n: r.of })}</span></div>
        <div>${t('Average')}<b>${r.pct}%</b><span class="small">${r.total} / ${r.max}</span></div></div>
        <div class="table-wrap"><table class="grid"><thead><tr><th>Test</th><th>Score</th></tr></thead><tbody>` +
        r.tests.map(x => `<tr><td><b data-noi18n>${esc(x.title)}</b><div class="muted small">${[x.subject, x.term, x.date].filter(Boolean).map(esc).join(' · ')}</div></td>
          <td><b>${x.score ?? '—'}</b> / ${x.max_score}</td></tr>`).join('') + '</tbody></table></div>'
        : `<p class="empty">${t('No results have been published yet.')}</p>`}` : ''}
    <p class="small muted" style="margin-top:10px">🔒 ${t('This code worked once. You will be logged out automatically in {n} minutes.', { n: Math.max(1, Math.round(d.expires / 60)) })}</p>
    <div class="row"><button type="button" class="btn" id="pt-print">🖨 Print</button><span class="spacer"></span>
      <button type="button" class="btn primary" id="pt-out">Log out</button></div>`;
  $('#portal-form').hidden = true; $('#portal-result').hidden = false;
  $$('[data-pt-term]').forEach(b => (b.onclick = async () => { portal.term = b.dataset.ptTerm; renderMe(await portalCall('me?term=' + encodeURIComponent(portal.term))); }));
  if ($('#pt-checkin')) $('#pt-checkin').onclick = async () => {
    try { renderMe(await portalCall('checkin?term=' + encodeURIComponent(portal.term), 'POST', { room: $('#pt-room').value })); toast('Attendance saved ✓'); }
    catch (err) { if (err.message !== 'ended') toast(err.message, true); }
  };
  $('#pt-out').onclick = closePortal;
  $('#pt-print').onclick = () => printOnly($('#portal-result').innerHTML);
  clearTimeout(portal.timer);
  portal.timer = setTimeout(() => portalEnded(), Math.max(5, d.expires) * 1000);
}
onSubmit($('#portal-form'), async () => {
  $('#pt-err').textContent = '';
  try {
    const r = await fetch('/api/portal/login', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: $('#pt-id').value.trim(), code: $('#pt-pw').value }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'Error');
    portal.token = d.token; portal.term = currentSemester(); $('#pt-pw').value = '';
    renderMe(await portalCall('me?term=' + encodeURIComponent(portal.term)));
  } catch (err) {
    if (err.message !== 'ended') $('#pt-err').textContent = t(err.message === 'Failed to fetch' ? 'Cannot reach the server' : err.message);
  }
});
$('#open-portal').onclick = e => { e.preventDefault(); openPortal(); };
$('#portal-back').onclick = e => { e.preventDefault(); closePortal(); };


/* ================= CALENDAR — Ethiopian Orthodox feasts, fasts & countdown ================= */
const C = EthioCal;
const cal = { mode: 'eth', y: 0, m: 0, sel: null, programs: [], timer: null };
try { cal.mode = localStorage.getItem('ss_cal_mode') || 'eth'; } catch (e) {}
const WD_EN = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const wdName = w => (I18N.lang === 'am' ? EthioDate.DAYS[w] : WD_EN[w]);
const evName = ev => C.name(ev, I18N.lang);
const fmtEth = j => (I18N.lang === 'am' ? EthioDate.format(C.jdnToDate(j), false)
  : `${C.MONTHS_EN[C.jdnToE(j).month - 1]} ${C.jdnToE(j).day}, ${C.jdnToE(j).year} E.C.`);
const fmtG = j => C.jdnToDate(j).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
const gMonth = (m, style = 'long') => new Date(2000, m - 1, 1).toLocaleDateString('en-GB', { month: style });
const todayJ = () => C.dateToJdn(new Date());
const leftText = n => (n === 0 ? t('Today') : n === 1 ? t('Tomorrow') : n < 0 ? t('{n} days ago', { n: -n }) : t('in {n} days', { n }));
const typeTag = ty => `<span class="tag ${ty}">${t(ty === 'major' ? 'One of the nine major feasts' : ty === 'holiday' ? 'Great holiday' : ty === 'fast' ? 'Fast' : ty === 'event' ? 'Program' : ty === 'saint' ? 'Saint of the day' : 'Feast')}</span>`;

function calToday() {
  const j = todayJ();
  if (cal.mode === 'eth') { const e = C.jdnToE(j); cal.y = e.year; cal.m = e.month; }
  else { const g = C.jdnToG(j); cal.y = g.y; cal.m = g.m; }
}
function monthSpan() {
  if (cal.mode === 'eth') { const start = C.eToJdn(cal.y, cal.m, 1); return { start, len: C.monthLength(cal.y, cal.m) }; }
  const start = C.gToJdn(cal.y, cal.m, 1), next = cal.m === 12 ? C.gToJdn(cal.y + 1, 1, 1) : C.gToJdn(cal.y, cal.m + 1, 1);
  return { start, len: next - start };
}
function programsOn(j) {
  const g = C.jdnToG(j), iso = `${g.y}-${pad(g.m)}-${pad(g.d)}`;
  return cal.programs.filter(p => p.date === iso);
}
function calStep(d) {
  cal.m += d;
  const last = cal.mode === 'eth' ? 13 : 12;
  if (cal.m < 1) { cal.m = last; cal.y--; } else if (cal.m > last) { cal.m = 1; cal.y++; }
  renderCal();
}

async function loadCal() {
  if (!cal.y) calToday();
  try { cal.programs = (await api('programs')).filter(p => p.date); } catch (e) { cal.programs = []; }
  renderCal();
  clearInterval(cal.timer);
  cal.timer = setInterval(() => { if ($('#tab-calendar').classList.contains('active')) renderCountdown(); }, 1000);
}
loaders.calendar = loadCal;

function renderCal() {
  const { start, len } = monthSpan(), tj = todayJ(), lang = I18N.lang;
  $$('.seg-toggle button').forEach(b => b.classList.toggle('on', b.dataset.cal === cal.mode));
  // title: main calendar + the other calendar's span
  const end = start + len - 1;
  let title, sub;
  if (cal.mode === 'eth') {
    title = `${C.monthName(cal.m, lang)} ${cal.y} ${lang === 'am' ? 'ዓ.ም' : 'E.C.'}`;
    const a = C.jdnToG(start), b = C.jdnToG(end);
    sub = a.m === b.m ? `${gMonth(a.m)} ${a.y}` : `${gMonth(a.m, 'short')} ${a.y !== b.y ? a.y + ' ' : ''}– ${gMonth(b.m, 'short')} ${b.y}`;
  } else {
    title = `${gMonth(cal.m)} ${cal.y}`;
    const a = C.jdnToE(start), b = C.jdnToE(end);
    sub = `${C.monthName(a.month, lang)} ${a.year} – ${C.monthName(b.month, lang)} ${b.year}${lang === 'am' ? ' ዓ.ም' : ' E.C.'}`;
  }
  $('#cal-title').innerHTML = `${esc(title)}<div class="muted small" style="font-weight:400">${esc(sub)}</div>`;
  $('#cal-print-title').textContent = `${$('#school-name').textContent} — ${title} (${sub})`;

  // grid
  let html = Array.from({ length: 7 }, (_, w) => `<div class="cal-wd">${esc(wdName(w))}</div>`).join('');
  for (let i = 0; i < C.weekday(start); i++) html += '<div class="cal-cell empty"></div>';
  for (let j = start; j <= end; j++) {
    const di = C.dayInfo(j), progs = programsOn(j);
    const main = cal.mode === 'eth' ? di.e.day : di.g.d;
    const other = cal.mode === 'eth' ? `${gMonth(di.g.m, 'short')} ${di.g.d}` : `${C.monthName(di.e.month, lang)} ${di.e.day}`;
    let evs = di.feasts.map(f => `<div class="ev ${f.type}" title="${esc(evName(f))}">${esc(evName(f))}</div>`).join('');
    evs += progs.map(p => `<div class="ev event" title="${esc(p.title)}" data-noi18n>📌 ${esc(p.title)}</div>`).join('');
    if (!di.feasts.length && di.monthly) evs += `<div class="ev monthly">${esc(di.monthly[lang === 'en' ? 1 : 0])}</div>`;
    const tip = [...di.fasts.map(evName), di.weekly ? t('Wednesday/Friday fast') : ''].filter(Boolean).join(', ');
    html += `<div class="cal-cell ${di.fasting ? 'fasting' : ''} ${j === tj ? 'today' : ''} ${j === cal.sel ? 'sel' : ''}" data-j="${j}" title="${esc(tip)}">
      <div class="d1">${main}</div><div class="d2">${esc(other)}</div>${evs}</div>`;
  }
  $('#cal-grid').innerHTML = html;

  // events this month (feasts, fasts touching the month, our programs)
  const years = [...new Set([C.jdnToE(start).year, C.jdnToE(end).year])];
  const list = [];
  years.forEach(Y => C.year(Y).events.forEach(ev => { if (ev.end >= start && ev.start <= end) list.push(ev); }));
  cal.programs.forEach(p => { const [y, m, d] = p.date.split('-').map(Number), j = C.gToJdn(y, m, d);
    if (j >= start && j <= end) list.push({ start: j, end: j, am: p.title, en: p.title, type: 'event' }); });
  list.sort((a, b) => a.start - b.start);
  $('#cal-month-h').textContent = t('This month');
  $('#cal-month-list').innerHTML = list.map(ev => evRow(ev, tj)).join('') || `<p class="empty">${t('Nothing this month.')}</p>`;

  // upcoming
  $('#cal-upcoming').innerHTML = C.upcoming(tj, { limit: 8 }).map(ev => evRow(ev, tj)).join('');

  // whole year table (Ethiopian year being viewed)
  const Y = cal.mode === 'eth' ? cal.y : C.jdnToE(start).year, info = C.year(Y);
  $('#cal-year-h').textContent = t('Feasts and fasts of {y}', { y: `${Y} ${lang === 'am' ? 'ዓ.ም' : 'E.C.'}` });
  $('#cal-year').innerHTML = `<thead><tr><th>Name</th><th>Type</th><th>Ethiopian date</th><th>Gregorian date</th><th>Day</th><th>When</th></tr></thead><tbody>` +
    info.events.map(ev => `<tr class="${ev.end < tj ? 'past' : ''}"><td><b>${esc(evName(ev))}</b></td><td>${typeTag(ev.type)}</td>
      <td>${esc(fmtEth(ev.start))}${ev.end !== ev.start ? ' → ' + esc(fmtEth(ev.end)) : ''}</td>
      <td>${esc(fmtG(ev.start))}${ev.end !== ev.start ? ' → ' + esc(fmtG(ev.end)) : ''}</td>
      <td>${esc(wdName(C.weekday(ev.start)))}</td>
      <td class="days-left">${ev.start <= tj && tj <= ev.end ? t('Now') : leftText(ev.start - tj)}</td></tr>`).join('') + '</tbody>';

  renderSideCards(Y);
  renderCountdown();
  if (cal.sel) showDay(cal.sel);
}
function evRow(ev, tj) {
  const now = ev.start <= tj && tj <= ev.end;
  return `<div class="prog"><div class="prog-time" style="min-width:110px">${esc(fmtEth(ev.start).replace(/ ቀን /, ' '))}</div>
    <div class="prog-body"><b ${ev.type === 'event' ? 'data-noi18n' : ''}>${esc(evName(ev))}</b> ${typeTag(ev.type)}
      <div class="muted small">${esc(fmtG(ev.start))}${ev.end !== ev.start ? ' → ' + esc(fmtG(ev.end)) + ' (' + t('{n} days', { n: ev.end - ev.start + 1 }) + ')' : ''}</div></div>
    <div class="days-left">${now ? t('Now') : leftText(ev.start - tj)}</div></div>`;
}

function renderSideCards(Y) {
  const tj = todayJ(), di = C.dayInfo(tj), lang = I18N.lang;
  // fasting status today
  const fasts = C.currentFasts(tj);
  let fh = `<h3>${t('Fasting today')}</h3>`;
  if (fasts.length) fh += fasts.map(f => `<div class="fast-now"><b>${esc(evName(f))}</b>
      <div class="small">${t('Day {d} of {n}', { d: f.day, n: f.total })} · ${f.left ? t('{n} days left', { n: f.left }) : t('Last day')}</div>
      <div class="bar fastbar" style="margin-top:6px"><i style="width:${Math.round(100 * f.day / f.total)}%"></i><span>${Math.round(100 * f.day / f.total)}%</span></div></div>`).join('');
  else if (di.weekly) fh += `<div class="fast-now"><b>${t(di.wd === 3 ? 'Wednesday fast' : 'Friday fast')}</b><div class="small">${t('Fast of salvation (ጾመ ድኅነት)')}</div></div>`;
  else if (di.inFifty) fh += `<p>${t('No fasting — the 50 days after Fasika (በዓለ ሃምሳ).')}</p>`;
  else fh += `<p>${t('Today is not a fasting day.')}</p>`;
  const nf = C.upcoming(tj + 1, { types: ['fast'], limit: 1 })[0];
  if (nf) fh += `<p class="small muted">${t('Next fast')}: <b>${esc(evName(nf))}</b> — ${esc(fmtEth(nf.start))} (${leftText(nf.start - tj)})</p>`;
  if (di.monthly) fh = `<div class="saint-now">✝ ${t('Today we commemorate')}: <b>${esc(di.monthly[lang === 'en' ? 1 : 0])}</b></div>` + fh;
  $('#cal-fast').innerHTML = fh;
  renderSaints();

  // Bahire Hasab information
  const b = C.year(Y), lent = b.events.find(e => e.type === 'fast' && e.en.startsWith('Great Lent')),
        nin = b.events.find(e => e.en === 'Fast of Nineveh');
  $('#cal-bh').innerHTML = `<h3>${t('Bahire Hasab')} ${Y}</h3><div class="bh-grid">
    <span>${t('Year')}</span><b>${esc(b.evangelist[lang === 'en' ? 1 : 0])}${b.leap ? ' · ' + t('leap year (Pagume 6)') : ''}</b>
    <span>${t('New Year falls on')}</span><b>${esc(wdName(b.newYearWeekday))}</b>
    <span>ዓመተ ዓለም</span><b>${b.ameteAlem}</b>
    <span>ወንበር · አበቅቴ · መጥቅዕ</span><b>${b.wenber} · ${b.abekte} · ${b.metqi}</b>
    <span>${t('Fast of Nineveh')}</span><b>${esc(fmtEth(nin.start))}</b>
    <span>${t('Great Lent begins')}</span><b>${esc(fmtEth(lent.start))}</b>
    <span>${t('Fasika')}</span><b>${esc(fmtEth(b.E))} · ${esc(fmtG(b.E))}</b></div>`;
}

function renderCountdown() {
  const tj = todayJ(), list = C.upcoming(tj, { types: ['major', 'holiday'], limit: 4 });
  const todays = list.filter(e => e.start === tj), next = list.find(e => e.start > tj);
  if (!next) return;
  const ms = Math.max(0, C.jdnToDate(next.start).getTime() - Date.now());
  const d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, mi = Math.floor(ms / 6e4) % 60, se = Math.floor(ms / 1e3) % 60;
  const after = list.filter(e => e.start > next.start).slice(0, 2);
  $('#cd-card').innerHTML = `
    ${todays.length ? `<div class="cd-kicker">🎉 ${t('Today')}: ${todays.map(e => esc(evName(e))).join(' · ')}</div><hr style="border-color:rgba(255,255,255,.2)">` : ''}
    <div class="cd-kicker">${t('Countdown to the next feast')}</div>
    <div class="cd-name">${esc(evName(next))}</div>
    <div class="cd-date">${esc(wdName(C.weekday(next.start)))}, ${esc(fmtEth(next.start))} · ${esc(fmtG(next.start))}</div>
    <div class="cd-boxes"><div><b>${d}</b><span>${t('days')}</span></div><div><b>${pad(h)}</b><span>${t('hours')}</span></div>
      <div><b>${pad(mi)}</b><span>${t('minutes')}</span></div><div><b>${pad(se)}</b><span>${t('seconds')}</span></div></div>
    ${after.length ? `<div class="cd-more">${t('Then')}: ${after.map(e => `${esc(evName(e))} (${leftText(e.start - tj)})`).join(' · ')}</div>` : ''}`;
}

// "— main yearly feast: ኅዳር 12 · ሰኔ 12"
function annualText(day) {
  const a = C.ANNUAL_OF[day]; if (!a) return '';
  return ` <span class="muted small">— ${t('main yearly feast')}: ${a.map(([m, d]) => esc(C.monthName(m, I18N.lang) + ' ' + d)).join(' · ')}</span>`;
}
// table of the saints commemorated on each day of every month (ወርኃዊ በዓላት)
function renderSaints() {
  const lang = I18N.lang, today = C.dayInfo(todayJ()).e.day;
  $('#cal-saints').innerHTML = `<thead><tr><th>${t('Day')}</th><th>${t('Commemoration (every month)')}</th><th>${t('Main yearly feast')}</th></tr></thead><tbody>` +
    Array.from({ length: 30 }, (_, i) => i + 1).map(d => {
      const m = C.MONTHLY[d], a = C.ANNUAL_OF[d] || [];
      return `<tr${d === today ? ' class="saint-today"' : ''}><td><b>${d}</b></td><td>${esc(m[lang === 'en' ? 1 : 0])}</td>
        <td>${a.map(([mm, dd]) => esc(C.monthName(mm, lang) + ' ' + dd)).join(' · ') || '—'}</td></tr>`;
    }).join('') + '</tbody>';
}

function showDay(j) {
  const di = C.dayInfo(j), progs = programsOn(j), lang = I18N.lang, tj = todayJ();
  let h = `<h3>${esc(wdName(di.wd))}, ${esc(fmtEth(j))}</h3><div class="muted">${esc(fmtG(j))} · ${leftText(j - tj)}</div><div style="margin-top:8px">`;
  di.feasts.forEach(f => (h += `<div>${typeTag(f.type)} <b>${esc(evName(f))}</b></div>`));
  di.fasts.forEach(f => (h += `<div>${typeTag('fast')} <b>${esc(evName(f))}</b> — ${t('Day {d} of {n}', { d: j - f.start + 1, n: f.end - f.start + 1 })}</div>`));
  if (di.weekly && !di.fasts.length) h += `<div>${typeTag('fast')} ${t(di.wd === 3 ? 'Wednesday fast' : 'Friday fast')}</div>`;
  if (!di.fasting && di.inFifty) h += `<div class="muted">${t('No fasting — the 50 days after Fasika (በዓለ ሃምሳ).')}</div>`;
  if (di.monthly) h += `<div>${typeTag('saint')} ${t('Monthly commemoration')}: <b>${esc(di.monthly[lang === 'en' ? 1 : 0])}</b>${annualText(di.e.day)}</div>`;
  progs.forEach(p => (h += `<div>${typeTag('event')} <b data-noi18n>${esc(p.title)}</b> ${esc(timeRange(p))}</div>`));
  $('#cal-day').innerHTML = h + '</div>';
  $('#cal-day').hidden = false;
}
$('#cal-grid').addEventListener('click', e => {
  const c = e.target.closest('[data-j]'); if (!c) return;
  cal.sel = +c.dataset.j;
  $$('.cal-cell.sel').forEach(x => x.classList.remove('sel')); c.classList.add('sel');
  showDay(cal.sel);
});
$('#cal-prev').onclick = () => calStep(-1);
$('#cal-next').onclick = () => calStep(1);
$('#cal-today').onclick = () => { calToday(); cal.sel = todayJ(); renderCal(); };
$$('.seg-toggle button').forEach(b => (b.onclick = () => {
  const { start } = monthSpan();
  cal.mode = b.dataset.cal;
  try { localStorage.setItem('ss_cal_mode', cal.mode); } catch (e) {}
  const mid = cal.sel || start + 14;            // keep roughly the same month in view
  if (cal.mode === 'eth') { const e = C.jdnToE(mid); cal.y = e.year; cal.m = e.month; }
  else { const g = C.jdnToG(mid); cal.y = g.y; cal.m = g.m; }
  renderCal();
}));


/* ================= HEADER CLOCK (daily time, next to the school name) ================= */
function renderHeroCd() {
  const el = $('#hero-cd'); if (!el) return;
  const now = new Date(), H = now.getHours(), mi = pad(now.getMinutes()), se = pad(now.getSeconds());
  // Ethiopian time first (day starts at 6 AM): e.g. 6:39 PM = ምሽት 12:39
  const eh = ((H + 6) % 12) || 12;
  const part = H >= 6 && H < 12 ? 'ጠዋት' : H >= 12 && H < 18 ? 'ከሰዓት' : H >= 18 ? 'ምሽት' : 'ሌሊት';
  const intl = `${pad(H % 12 || 12)}:${mi}:${se} ${H < 12 ? 'AM' : 'PM'}`;
  el.innerHTML = `<div class="hc-k">🕰 ${t('Ethiopian time')}</div>
    <div class="hc-clock"><span class="ap pre">${part}</span><b>${pad(eh)}</b><i>:</i><b>${mi}</b><i>:</i><b class="sec">${se}</b></div>
    <div class="hc-f">${t('International time')}: <b>${intl}</b></div>`;
}
renderHeroCd();
setInterval(renderHeroCd, 1000);


/* ================= LIVE UPDATES — edits made in another browser appear here automatically ================= */
const live = { rev: null, dirty: false, busy: false, every: 4000 };
// mark the page "dirty" while someone is typing or marking, so we never wipe unsaved work
document.addEventListener('input', e => { if (e.target.closest('main')) live.dirty = true; });
document.addEventListener('click', e => {
  if (e.target.closest('.seg button')) live.dirty = true;                          // attendance marks
  if (e.target.closest('#at-save, #at-save2, #mt-save, #tabs button')) live.dirty = false;
});
function refreshSchoolName() {
  fetch('/api/info').then(x => x.json()).then(i => { if (i.school_name) setSchool(i.school_name); }).catch(() => {});
}
function safeToRefresh() {
  if (!TOKEN || !$('#login').hidden || !$('#portal').hidden) return false;
  if ($$('dialog[open]').length) return false;
  const a = document.activeElement;
  if (a && a.closest('main') && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return false;
  return !live.dirty;
}
async function checkLive() {
  if (live.busy || document.hidden || !TOKEN || !$('#login').hidden) return;   // only logged-in admins poll
  live.busy = true;
  try {
    const r = await fetch('/api/changes', { cache: 'no-store' });
    const { v } = await r.json();
    const v2 = String(v);
    if (live.rev === null) live.rev = v2;
    else if (v2 !== live.rev && safeToRefresh()) {
      live.rev = v2;
      reloadCurrent();
      refreshSchoolName();
      toast('Updated from another device ↻');
    }
    $('#live-dot') && ($('#live-dot').className = 'live-dot on');
  } catch (e) {
    $('#live-dot') && ($('#live-dot').className = 'live-dot off');
  } finally { live.busy = false; }
}
live.every = 4000;                                   // online version: every 10 s (saves the free quota)
(function liveLoop() { checkLive().finally(() => setTimeout(liveLoop, live.every)); })();
document.addEventListener('visibilitychange', () => { if (!document.hidden) checkLive(); });
window.addEventListener('storage', e => { if (e.key === 'ssm_data_v1') checkLive(); });   // other tab, same browser

/* ================= START ================= */
function setSchool(name) {
  $('#school-name').textContent = name;
  $('#login-school').textContent = name;
  if ($('#portal-school')) $('#portal-school').textContent = name;
  document.title = name;
}

async function start() {
  const info = await fetch('/api/info').then(r => r.json()).catch(() => null);
  if (info) { setSchool(info.school_name); }
  if (TOKEN) fetch('/api/info', { headers: { 'X-Token': TOKEN } }).then(r => r.json()).then(i => {
    if (i.online) live.every = 10000;
    $('#pin-warning').hidden = !i.default_pin;
    if (i.default_pin) forcePin();
    else if (!i.online) usbReminder();
  }).catch(() => {});
  if (!TOKEN) return showLogin();
  let tab = 'students';
  try { tab = localStorage.getItem('ss_tab') || tab; } catch (e) {}
  openTab(tab);
}

(function init() {
  fillGradeSelects();
  I18N.onChange(fillGradeSelects);
  bdInit();
  $('#st-grade').innerHTML = '<option value="">—</option>' + Array.from({ length: 12 }, (_, i) =>
    `<option value="${i + 1}">${gradeLabel(i + 1)}</option>`).join('');
  I18N.onChange(() => $$('#st-grade option').forEach(o => { if (o.value) o.textContent = gradeLabel(+o.value); }));
  if (/^#(me|result)$/.test(location.hash)) setTimeout(openPortal, 0);
  window.addEventListener('hashchange', () => { if (/^#(me|result)$/.test(location.hash)) openPortal(); });
  const now = new Date();
  const setToday = () => ($('#today-label').textContent = I18N.lang === 'am'
    ? `${EthioDate.format(now)} · ${now.toDateString()}` : `${now.toDateString()} · ${EthioDate.format(now)}`);
  setToday();
  I18N.onChange(() => {
    setToday();
    const cur = $('#tabs button.active');
    if (TOKEN && cur && loaders[cur.dataset.tab]) loaders[cur.dataset.tab]();
    if (typeof showBackupInfo === 'function') showBackupInfo();
  });
  $('#at-date').value = today();
  $('#dp-date').value = today(); $('#dp-to').value = today();
  { const f = new Date(); f.setMonth(f.getMonth() - 3); $('#dp-from').value = isoDate(f); }
  $('#pg-day').value = today();
  $('#rp-to').value = today();
  const from = new Date(); from.setMonth(from.getMonth() - 3);
  $('#rp-from').value = isoDate(from);
  start();
})();

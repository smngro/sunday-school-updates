# Final independent review: Sunday School Manager (ውሉደ አበው ሰንበት ት/ቤት)

Version reviewed and delivered: **2026.11.12.7** (offline Wi-Fi version, single-file version, Android/Termux).
Date: 12 November 2026 (ኅዳር 3, 2019 ዓ.ም).
Scope: whether it can run for **many years** with non-technical volunteers. The Cloudflare online version is **out of scope**: it is frozen at an older version and should not be used for children's data (see §6).

## Verdict

The app is suitable for long-term use, after the fixes below. Its foundations are sound:
- **Dependencies:** only Python's standard library and a browser, so nothing is left to break or expire.
- **Storage:** SQLite, a file format that will stay readable for decades.
- **Data location:** kept outside the app folder.
- **Protection:** weekly USB copies, safe updates with automatic rollback, and restore from Settings.

The review found **one serious defect that would have appeared in Meskerem 2020** (§1, A1) and several smaller ones. All of them are now fixed and tested.

---

## 1. Defects found and fixed in this review

| # | Problem | Impact | Fix |
|---|---|---|---|
| **A1** | **No school year for መሠረተ ትምህርት.** Tests were stored only by grade and semester. | From the next Meskerem, last year's grade-4 tests would have been counted for the new grade-4 students as 0. Totals, % and ranks would have been **wrong for every grade, every year after the first**. | Every test now belongs to a **school year (E.C.)**. The view shows the current year by default, and a year selector shows past years. Existing tests got their year from their date automatically. The student portal and exports use the same year. |
| **A2** | **No way to move students up a grade at the new year.** Admins would have had to edit hundreds of students one by one. | Errors, and lost time every Meskerem. | **"New school year: move everyone up"** button: 1→2 … 11→12, and grade 12 become graduates (`ተመራቂ <year>`). A backup is made first. A second run in the same year needs an extra confirmation. |
| **A3** | **The admin's attendance save could erase a phone check-in.** The page sent every row, blank ones too, so a student who checked in by phone after the admin opened the page lost the mark. | Silent loss of attendance. | The page now sends **only the rows this device changed** (Sunday-school and department attendance). Tested with a real browser. |
| **A4** | **Automatic USB backup wrote to *any* flash drive**, for example a student's drive plugged in to print. | Children's data copied onto strangers' drives. A privacy breach. | Automatic copies go **only** to a drive that already has a `SundaySchool-Backup` folder (made the first time the admin presses "Back up to USB now") or to the chosen folder. |
| **A5** | **Update safety marker written after the new files.** A power cut in the middle of an update could leave a half-old, half-new app with no automatic way back. | The app might not start after a power cut. | The rollback marker is now written **before** any file is replaced. A broken update is put back automatically (tested). |
| **A6** | **Restoring needed manual file copying.** | Volunteers would struggle in an emergency. | **Settings → Restore from a backup file (.db).** It checks the file (SQLite, integrity, tables), saves the current data first, keeps the PIN and upgrades older backups. Nonsense files are refused. |
| **A7** | **No database health check.** A damaged database would have been copied over good backups day after day. | All backups could become copies of a damaged file. | The daily backup runs `PRAGMA quick_check`. If damaged, it **stops replacing old copies** and shows a warning. |
| **A8** | **Mixed backup retention.** Safety copies (before import/update) and daily copies shared one limit of 30. | Fewer real daily copies than expected. | 30 daily copies plus 20 safety copies, kept separately. |

Earlier review rounds fixed: path traversal, forced change of the default PIN, the room code for check-in, CSV formula injection, a public program list, the Windows MIME/blank-page problem, a restore lockout, duplicate imports, excused absences counted as absences, data kept inside the app folder, firewall rules on networks without internet, and the 9-major-feast labels.

## 2. Factual points

- **Ethiopian year:** E.C. years now come from one formula: Meskerem 1 = 11 Sept, or 12 Sept before a Gregorian leap year. Checked for 2015–2020 E.C.
- **Fasika and fasts:** checked for 2016–2019 E.C., and the computus matches Bahire Hasab for 1900–2200.
- **Still needs clergy confirmation:**
  - **Advent length:** 43 or 44 days depending on the year.
  - **Saints:** the full 30-day list and the yearly saints' days. Lists differ slightly between churches. Days 2, 11, 26 and 28 have no yearly date because sources disagree.
- **Law:** Ethiopia's Personal Data Protection Proclamation No. 1321/2024 applies to this data. Keeping it offline, recording consent and keeping backups locked follows its spirit. This is not legal advice.

## 3. Weak assumptions that remain (honest limits)

1. **One-time codes every week.** Students need a new code each time, as requested. Over years this means printing slips every Sunday. *Option:* a personal code valid for a whole semester (needs your decision).
2. **Physical security of the computer.** Anyone who can open the computer can reset the PIN (by deleting `config.json`) or copy the data. *Do:* use a Windows login password and keep the computer locked away.
3. **Plain `http` on the hotspot.** A strong hotspot password is what protects the traffic. Don't run the app on public Wi-Fi.
4. **One admin PIN for everyone.** There are no teacher accounts and no log of who changed what.
5. **Browsers.** The app needs a browser from about 2020 or newer (Chrome 80+). Very old phones with the built-in browser may fail; use Chrome.
6. **Single-file version.** Data lives in one browser (about 5 MB, enough for roughly 10 years of a small school). It is fine as a fallback, but not as the main system.
7. **Android/Termux.** Android can stop background apps. Keep the phone charging and set battery to "Unrestricted". It is a fallback, not the main server.
8. **Update channel.** The SHA-256 checksum proves the download matches `latest.json`, not who published it. Whoever controls the GitHub account controls updates. Turn on two-step login, and remember that the admin must still click Install.
9. **Amharic text** was written by an AI and has not been reviewed by a native speaker.

## 4. Missing information (decide locally)

- **Record retention:** how long to keep records of members who left. Suggestion: review every Meskerem.
- **Results access:** who may see a child's results (the child, the parent, or both).
- **Pass mark** and grading scale for መሠረተ ትምህርት.
- **Teachers repeating grades:** the promotion button moves everyone, so fix repeaters by hand afterwards.

## 5. Long-term sustainability checklist (built in)

| Risk over the years | Protection |
|---|---|
| Computer dies or is stolen | Weekly USB copy (automatic once registered), 30 daily copies, restore from Settings |
| Bad update | Copy of data and app first, automatic rollback, admin must click Install |
| Power cut during update | Rollback marker written first |
| Database damage | Health check; good copies are not overwritten |
| New school year | Year-aware results and the promotion button |
| New computer or new Python | START-Windows.bat checks Python and offers to install it; portable Python is supported |
| New admin | HANDOVER-GUIDE.txt (Amharic/English), yearly checklist |
| Reports for the church office | Export to Excel, Word, ODS or CSV from every section |

## 6. Recommendations (not done)

1. **Delete the old Cloudflare deployment** if it was ever deployed. It is out of date and stores data abroad.
2. **Native-speaker review** of all Amharic screens and slips.
3. **Clergy check** of the calendar and the saints list.
4. **Teacher accounts** per grade or department, with a change log (larger change).
5. **A semester-long personal code** as an alternative to weekly one-time codes (decision needed).

## 7. How this version was tested

All on the delivered code:
- **API and security:** 20/20 checks.
- **Admin and member flows:** 17/17 on the server version, 15/15 on the single file.
- **Exports:** 40/40 combinations, opened with real Excel/Word/ODS readers, on both server and single file.
- **Review fixes:** 16/16 at API level and 7/7 in the browser, on server and single file (school year, migration, promotion, attendance save, USB privacy, restore, health check).
- **Update and rollback:** a good update installs with data kept, and a broken update is rolled back automatically.
- **Python versions:** 3.11, 3.12 and 3.13; the code also parses as 3.8.

Test scripts are in `tests/`.

## 8. Review of the member-form department update (12 Nov 2026, version 2026.11.12.10)

The update "department list in the member form, class / group removed" (2026.11.12.9) was reviewed in the same way.

| # | Problem found | Impact | Fix (2026.11.12.10) |
|---|---|---|---|
| M1 | **Moving a member to another department erased them from the old department's meeting report.** The report listed only current members. The records were still stored but became invisible. | Wrong meeting reports for past months, and a one-click move made this likely | The report lists current members **plus anyone who attended in that period**, marked **"Former member"**. The same holds in the Excel/Word export and the single file. |
| M2 | **Editing a member from the Meserete Timhirt tab wiped the stored class/group value.** The field left the form, so the update sent nothing for it. | Old data lost silently, although the release note promised it was kept | The server and single file now keep the stored value when the form doesn't send it. |
| M3 | **A member in several departments saw only the first one in the form.** | The admin might think the member was in one department only | The form shows "Also in: …" with a hint to change those in the Departments tab. |

What was confirmed correct:
- **Meeting records:** removing a member from a department never deletes their meeting records.
- **Inactive departments:** they are hidden from the list unless the member is already in one.
- **"New member" inside a department:** it preselects that department.

Tests:
- **Department changes:** member-department 9/9, department-history 3/3.
- **Regression:** admin/member 17/17 (server) and 15/15 (single file), exports 40/40, security 20/20, earlier review fixes 16/16.

Remaining limit, by design: the form handles **one** department per member. Use the Departments tab for members who serve in several.

## 9. Review of the ID-number and department-role updates (version 2026.11.12.13)

| # | Problem found | Impact | Fix |
|---|---|---|---|
| R1 | **ID numbers were reused.** If the newest member was deleted, the next new member got the same ID number (confirmed: deleted #2, new member also #2). | Now that the ID number is shown on the form, in lists and in exports, old printouts, slips and Excel files could point to the wrong person. (Their old one-time codes were deleted with them, so no one could log in as someone else.) | IDs are never given twice, for members added by hand or by CSV import. The single-file version already numbered this way. |

Checked and correct:
- **ID field:** it can't be typed over, it shows on edit, and a new member's number is shown after saving.
- **Roles:**
  - commas or new lines both work, duplicates are removed, and long names are cut to 40 characters
  - a member's role stays even if removed from the list
  - other departments keep their own lists
  - roles survive export/import and restore.

Tests:
- **These updates:** ID and roles 4/4, department roles 8/8, member ID 6/6, member department 9/9.
- **Regression:** admin/member 17/17 (server) and 15/15 (single file), exports 40/40, security 20/20, earlier review fixes 16/16.

**Opportunity (not done):** an optional free "card number" field, if the church already prints its own membership cards. The automatic ID number should stay as it is, because members log in with it.

# Independent review: Sunday School Manager (ውሉደ አበው ሰንበት ት/ቤት)

Reviewed: November 2026, all three versions (Wi‑Fi server `server.py`, online Cloudflare Worker, single HTML file).
Method: code reading, then live attacks and end-to-end browser tests against each version. Every **Fixed** item
below was re-tested after the fix. Results: 17/17 checks on Wi‑Fi, 17/17 online, 15/15 single file, and 20/20 API security
probes on both servers.

---

## 1. Security problems (confirmed by live attack, now fixed)

| # | Problem | Impact | Fix |
|---|---------|--------|-----|
| S1 | **Path traversal** in the Wi‑Fi server. `/../` style paths could read files next to `public/` | Anyone on the Wi‑Fi could read files outside the app folder | Strict folder containment check; hidden `.`/`_` files are never served |
| S2 | **Default PIN 1234 kept working forever**; `0000` was an accepted PIN | Any member who guesses 1234 becomes admin | After the first login the app **forces** a new PIN (modal that Esc can't close). Every write is refused with 403 until it is changed. PINs must be at least 6 characters and not obvious (123456, 111111, …) |
| S3 | **Self check-in from home**: a member with a code could mark "present" from anywhere | Attendance numbers could not be trusted | Each time check-in opens, a new **4-digit room code** is made. It is shown to the admin and on the TV through a secret `?key=` link; the public `/display` never shows it. Wrong codes lock that member out for 15 min after 5 tries |
| S4 | **CSV formula injection**: a name like `=HYPERLINK(...)` ran as a formula when the export was opened in Excel | Phishing / data leak through spreadsheets | Cells starting with `= + - @ Tab CR` are prefixed with `'` in every CSV export (all 3 versions) |
| S5 | `/api/programs` was **public** | Anyone could read the internal program list | Admin only; the TV uses the public `/api/display`, which shows only today's items |
| S6 | Inline scripts forced `script-src 'unsafe-inline'` | Weak protection against injected script | TV script moved to `display.js`. The CSP is now `script-src 'self'`, plus `frame-ancestors 'none'` and `base-uri 'none'`. Online, the same headers are set by `_headers` |
| S7 | **Windows MIME risk**: Python reads file types from the Windows registry. On some PCs `.js` is `text/plain`, and with `nosniff` the browser refuses to run the app (blank screen) | App fails on some church PCs | Fixed built-in table of file types |

## 2. Functional bugs (now fixed)

| # | Problem | Fix |
|---|---------|-----|
| B1 | **Restoring a Wi‑Fi/online backup into the single file locked the admin out** (that backup has no PIN) | The current browser's PIN is kept when the backup has none |
| B2 | Importing the same CSV twice **doubled every member** | Duplicates (same full name + Christian name, spaces/case ignored) are skipped and counted in the message |
| B3 | **Excused absences lowered the attendance %**. A sick child with permission looked like a poor attender | `% = (present + late) / (marked − excused)` in class and department reports |
| B4 | Found during testing: a new tick-box was **ticked by default** in the member form | Tick-boxes now follow their HTML default; consent starts unticked |
| B5 | Online: `run_worker_first = true` sent every image/CSS request through the Worker, using up the 100k/day free requests | Only `/api/*` runs the Worker; static files are free |
| B6 | Online: PBKDF2 with 20,000 iterations used ~3 ms CPU per check, close to the free plan's 10 ms limit (Error 1102) | 10,000 for PINs and 4,000 for one-time codes. Old hashes still verify (backward compatible) |

## 3. Factual errors (fixed or flagged)

- **New Year (ዕንቁጣጣሽ) and Meskel were labelled "major feast".** They are great public and church holidays, but they are not
  among the **nine major feasts of the Lord** (ዘጠኙ ዐበይት በዓላት). They now have their own "Great holiday / ታላቅ በዓል"
  type and colour, and they are still counted down.
- **Fasika dates were verified** for 2016–2019 E.C. (5 May 2024, 20 Apr 2025, 12 Apr 2026, 2 May 2027). The computus
  matches Bahire Hasab for every year 1900–2200 (0 mismatches). Ethiopian↔Gregorian round-trip: 0 errors.
- **Flag for the clergy:** the Advent fast (ጾመ ነቢያት) is shown from ኅዳር 15 to the day before Genna. That is **44 days** in most
  years and 43 when Genna falls on ታኅሣሥ 28. Many sources simply say "43 days", and local custom varies.
  Please confirm with your church before printing it.
- The privacy law is **Proclamation No. 1321/2024** (ቁጥር 1321/2016 ዓ.ም.). It was adopted April 2024 and has been in force since July 2024.

## 4. Weak assumptions

1. **"Online is just the same app, anywhere."** Legally it isn't. D1 stores data **outside Ethiopia**, and the proclamation
   restricts transfer and storage of personal data, especially children's. *Recommendation:* keep personal data on the
   offline Wi‑Fi version. Use online only after advice from a lawyer or the Ethiopian Communications Authority.
   A **consent** field was added (member form, CSV, export), and members without consent show ⚠ in the list.
   This is general information, not legal advice.
2. **"Wi‑Fi means private."** The Wi‑Fi version uses plain `http://`. Anyone on the same Wi‑Fi with the right tools could read
   traffic, including the admin token. *Mitigation:* use a password-protected Wi‑Fi that only the Sunday school uses, and don't run
   it on a public hotspot. (HTTPS on a LAN needs a certificate on each phone, which is too complex for this setting.)
3. **"One admin PIN is enough."** Every teacher who needs to take attendance must know the full admin PIN.
   *Recommended next step:* teacher accounts limited to their grade/department.
4. **"Backups are safe."** Daily backups are written to the **same disk**. A dead or stolen PC loses everything.
   *Do now:* once a week, Settings → Export all data → copy to a USB stick kept by another person.
5. **"The Amharic is correct."** The translations were written by an AI and have not been checked by a native speaker.
   Before printing slips or showing the TV publicly, have a deacon or teacher read every screen.

## 5. Missing information (decide locally)

- Who may see a child's results: the child, the parent, or both? Today it is whoever holds the slip.
- How long to keep records of members who have left. The app keeps them until they are deleted.
- The grading scale and pass mark for መሠረተ ትምህርት. Ranks are relative only.
- The official semester dates. The app assumes መስከረም–ጥር = 1st semester, የካቲት–ጳጉሜን = 2nd.

## 6. Improvements added

- Forced first-login PIN setup, room-code check-in and the secret TV link (above).
- **Consent** field with a ⚠ marker; consent is included in the CSV export and import.
- Privacy and security help text in Settings (Amharic and English).
- **Install as an app (PWA):** a manifest and icons, so phones can "Add to Home screen" from the Wi‑Fi or online version.
- Calendar legend: nine major feasts vs great holidays.
- **Saints of every day (ወርኃዊ በዓላት):** all 30 days of the month now have their commemoration (before, only 11 did), and
  each saint's main yearly feast is listed. The calendar has a 30-row table, today's saint on the calendar card and on the TV,
  and the saint plus yearly feast dates when you tap a day. **Verify the list with your clergy**: lists differ slightly between
  churches. Days 2, 11, 26 and 28 have no yearly date yet because sources disagree.

## 6b. Long-term maintenance (added 12 Nov 2026)

- **Weekly USB backup**, automatic when a flash drive is plugged in, with a 2-week warning banner. Restore steps are in HANDOVER-GUIDE.txt.
- **Safe updates:** install from a file (works offline) or from an https `latest.json` with a SHA-256 check. Data and app are copied first, and the old version comes back automatically if the new one fails to start (tested: install → restart → data kept; broken release → rollback).
  *Limit:* the checksum proves the download matches `latest.json`, not who published it. Whoever controls the update address controls the update, so keep that account protected (2-factor).
- **Python check** in START-Windows.bat (version ≥ 3.8, Store-alias trap, portable `python` folder, winget offer). Tested on Python 3.11, 3.12 and 3.13; the code parses as 3.8.
- **HANDOVER-GUIDE.txt**: weekly routine, restore, updates, PIN reset, new computer, yearly checklist.

## 7. Recommended next steps (not done; in priority order)

1. ~~Weekly USB backup~~ — done (automatic).
2. **Native Amharic review** of all screens and printed slips.
3. **Clergy check** of the calendar (Advent length, local saints' days).
4. **Teacher roles** (per grade/department) and an **audit log** of who changed what.
5. Automatic copy of the daily backup to a second drive or USB.
6. Legal check before putting children's data online.

---

## How it was tested

- `final.py` (browser, Playwright): forced PIN, consent marker, one-time codes, member sees only their own record,
  room code (wrong code refused, right code accepted), public TV hides the code, keyed TV shows it, excused % and
  calendar labels. The single file also tests that restore keeps the PIN.
- `api.py` (HTTP): default-PIN write block, weak PINs, admin-only endpoints, 5 path-traversal variants, CSV injection,
  duplicate import, CSP header, JS content type, and no code in the public display.
- Calendar script: Fasika for 4 years, Bahire Hasab vs computus over 1900–2200, and date round-trips.

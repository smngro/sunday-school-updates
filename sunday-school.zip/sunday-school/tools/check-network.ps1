# Sunday School Manager - network fixer and checker (run by ALLOW-PHONES-Windows.bat as administrator)
$ErrorActionPreference = 'SilentlyContinue'
Write-Host ''
Write-Host ' 1) Marking your Wi-Fi / hotspot as a PRIVATE network...'
Write-Host '    (Windows calls a network with no internet "Unidentified" and treats it as Public)'
Get-NetConnectionProfile | ForEach-Object {
  Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory Private
}
Get-NetConnectionProfile | ForEach-Object { Write-Host ("    - {0}: {1}" -f $_.InterfaceAlias, $_.NetworkCategory) }

Write-Host ''
Write-Host ' 2) Opening port 8080 for phones on the same network (with or without internet)...'
netsh advfirewall firewall delete rule name="Sunday School 8080" | Out-Null
netsh advfirewall firewall add rule name="Sunday School 8080" dir=in action=allow protocol=TCP localport=8080 profile=any remoteip=localsubnet | Out-Null
# Python "Block" rules (made when only "Private" was ticked) win over allow rules - remove them
Get-NetFirewallRule -Direction Inbound -Action Block | Where-Object { ($_ | Get-NetFirewallApplicationFilter).Program -like '*python*' } | Remove-NetFirewallRule
Write-Host '    - done'

Write-Host ''
Write-Host ' 3) Checking...'
$listen = Get-NetTCPConnection -LocalPort 8080 -State Listen
if ($listen) { Write-Host '    - The app is running (port 8080 is open).' -ForegroundColor Green }
else { Write-Host '    - The app is NOT running. Start START-Windows.bat after this.' -ForegroundColor Yellow }

$ips = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' }
if (-not $ips) {
  Write-Host '    - This computer is NOT connected to any Wi-Fi or hotspot right now!' -ForegroundColor Red
  Write-Host '      Connect it to the hotspot first, then run this again.'
} else {
  Write-Host ''
  Write-Host '    Phones must be on the SAME Wi-Fi / hotspot and open:' -ForegroundColor Green
  foreach ($ip in $ips) { Write-Host ("       http://{0}:8080      ({1})" -f $ip.IPAddress, $ip.InterfaceAlias) -ForegroundColor Green }
}

$other = Get-CimInstance -Namespace root/SecurityCenter2 -ClassName FirewallProduct
if ($other) {
  Write-Host ''
  Write-Host '    NOTE: another firewall / antivirus is installed:' -ForegroundColor Yellow
  foreach ($o in $other) { Write-Host ("       - {0}" -f $o.displayName) -ForegroundColor Yellow }
  Write-Host '      If phones still cannot connect, allow port 8080 (or Python) in that program too,'
  Write-Host '      or set the network to "Trusted / Home" in it.'
}
